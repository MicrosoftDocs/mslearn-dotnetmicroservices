[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ModuleName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Xml.XmlElement] $ConfigNode,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string] $StagingDirectory,

    $AvailableProjects
)

$configs = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$ModuleName']//scriptcommand[@scriptfolder='$ProjectName']"

if ( -not $configs ) {
    Write-ToLogfile "scriptcommand not found for module '$ModuleName' and project '$ProjectName'"
}

$projects = $configs | ForEach-Object {
    Write-Output $_.Node.Attributes['projectName'].Value
} | Select -Unique

foreach ( $project in $projects ) {
    $jobProject = $AvailableProjects | Where-Object { $_.BaseName -eq $project  }

    if ( -not $jobProject ) {
        throw "SqlAgent project '$project' not found."
    }

    Get-ChildItem -Path "$( $jobProject.FullName )" -Recurse |
    Where-Object { $_.Name.EndsWith("job.xml") } -PipelineVariable jobDefinition |
    ForEach-Object {
        Copy-Item -Path $jobDefinition.FullName -Destination $StagingDirectory
        $jobComponentsPath = $jobDefinition.FullName.Replace("job.xml", '')
        if ( Test-Path $jobComponentsPath ) {
            Copy-Item -Path $jobComponentsPath -Destination $StagingDirectory -Recurse
        }

        Write-ToLogfile "Job '$jobDefinition' copied."
    }
}