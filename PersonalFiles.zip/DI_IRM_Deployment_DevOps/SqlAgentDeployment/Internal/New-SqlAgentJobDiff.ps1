function New-SqlAgentJobDiff {

    [CmdletBinding()]
    param
    (
        #region Type Switches
        #region Job
        [Parameter( Mandatory = $true, ParameterSetName = 'NewJob' )]
        [switch] $NewJob,

        [Parameter( Mandatory = $true, ParameterSetName = 'JobServer' )]
        [switch] $JobServer,

        [Parameter( Mandatory = $true, ParameterSetName = 'Category' )]
        [switch] $Category,

        [Parameter( Mandatory = $true, ParameterSetName = 'NotificationLevel' )]
        [switch] $NotificationLevel,

        [Parameter( Mandatory = $true, ParameterSetName = 'OperatorName' )]
        [switch] $OperatorName,

        #endregion
        #region Steps
        [Parameter( Mandatory = $true, ParameterSetName = 'NewStep' )]
        [switch] $NewStep,

        [Parameter( Mandatory = $true, ParameterSetName = 'ObsoleteStep' )]
        [switch] $ObsoleteStep,

        [Parameter( Mandatory = $true, ParameterSetName = 'SuccessAction' )]
        [switch] $SuccessAction,

        [Parameter( Mandatory = $true, ParameterSetName = 'SuccessStep' )]
        [switch] $SuccessStep,

        [Parameter( Mandatory = $true, ParameterSetName = 'FailureAction' )]
        [switch] $FailureAction,

        [Parameter( Mandatory = $true, ParameterSetName = 'FailureStep' )]
        [switch] $FailureStep,

        [Parameter( Mandatory = $true, ParameterSetName = 'RetryAttempts' )]
        [switch] $RetryAttempts,

        [Parameter( Mandatory = $true, ParameterSetName = 'RetryInterval' )]
        [switch] $RetryInterval,

        [Parameter( Mandatory = $true, ParameterSetName = 'Subsystem' )]
        [switch] $Subsystem,

        [Parameter( Mandatory = $true, ParameterSetName = 'SqlScript' )]
        [switch] $SqlScript,

        [Parameter( Mandatory = $true, ParameterSetName = 'DatabaseName' )]
        [switch] $DatabaseName,

        [Parameter( Mandatory = $true, ParameterSetName = 'SsisPackage' )]
        [switch] $SsisPackage,

        [Parameter( Mandatory = $true, ParameterSetName = 'PsScript' )]
        [switch] $PsScript,

        [Parameter( Mandatory = $true, ParameterSetName = 'Proxy' )]
        [switch] $Proxy,
        #endregion
        #region Schedule
        [Parameter( Mandatory = $true, ParameterSetName = 'NewSchedule' )]
        [switch] $NewSchedule,

        [Parameter( Mandatory = $true, ParameterSetName = 'ObsoleteSchedule' )]
        [switch] $ObsoleteSchedule,

        [Parameter( Mandatory = $true, ParameterSetName = 'ScheduleType' )]
        [switch] $ScheduleType,

        [Parameter( Mandatory = $true, ParameterSetName = 'Interval' )]
        [switch] $Interval,

        [Parameter( Mandatory = $true, ParameterSetName = 'StartDate' )]
        [switch] $StartDate,

        [Parameter( Mandatory = $true, ParameterSetName = 'SubdayType' )]
        [switch] $SubdayType,

        [Parameter( Mandatory = $true, ParameterSetName = 'SubdayInterval' )]
        [switch] $SubdayInterval,

        [Parameter( Mandatory = $true, ParameterSetName = 'StartTime' )]
        [switch] $StartTime,

        [Parameter( Mandatory = $true, ParameterSetName = 'RelativeInterval' )]
        [switch] $RelativeInterval,

        [Parameter( Mandatory = $true, ParameterSetName = 'RecurrenceFactor' )]
        [switch] $RecurrenceFactor,
        #endregion
        #endregion

        #region Step Parameters
        [Parameter( Mandatory = $true, ParameterSetName = 'ObsoleteStep' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SuccessAction' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SuccessStep' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'FailureAction' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'FailureStep' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'RetryAttempts' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'RetryInterval' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'Subsystem' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SqlScript' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'DatabaseName' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SsisPackage' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'PsScript' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'Proxy' )]
        [ValidateNotNullOrEmpty()]
        [string] $StepName,
        #endregion

        #region Schedule Parameters
        [Parameter( Mandatory = $true, ParameterSetName = 'ObsoleteSchedule' )]
        [string] $ScheduleName,
        #endregion

        #region DesiredValue ParameterSets
        #region Job
        [Parameter( Mandatory = $true, ParameterSetName = 'NewJob' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'JobServer' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'Category' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'NotificationLevel' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'OperatorName' )]
        #endregion
        #region Step
        [Parameter( Mandatory = $true, ParameterSetName = 'NewStep' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SuccessAction' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SuccessStep' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'FailureAction' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'FailureStep' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'RetryAttempts' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'RetryInterval' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'Subsystem' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SqlScript' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'DatabaseName' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SsisPackage' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'PsScript' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'Proxy' )]
        #endregion
        #region Schedule
        [Parameter( Mandatory = $true, ParameterSetName = 'NewSchedule' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'ScheduleType' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'Interval' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'StartDate' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SubdayType' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'SubdayInterval' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'StartTime' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'RelativeInterval' )]
        [Parameter( Mandatory = $true, ParameterSetName = 'RecurrenceFactor' )]
        #endregion
        #endregion
        $DesiredValue
    )

    $difference = [ordered] @{
        Type = $PsCmdlet.ParameterSetName
    }

    if ( $StepName ) {
        $difference.StepName = $StepName
    }

    Write-ToLogfile "Found $( $difference.Type ) difference for '$StepName'."

    switch ( $difference.Type ) {

        #region Job

        NewJob {
            $difference.Job = $DesiredValue
        }

        JobServer {
            $difference.Job = $DesiredValue
        }

        Category {
            $difference.Job = $DesiredValue
        }

        NotificationLevel {
            $difference.Job = $DesiredValue
        }

        OperatorName {
            $difference.Job = $DesiredValue
        }

        #endregion
        #region Step

        NewStep {
            $difference.Step = $DesiredValue
        }

        ObsoleteStep {} # no additional parameters necessary

        SuccessAction {
            $difference.Step = $DesiredValue
        }

        SuccessStep {
            $difference.Step = $DesiredValue
        }

        FailureAction {
            $difference.Step = $DesiredValue
        }

        FailureStep {
            $difference.Step = $DesiredValue
        }

        RetryAttempts {
            $difference.Step = $DesiredValue
        }

        RetryInterval {
            $difference.Step = $DesiredValue
        }

        Subsystem {
            $difference.Step = $DesiredValue
        }

        SqlScript {
            $difference.Step = $DesiredValue
        }

        DatabaseName {
            $difference.Step = $DesiredValue
        }

        SsisPackage {
            $difference.Step = $DesiredValue
        }

        PsScript {
            $difference.Step = $DesiredValue
        }

        Proxy {
            $difference.Step = $DesiredValue
        }

        #endregion
        #region Schedule
        NewSchedule {
            $difference.Schedule = $DesiredValue
        }

        ObsoleteSchedule {
            $difference.ScheduleName = $ScheduleName
        }

        ScheduleType {
            $difference.Schedule = $DesiredValue
        }

        Interval {
            $difference.Schedule = $DesiredValue
        }

        SubdayType {
            $difference.Schedule = $DesiredValue
        }

        SubdayInterval {
            $difference.Schedule = $DesiredValue
        }

        StartTime {
            $difference.Schedule = $DesiredValue
        }
        #endregion

        default {
            throw "New-SqlAgentJobDiff type '$_' is not implemented."
        }
    }

    New-Object -Type PsObject -Property $difference | Write-Output
}
