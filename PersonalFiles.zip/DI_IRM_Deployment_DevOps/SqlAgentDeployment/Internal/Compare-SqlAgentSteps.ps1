function Compare-SqlAgentSteps {

    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Desired,

        $Current = $null
    )

    if ( $Current.Name -ne $Desired.Name -and $Current  ) {
        throw "mismatching Name is not implemented."
    }

    # Id
    if ( $Current.Id -ne $Desired.Id -and $Current ) {
        Write-ToLogfile "Found mismatching step Ids: current: $( $Current.Id ) and desired $( $Desired.Id )."
        New-SqlAgentJobDiff -ObsoleteStep -StepName $Current.Name
        New-SqlAgentJobDiff -NewStep -DesiredValue $Desired
    }

    # Success
    if ( $Current.SuccessAction -ne $Desired.SuccessAction ) {
        New-SqlAgentJobDiff -SuccessAction -StepName $Desired.Name -DesiredValue $Desired
    }
    if ( $Current.SuccessStep -ne $Desired.SuccessStep ) {
        New-SqlAgentJobDiff -SuccessStep -StepName $Desired.Name -DesiredValue $Desired
    }

    # Retry
    if ( $Current.RetryAttempts -ne $Desired.RetryAttempts ) {
        New-SqlAgentJobDiff -RetryAttempts -StepName $Desired.Name -DesiredValue $Desired
    }
    if ( $Current.RetryInterval -ne $Desired.RetryInterval ) {
        New-SqlAgentJobDiff -RetryInterval -StepName $Desired.Name -DesiredValue $Desired
    }

    # Failure
    if ( $Current.FailureAction -ne $Desired.FailureAction ) {
        New-SqlAgentJobDiff -FailureAction -StepName $Desired.Name -DesiredValue $Desired
    }
    if ( $Current.FailureStep -ne $Desired.FailureStep ) {
        New-SqlAgentJobDiff -FailureStep -StepName $Desired.Name -DesiredValue $Desired
    }

    # Subsystem
    if ( $Current.Subsystem -ne $Desired.Subsystem ) {
        New-SqlAgentJobDiff -Subsystem -StepName $Desired.Name -DesiredValue $Desired
    }

    # Command
    switch ( $Desired.Subsystem ) {
        TSQL {
            if ( $Current.SqlScript -ne $Desired.SqlScript ) {
                New-SqlAgentJobDiff -SqlScript -StepName $Desired.Name -DesiredValue $Desired
            }
            if ( $Current.DatabaseName -ne $Desired.DatabaseName ) {
                New-SqlAgentJobDiff -DatabaseName -StepName $Desired.Name -DesiredValue $Desired
            }
        }
        SSIS {

            #region calc SSIS-Command

            $ssisCmd = ''

            if ( $Desired.SsisPackage.CatalogPath ) {
                $ssisCmd = $ssisCmd + '/ISSERVER "' + $Desired.SsisPackage.CatalogPath + '" '
            }

            if ( $Desired.SsisPackage.CatalogServer ) {
                $ssisCmd = $ssisCmd + '/SERVER "' + $Desired.SsisPackage.CatalogServer + '" '
            }

            if ( $Desired.SsisPackage.CatalogEnvironment ) {
                $ssisCmd = $ssisCmd + '/ENVREFERENCE ' + (
                    Get-SsisEnvironmentId -ServerInstance $Desired.SsisPackage.CatalogServer -Name $Desired.SsisPackage.CatalogEnvironment
                ) + ' '
            }

            if ( $Desired.SsisPackage.Architecture ) {
                $ssisCmd = $ssisCmd + '/' + $Desired.SsisPackage.Architecture + ' '
            }

            $ssisCmd = $ssisCmd + '/Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True '

            $Desired | Add-Member -NotePropertyName 'SsisCommand' -NotePropertyValue $ssisCmd

            #endregion

            if ( ( $Current.SsisPackage.CatalogPath -ne $Desired.SsisPackage.CatalogPath ) -or
                ( $Current.SsisPackage.CatalogServer -ne $Desired.SsisPackage.CatalogServer ) -or
                ( $Current.SsisPackage.CatalogEnvironment -ne $Desired.SsisPackage.CatalogEnvironment ) -or
                ( $Current.SsisPackage.Architecture -ne $Desired.SsisPackage.Architecture ) -or
                ( $Current.SsisPackage.Par -ne @( '"\"$ServerOption::SYNCHRONIZED(Boolean)\"";True' ) ))
            {
                New-SqlAgentJobDiff -SsisPackage -StepName $Desired.Name -DesiredValue $Desired
            }
        }
        PowerShell {
            if ( $Current.PsScript -ne $Desired.PsScript ) {
                New-SqlAgentJobDiff -PsScript -StepName $Desired.Name -DesiredValue $Desired
            }
        }
        default {
            throw "Compare Command for Subsystem '$_' is not implemented."
        }
    }

    # Subsystem
    if ( $Current.Proxy -ne $Desired.Proxy ) {
        New-SqlAgentJobDiff -Proxy -StepName $Desired.Name -DesiredValue $Desired
    }
}
