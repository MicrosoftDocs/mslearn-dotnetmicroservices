function Convert-ToSqlAgentSchedule {
    [CmdletBinding()]
    param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true,
            Position=0)
        ]
        $Source,

        [Parameter(Mandatory=$true)]
        [ValidateSet("DataRow", "XML")]
        [string] $From,

        [Parameter(Mandatory=$false)]
        [hashtable] $DeploymentParameter
    )

    process {

        $typeCodes = @{
            1 = 'Once'
            4 = 'Days'
            8 = 'Weeks'
            16 = 'Months'
            32 = 'Months relative'
            64 = 'On Startup'
            128 = 'On Idle'
        }

        $subdayTypeCodes = @{
            1 = 'Once'
            2 = 'Seconds'
            4 = 'Minutes'
            8 = 'Hours'
        }

        $relativeTypecodes = @{
            1 = 'First'
            2 = 'Second'
            4 = 'Third'
            8 = 'Fourth'
            16 = 'Last'
        }

        $property = [ordered] @{}

        switch ( $From ) {
            DataRow {
                $property.Name = $Source.Name
                $property.Type = $typeCodes[$Source.Type]
                $property.Interval = $Source.Interval
                $startDate = [datetime]::ParseExact( $Source.StartDate, 'yyyyMMdd', [System.Globalization.CultureInfo]::InvariantCulture )
                if ( $startDate -gt ( Get-Date ) ) {
                    $property.StartDate = $startDate
                }
                $property.SubdayType = $subdayTypeCodes[$Source.SubdayType]
                $property.SubdayInterval = $Source.SubdayInterval
                if ( $Source.StartTime ) {
                    $startTime = $Source.StartTime.ToString().PadLeft(6, '0')
                    $property.StartTime = [timespan]::ParseExact( $startTime, 'hhmmss', [System.Globalization.CultureInfo]::CurrentCulture )
                }
                if ( $Source.RelativeInterval ) {
                    $property.RelativeInterval = $Source.RelativeInterval
                }
                if ( $Source.RecurrenceFactor ) {
                    $property.RecurrenceFactor = $Source.RecurrenceFactor
                }
            }
            Xml {
                $property.Name = $Source.Node.Attributes['Name'].Value

                $typeCodes.GetEnumerator() | ForEach-Object {
                    [int] $code = $_.Key
                    [string] $type = $_.Value

                    Select-Xml $Source.Node -XPath "./$( $type.Replace(' ', '') )" | ForEach-Object {
                        $typeXml = $_
                        $property.Type = $type
                        $property.TypeCode = $code
                        $property.Interval = [int] $typeXml.Node.Attributes['Interval'].Value

                        $subdayTypeCodes.GetEnumerator() | ForEach-Object {
                            [int] $subdayCode = $_.Key
                            [string] $subdayType = $_.Value

                            Select-Xml $typeXml.Node -XPath "./$( $subdayType.Replace(' ', '') )" | ForEach-Object {
                                $subdayTypeXml = $_
                                $property.SubdayType = $subdayType
                                $property.SubdayTypeCode = $subdayCode
                                $property.SubdayInterval = [int] $subdayTypeXml.Node.Attributes['Interval'].Value
                                if ( $subdayTypeXml.Node.Attributes['StartTime'].Value ) {
                                    $property.StartTime = [timespan] (
                                        $subdayTypeXml.Node.Attributes['StartTime'].Value |
                                        Set-ParameterValues -Parameter $DeploymentParameter
                                    )
                                } else {
                                    $property.StartTime = "00:00:00"
                                }
                            }
                        }

                    }

                }
            }
            default {
                throw "Convert-ToSqlAgentSchedule -From '$From' is not implemented."
            }
        }

        $jobSchedule = New-Object -Type PsObject -Property $property
        Write-Output $jobSchedule
    }
}
