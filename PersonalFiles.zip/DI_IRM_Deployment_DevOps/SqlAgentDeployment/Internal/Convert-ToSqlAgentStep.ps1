function Convert-ToSqlAgentStep
{
    [CmdletBinding()]
    param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true,
            Position=0)
        ]
        $Source,

        [Parameter(Mandatory=$true)]
        [ValidateSet("DataRow", "XML")]
        [string] $From,

        [Parameter(Mandatory=$false)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$false)]
        [hashtable] $DeploymentParameter
    )

    process {

        $actionCodes = @{
            1 = 'Success'
            2 = 'Failure'
            3 = 'Goto Next'
            4 = 'Goto Step'
        }

        Write-ToLogfile "Convert Sql Agent Step from '$From'."

        $property = [ordered] @{}

        switch ( $From ) {
            DataRow {
                $property.Id = $Source.Id
                Write-ToLogfile "Step Id is '$( $property.Id )'."

                $property.Name = $Source.Name
                Write-ToLogfile "Step Name is '$( $property.Name )'."

                # Success
                $property.SuccessActionCode = [int] $Source.SuccessAction
                Write-ToLogfile "Step SuccessActionCode is '$( $property.SuccessActionCode )'."

                $property.SuccessAction = $actionCodes[ $property.SuccessActionCode ]
                Write-ToLogfile "Step SuccessAction is '$( $property.SuccessAction )'."

                if ( $successAction -eq 'Goto Step' -and $Source.SuccessStep) {
                    $property.SuccessStep = $Source.SuccessStep
                    Write-ToLogfile "Step SuccessStep is '$( $property.SuccessStep )'."
                }

                # Failure
                $property.FailureActionCode = [int] $Source.FailureAction
                Write-ToLogfile "Step FailureActionCode is '$( $property.FailureActionCode )'."

                $property.FailureAction = $actionCodes[ $property.FailureActionCode ]
                Write-ToLogfile "Step FailureAction is '$( $property.FailureAction )'."

                if ( $failureAction -eq 'Goto Step' -and $Source.FailureStep ) {
                    $property.FailureStep = $Source.FailureStep
                    Write-ToLogfile "Step FailureStep is '$( $property.FailureStep )'."
                }

                # Retry
                $property.RetryAttempts = $Source.RetryAttempts
                Write-ToLogfile "Step RetryAttempts is '$( $property.RetryAttempts )'."

                $property.RetryInterval = $Source.RetryInterval
                Write-ToLogfile "Step RetryInterval is '$( $property.RetryInterval )'."

                # Subsystem
                $property.Subsystem = $Source.Subsystem
                Write-ToLogfile "Step Subsystem is '$( $property.Subsystem )'."

                switch ( $Source.Subsystem ) {
                    TSQL {
                        $property.SqlScript = $Source.Command.ToString().Trim() | Write-Output
                        Write-ToLogfile "Step SqlScript is '$( $property.SqlScript )'."

                        $property.DatabaseName = $Source.DatabaseName
                        Write-ToLogfile "Step DatabaseName is '$( $property.DatabaseName )'."
                    }
                    SSIS {
                        $ssisParams = @{}
                        (( ' ' + $Source.Command ) -split ' /' ) | Where-Object { $_ } | ForEach-Object {
                            $key, $value = $_ -split ' ', 2

                            switch ( $key ) {
                                ENVREFERENCE {
                                    $value = Get-SsisEnvironmentName -Id $value -ServerInstance $ServerInstance
                                    $key = "CatalogEnvironment"
                                    Write-ToLogfile "Step CatalogEnvironment is '$( $value )'."
                                }

                                ISSERVER {
                                    $value = $value.Replace('\"', '').Trim('"')
                                    $key = "CatalogPath"
                                    Write-ToLogfile "Step CatalogPath is '$( $value )'."
                                }

                                SERVER {
                                    $value = $value.Replace(' ', '').Replace('\"', '').Trim('"')
                                    $key = "CatalogServer"
                                    Write-ToLogfile "Step CatalogServer is '$( $value )'."
                                }

                                X86 {
                                    $value = "X86"
                                    $key = "Architecture"
                                    Write-ToLogfile "Step Architecture is '$( $value )'."
                                }
                            }

                            if ( $key ) {
                                $ssisParams[$key] = @( $ssisParams[$key] ) + $value | Where-Object { $_ }
                            }
                        }
                        $property.SsisPackage = New-Object -Type PsObject -Property $ssisParams
                    }
                    PowerShell {
                        $property.PsScript = $Source.Command.ToString().Trim() | Write-Output
                        Write-ToLogfile "Step PsScript is '$( $property.PsScript )'."
                    }
                    CmdExec {
                        $property.BatchScript = $Source.Command.ToString().Trim() | Write-Output
                        Write-ToLogfile "Step BatchScript is '$( $property.BatchScript )'."
                    }
                    default {
                        throw "Command '$( $Source.Command )' is not implemented for subsystem '$( $Source.Subsystem )'. Appeared in step '$( $Source.Name )'."
                    }
                }

                if ( $Source.Proxy -and $Source.Proxy -ne [DBNull]::Value ) {
                    $property.Proxy = $Source.Proxy
                }
            }

            XML {
                $Source.Node.Attributes | ForEach-Object {
                    $attribute = $_
                    $property.( $attribute.Name ) = $attribute.Value
                    Write-ToLogfile "Set '$( $attribute.Name )' to '$( $attribute.Value )'"
                }

                # set defaults
                @{
                    SuccessAction = "Goto Next"
                    RetryAttempts = 0
                    RetryInterval = 0
                    FailureAction = "Failure"
                }.GetEnumerator() |
                ForEach-Object {
                    if ( -not $property.Contains($_.Key) ) {
                        $property[$_.Key] = $_.Value
                        Write-ToLogfile "Set '$( $_.Key )' default to '$( $_.Value )'"
                    }
                }

                if ( $property.SuccessStep ) {
                    $property.SuccessAction = "Goto Step"
                    Write-ToLogfile "Step SuccessAction is '$( $property.SuccessAction )'."
                }

                if ( $property.FailureStep ) {
                    $property.FailureAction = "Goto Step"
                    Write-ToLogfile "Step FailureAction is '$( $property.FailureAction )'."
                }

                $property.SuccessActionCode = $actionCodes.GetEnumerator() |
                Where-Object { $_.Value -eq $property.SuccessAction } |
                ForEach-Object { $_.Key } |
                Select -First 1
                Write-ToLogfile "Step SuccessActionCode is '$( $property.SuccessActionCode )'."

                $property.FailureActionCode = $actionCodes.GetEnumerator() |
                Where-Object { $_.Value -eq $property.FailureAction } |
                ForEach-Object { $_.Key } |
                Select-Object -First 1
                Write-ToLogfile "Step FailureActionCode is '$( $property.FailureActionCode )'."

                switch ($Source.Node.Attributes['Subsystem'].Value) {
                    TSQL {
                        $property.DatabaseName = $Source.Node.SqlScript.Attributes['Database'].Value
                        Write-ToLogfile "Step DatabaseName is '$( $property.DatabaseName )'."

                        $scriptPath = $Source.Node.SqlScript.Attributes['Path'].Value
                        $absoluteScriptPath = "$( ( Get-Item $Path ).Directory.FullName )/$scriptPath"
                        if ( -not ( $absoluteScriptPath ) ) {
                            throw "The path '$absoluteScriptPath' does not exist."
                        }
                        $property.SqlScript = ( Get-Content -Path $absoluteScriptPath -Raw ).Trim() |
                        Set-ParameterValues -Parameter $DeploymentParameter
                        Write-ToLogfile "Step SqlScript is '$( $property.SqlScript )'."
                    }
                    SSIS {
                        $property.SsisPackage = New-Object -Type PsObject -Property @{
                            CatalogPath = (
                                $Source.Node.SsisPackage.Attributes['CatalogPath'].Value |
                                Set-ParameterValues -Parameter $DeploymentParameter
                            )
                            CatalogServer = (
                                $Source.Node.SsisPackage.Attributes['CatalogServer'].Value |
                                Set-ParameterValues -Parameter $DeploymentParameter
                            )
                            CatalogEnvironment = (
                                $Source.Node.SsisPackage.Attributes['CatalogEnvironment'].Value |
                                Set-ParameterValues -Parameter $DeploymentParameter
                            )
                            Architecture = (
                                $Source.Node.SsisPackage.Attributes['Architecture'].Value
                            )
                        }
                        Write-ToLogfile "Step CatalogPath is '$( $property.CatalogPath )'."
                        Write-ToLogfile "Step CatalogServer is '$( $property.CatalogServer )'."
                        Write-ToLogfile "Step CatalogEnvironment is '$( $property.CatalogEnvironment )'."
                        Write-ToLogfile "Step Architecture is '$( $property.Architecture )'."

                        $property.Proxy = (
                            $Source.Node.SsisPackage.Attributes['Proxy'].Value |
                            Set-ParameterValues -Parameter $DeploymentParameter
                        )
                        Write-ToLogfile "Step Proxy is '$( $property.Proxy )'."
                    }
                    PowerShell {
                        $scriptPath = $Source.Node.PsScript.Attributes['Path'].Value
                        $absoluteScriptPath = "$( ( Get-Item $Path ).Directory.FullName )/$scriptPath"
                        if ( -not ( $absoluteScriptPath ) ) {
                            throw "The path '$absoluteScriptPath' does not exist."
                        }
                        $property.PsScript = ( Get-Content -Path $absoluteScriptPath -Raw ).Trim() |
                        Set-ParameterValues -Parameter $DeploymentParameter
                        Write-ToLogfile "Step scriptPath is '$( $property.scriptPath )'."

                        $property.Proxy = (
                            $Source.Node.PsScript.Attributes['Proxy'].Value |
                            Set-ParameterValues -Parameter $DeploymentParameter
                        )
                        Write-ToLogfile "Step Proxy is '$( $property.Proxy )'."
                    }
                    default {
                        throw "conversion of '$_' is not implemented"
                    }
                }
            }

            default {
                throw "Convert-ToSqlAgentStep -From '$From' is not implemented."
            }
        }

        New-Object -Type PsObject -Property $property | Write-Output
    }
}
