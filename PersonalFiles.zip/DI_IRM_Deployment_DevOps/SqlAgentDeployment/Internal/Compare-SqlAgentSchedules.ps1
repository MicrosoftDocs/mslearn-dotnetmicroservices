function Compare-SqlAgentSchedules {

    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Desired,

        $Current = $null
    )

    if ( $Current.Name -ne $Desired.Name -and $Current  ) {
        throw "mismatching Name is not implemented."
    }

    if ( $Current.Type -ne $Desired.Type ) {
        New-SqlAgentJobDiff -ScheduleType -DesiredValue $Desired
    }
    if ( $Current.Interval -ne $Desired.Interval ) {
        New-SqlAgentJobDiff -Interval -DesiredValue $Desired
    }
    if ( $Current.StartDate -ne $Desired.StartDate ) {
        New-SqlAgentJobDiff -StartDate -DesiredValue $Desired
    }
    if ( $Current.SubdayType -ne $Desired.SubdayType ) {
        New-SqlAgentJobDiff -SubdayType -DesiredValue $Desired
    }
    if ( $Current.SubdayInterval -ne $Desired.SubdayInterval ) {
        New-SqlAgentJobDiff -SubdayInterval -DesiredValue $Desired
    }
    if ( $Current.StartTime -ne $Desired.StartTime ) {
        New-SqlAgentJobDiff -StartTime -DesiredValue $Desired
    }
    if ( $Current.RelativeInterval -ne $Desired.RelativeInterval ) {
        New-SqlAgentJobDiff -RelativeInterval -DesiredValue $Desired
    }
    if ( $Current.RecurrenceFactor -ne $Desired.RecurrenceFactor ) {
        New-SqlAgentJobDiff -RecurrenceFactor -DesiredValue $Desired
    }
}