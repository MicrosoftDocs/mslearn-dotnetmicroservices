function Compare-SqlAgentJobs {

    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Desired,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Current
    )

    if ( -not $Current -or -not $Current.Name ) {
        New-SqlAgentJobDiff -NewJob -DesiredValue $Desired
    }

    if ( -not $Current -or $Current.JobServer -lt 0 ) {
        New-SqlAgentJobDiff -JobServer -DesiredValue $Desired
    }

    if ( -not $Current -or $Current.Category -ne $Desired.Category ) {
        New-SqlAgentJobDiff -Category -DesiredValue $Desired
    }

    if ( $Desired.NotificationLevel -eq 'Never' ) {
        $Desired.NotificationLevel = 'On failure'
        $Desired.NotificationLevelCode = 2
        $Desired.OperatorName = ''
    }

    if ( -not $Current -or $Current.NotificationLevel -ne $Desired.NotificationLevel ) {
        New-SqlAgentJobDiff -NotificationLevel -DesiredValue $Desired
    }

    if ( -not $Current -or $Current.OperatorName -ne $Desired.OperatorName ) {
        New-SqlAgentJobDiff -OperatorName -DesiredValue $Desired
    }

    #region Steps

    Write-ToLogfile "Current steps are: $( $Current.Steps | ForEach-Object { '[' + $_.Name + ']' } )"
    Write-ToLogfile "Desired steps are: $( $Desired.Steps | ForEach-Object { '[' + $_.Name + ']' } )"

    #region Current Steps
    if ( $Current.Steps ) {
        foreach ( $currentStep in $Current.Steps )
        {
            $desiredStep = $Desired.Steps | Where-Object { $_.Name -eq $currentStep.Name } | Select-Object -First 1

            if ( -not $desiredStep ) {
                Write-ToLogfile "Found obsolete current step [$( $currentStep.Id )]:[$( $currentStep.Name )]."
                New-SqlAgentJobDiff -ObsoleteStep -StepName $currentStep.Name
            } else {
                Write-ToLogfile "Compare desired step [$( $desiredStep.Id )]:[$( $desiredStep.Name )] with current step [$( $currentStep.Id )]:[$( $currentStep.Name )]."
                Compare-SqlAgentSteps -Current $currentStep -Desired $desiredStep
            }
        }
    }
    #endregion
    #region Desired Steps
    foreach ( $desiredStep in $Desired.Steps )
    {
        $currentStep = $Current.Steps | Where-Object { $_.Name -eq $desiredStep.Name } | Select-Object -First 1

        if ( -not $currentStep ) {
            Write-ToLogfile "Found new desired step [$( $desiredStep.Id )]:[$( $desiredStep.Name )]."
            New-SqlAgentJobDiff -NewStep -DesiredValue $desiredStep
            Compare-SqlAgentSteps -Desired $desiredStep
        }
    }
    #endregion
    #endregion
    #region Schedules

    Write-ToLogfile "Current schedules are: $( $Current.Schedules | ForEach-Object { '[' + $_.Name + ']' } )"
    Write-ToLogfile "Desired schedules are: $( $Desired.Schedules | ForEach-Object { '[' + $_.Name + ']' } )"

    #region Current Schedules
    if ( $Current.Schedules ) {
        foreach ( $currentSchedule in $Current.Schedules ) {
            $desiredSchedule = $Desired.Schedules | Where-Object { $_.Name -eq $currentSchedule.Name } | Select-Object -First 1

            if ( -not $desiredSchedule ) {
                Write-ToLogfile "Found obsolete current schedule [$( $currentSchedule.Name )]."
                New-SqlAgentJobDiff -ObsoleteSchedule -ScheduleName $currentSchedule.Name
            } else {
                Write-ToLogfile "Compare desired schedule [$( $desiredSchedule.Name )] with current schedule [$( $currentSchedule.Name )]."
                Compare-SqlAgentSchedules -Current $currentSchedule -Desired $desiredSchedule
            }
        }
    }
    #endregion

    #region Desired Schedules
    foreach ( $desiredSchedule in $Desired.Schedules )
    {
        $currentSchedule = $Current.Schedules | Where-Object { $_.Name -eq $desiredSchedule.Name } | Select-Object -First 1

        if ( -not $currentSchedule ) {
            Write-ToLogfile "Found new desired schedule '$( $desiredSchedule.Name )'."
            New-SqlAgentJobDiff -NewSchedule -DesiredValue $desiredSchedule
            Compare-SqlAgentSchedules -Desired $desiredSchedule
        }
    }
    #endregion
    #endregion
}
