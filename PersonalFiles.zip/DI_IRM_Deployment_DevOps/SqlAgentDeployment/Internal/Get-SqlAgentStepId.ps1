function Get-SqlAgentStepId {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $JobName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $StepName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance
    )

    [System.Data.DataTable] $data = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "msdb" -SqlCommand @"
SELECT StepId = s.step_id
FROM sysjobsteps s
JOIN sysjobs j ON j.job_id = s.job_id
WHERE 1 = 1
    AND j.name = '$JobName'
    AND s.step_name = '$StepName'
"@

    ( $data | Select-Object -First 1 )[0] | Write-Output
}
