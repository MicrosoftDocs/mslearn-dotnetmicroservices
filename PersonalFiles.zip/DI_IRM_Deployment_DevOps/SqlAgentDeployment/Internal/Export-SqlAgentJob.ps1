function Export-SqlAgentJob
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Job,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Path
    )

    Write-ToLogfile "Export job to '$Path'"

    $xmlWriter = New-Object System.XMl.XmlTextWriter( $Path, $null )

    # choose a pretty formatting:
    $xmlWriter.Formatting = 'Indented'
    $xmlWriter.Indentation = 1
    $xmlWriter.IndentChar = "`t"

    # write the header
    $xmlWriter.WriteStartDocument()
    $xmlWriter.WriteStartElement('Job')

#region Steps
    $xmlWriter.WriteStartElement("Steps")
    foreach ( $step in $Job.Steps ) {
        $xmlWriter.WriteStartElement("Step")
        $xmlWriter.WriteAttributeString("Name", $step.Name)

        # Success
        switch ($step.SuccessAction) {
            "Goto Next" {
                # ignore default
            }
            "Goto Step" {
                $xmlWriter.WriteAttributeString("SuccessStep", $step.SuccessStep)
            }
            default {
                $xmlWriter.WriteAttributeString("SuccessAction", $step.SuccessAction)
            }
        }

        # Retry
        switch ($step.RetryAttempts) {
            0 {
                # ignore default
            }
            default {
                $xmlWriter.WriteAttributeString("RetryAttempts", $step.RetryAttempts)
                $xmlWriter.WriteAttributeString("RetryInterval", $step.RetryInterval)
            }
        }

        # Failure
        switch ($step.FailureAction) {
            "Failure" {
                # ignore default
            }
            "Goto Step" {
                $xmlWriter.WriteAttributeString("FailureStep", $step.FailureStep)
            }
            default {
                $xmlWriter.WriteAttributeString("FailureAction", $step.FailureAction)
            }
        }

        # Subsystem
        $xmlWriter.WriteAttributeString("Subsystem", $step.Subsystem )
        switch ( $step.Subsystem ) {
            "TSQL" {
                $xmlWriter.WriteStartElement("SqlScript")
                $xmlWriter.WriteAttributeString("Database", $step.DatabaseName )

                $jobDirectoryPath = "$( ( Get-Item $Path ).Directory.FullName )/$( $Job.Name )"
                New-Item -Path $jobDirectoryPath -ItemType Directory -Force | Out-Null
                $scriptName = "$( $step.Name -replace "[^a-zA-Z0-9 ]", '' ).sql"
                $scriptPath = "$jobDirectoryPath/$scriptName"
                $step.SqlScript | Out-File -FilePath $scriptPath

                $xmlWriter.WriteAttributeString("Path", "./$( $Job.Name )/$scriptName" )

                $xmlWriter.WriteEndElement() # close SqlScript
            }
            "SSIS" {
                $xmlWriter.WriteStartElement("SsisPackage")

                $xmlWriter.WriteAttributeString("CatalogServer", $step.SsisPackage.CatalogServer)
                $xmlWriter.WriteAttributeString("CatalogPath", $step.SsisPackage.CatalogPath)

                switch ($step.SsisPackage.REPORTING)
                {
                    "E" {
                        # ignore default
                    }
                    default {
                        $xmlWriter.WriteAttributeString("Reporting", $step.SsisPackage.REPORTING )
                    }
                }

                switch ($step.SsisPackage.CALLERINFO)
                {
                    "SQLAGENT" {
                        # ignore default
                    }
                    default {
                        $xmlWriter.WriteAttributeString("CallerAgent", $step.SsisPackage.CALLERINFO )
                    }
                }

                $xmlWriter.WriteAttributeString("CatalogEnvironment", $step.SsisPackage.CatalogEnvironment )
                $xmlWriter.WriteAttributeString("Proxy", $step.Proxy)

                if ( $step.SsisPackage.Architecture ) {
                    $xmlWriter.WriteAttributeString("Architecture", $step.SsisPackage.Architecture )
                }

                $step.SsisPackage.Par | ForEach-Object {
                    switch( $_ ){
                        '"\"$ServerOption::LOGGING_LEVEL(Int16)\"";1' {
                            # ignore default
                        }
                        '"\"$ServerOption::SYNCHRONIZED(Boolean)\"";True' {
                            # ignore default
                        }
                        '' {
                            # ingore empty parameter
                        }
                        default {
                            $xmlWriter.WriteElementString("Parameter", $_ )
                        }
                    }
                }

                $xmlWriter.WriteEndElement() # close SsisPackage
            }
            "PowerShell" {
                $xmlWriter.WriteStartElement("PsScript")

                $jobDirectoryPath = "$( ( Get-Item $Path ).Directory.FullName )/$( $Job.Name )"
                New-Item -Path $jobDirectoryPath -ItemType Directory -Force | Out-Null
                $scriptName = "$( $step.Name -replace "[^a-zA-Z0-9 ]", '' ).ps1"
                $scriptPath = "$jobDirectoryPath/$scriptName"
                $step.PsScript | Out-File -FilePath $scriptPath

                $xmlWriter.WriteAttributeString("Path", "./$( $Job.Name )/$scriptName" )
                $xmlWriter.WriteAttributeString("Proxy", $step.Proxy)

                $xmlWriter.WriteEndElement() # close PsScript
            }
            "CmdExec" {
                $xmlWriter.WriteStartElement("PsScript")

                $jobDirectoryPath = "$( ( Get-Item $Path ).Directory.FullName )/$( $Job.Name )"
                New-Item -Path $jobDirectoryPath -ItemType Directory -Force | Out-Null
                $scriptName = "$( $step.Name -replace "[^a-zA-Z0-9 ]", '' ).ps1"
                $scriptPath = "$jobDirectoryPath/$scriptName"
                $step.BatchScript | Out-File -FilePath $scriptPath

                $xmlWriter.WriteAttributeString("Path", "./$( $Job.Name )/$scriptName" )
                $xmlWriter.WriteAttributeString("Proxy", $step.Proxy)

                $xmlWriter.WriteEndElement() # close PsScript
            }
            default { throw "Command for Subsystem '$( $step.Subsystem )' is not implemented" }
        }

        Write-Verbose "Exported $( $step.Id ): '$( $step.Name )'."

        $xmlWriter.WriteEndElement() # close Step
    }
    $xmlWriter.WriteEndElement() # close Steps
#endregion
#region Schedules
    $xmlWriter.WriteStartElement("Schedules")
    foreach ( $schedule in $Job.Schedules ) {
        $xmlWriter.WriteStartElement("Schedule")
        $xmlWriter.WriteAttributeString("Name", $schedule.Name)

        $xmlWriter.WriteStartElement($schedule.Type.Replace(' ', ''))
        $xmlWriter.WriteAttributeString("Interval", $schedule.Interval)
        if ( $schedule.StartDate ) {
            $xmlWriter.WriteAttributeString("StartDate", $schedule.StartDate.ToString("yyyy/MM/dd"))
        }
        if ( $schedule.RelativeInterval ) {
            $xmlWriter.WriteAttributeString("RelativeInterval", $schedule.RelativeInterval)
        }
        if ( $schedule.RecurranceFactor ) {
            $xmlWriter.WriteAttributeString("RecurranceFactor", $schedule.RecurranceFactor)
        }

        $xmlWriter.WriteStartElement($schedule.SubdayType)
        $xmlWriter.WriteAttributeString("Interval", $schedule.SubdayInterval)
        if ( $schedule.StartTime ) {
            $xmlWriter.WriteAttributeString("StartTime", $schedule.StartTime -f "mm:hh:ss")
        }
        $xmlWriter.WriteEndElement() # close SubdayType

        $xmlWriter.WriteEndElement() # close Type

        $xmlWriter.WriteEndElement() # close Schedule
    }
    $xmlWriter.WriteEndElement() # close Schedules
#endregion
    $xmlWriter.WriteEndElement()
    $xmlWriter.WriteEndDocument()
    $xmlWriter.Flush()
    $xmlWriter.Close()

    Write-ToLogfile "Export job done."
}