function Import-SqlAgentJob
{
    [CmdletBinding()]
    param(
        [Parameter(ParameterSetName="Database", Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(ParameterSetName="Database", Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Name,

        [Parameter(ParameterSetName="XML", Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Path,

        [Parameter(ParameterSetName="XML", Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [hashtable] $DeploymentParameter
    )

    Write-ToLogfile "Import Job '$Name$Path'."

    $notifyCodes = @{
        0 = 'Never'
        1 = 'On success'
        2 = 'On failure'
        3 = 'Always'
    }

    $jobProperty = @{}

    switch ($PSCmdlet.ParameterSetName) {
        "Database" {
            Write-Verbose "Export job steps for '$Name' from '$ServerInstance'."

            # Name
            [System.Data.DataTable] $jobData = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "msdb" -SqlCommand @"
SELECT
    [Name] = j.name,
    [JobServer] = ISNULL(s.server_id, -1),
    [Catagory] = c.name,
    [NotificationLevel] = j.notify_level_email,
    [OperatorName] = o.name
FROM sysjobs j
LEFT JOIN sysjobservers s ON s.job_id = j.job_id
LEFT JOIN syscategories c ON c.category_id = j.category_id
LEFT JOIN sysoperators o ON o.id = j.notify_email_operator_id
WHERE j.name = '$Name'
"@
            if ( $jobData.Rows.Count -gt 0 )
            {
                $jobProperty.Name = $jobData[0].Name
                $jobProperty.JobServer = [int] $jobData[0].JobServer
                $jobProperty.Category = $jobData[0].Catagory
                $jobProperty.NotificationLevelCode = $jobData[0].NotificationLevel
                $jobProperty.NotificationLevel = $notifyCodes[$jobProperty.NotificationLevelCode]
                $jobProperty.OperatorName = $jobData[0].OperatorName
            }

            # Steps
            [System.Data.DataTable] $jobStepData = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "msdb" -SqlCommand @"
SELECT
    Id = s.step_id,
    Name = s.step_name,
    SuccessAction = s.on_success_action,
    SuccessStep = ss.step_name,
    FailureAction = s.on_fail_action,
    FailureStep = fs.step_name,
    RetryAttempts = s.retry_attempts,
    RetryInterval = s.retry_interval,
    Subsystem = s.subsystem,
    Command = s.command,
    DatabaseName = s.database_name,
    Proxy = p.description
FROM sysjobs j
JOIN sysjobsteps s
ON s.job_id = j.job_id
LEFT JOIN sysproxies p
ON p.proxy_id = s.proxy_id
LEFT JOIN sysjobsteps ss
ON ss.job_id = j.job_id AND ss.step_id = s.on_success_step_id AND s.on_success_action = 4
LEFT JOIN sysjobsteps fs
ON fs.job_id = j.job_id AND fs.step_id = s.on_fail_step_id AND s.on_fail_action = 4
WHERE j.name = '$Name'
ORDER BY s.step_id
"@
            $steps = @(
                $jobStepData |
                Convert-ToSqlAgentStep -ServerInstance $ServerInstance -From DataRow
            )
            if ( $steps ) {
                $jobProperty.Steps = $steps
            }

            # Schedules
            [System.Data.DataTable] $jobScheduleData = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "msdb" -SqlCommand @"
SELECT
    Name = s.name,
    Type = s.freq_type,
    Interval = s.freq_interval,
    SubdayType = s.freq_subday_type,
    SubdayInterval = s.freq_subday_interval,
    RelativeInterval = s.freq_relative_interval,
    RecurrenceFactor = s.freq_recurrence_factor,
    StartDate = s.active_start_date,
    StartTime = s.active_start_time
FROM sysschedules s
WHERE EXISTS (
        SELECT 1
        FROM sysjobs m
        JOIN sysjobschedules j ON j.schedule_id = s.schedule_id
        WHERE 1 = 1
            AND m.job_id = j.job_id
            AND m.name = '$Name'
    )
"@
            $schedules = $(
                $jobScheduleData |
                Convert-ToSqlAgentSchedule -From DataRow
            )

            if ( $schedules ) {
                $jobProperty.Schedules = $schedules
            }
        }

        "XML" {
            Write-Verbose "Export job steps from '$Path'."
            [xml] $definition = Get-Content $Path

            # Name
            $jobProperty.Name = ( Get-Item $Path ).BaseName

            Select-Xml -Xml $definition -XPath '/Job' |
            ForEach-Object {
                $jobProperty.Category = $_.Node.Attributes['Category'].value

                $jobProperty.NotificationLevel = $_.Node.Attributes['NotificationLevel'].value |
                Set-ParameterValues -Parameter $DeploymentParameter

                if ( -not $jobProperty.NotificationLevel ) {
                    $jobProperty.NotificationLevel = 'Never'
                }

                $jobProperty.NotificationLevelCode = $notifyCodes.GetEnumerator() |
                Where-Object { $_.Value -eq $jobProperty.NotificationLevel } |
                ForEach-Object { $_.Key } |
                Select-Object -First 1
                Write-ToLogfile "Step NotificationLevelCode is '$( $property.NotificationLevelCode )'."

                $jobProperty.OperatorName = $_.Node.Attributes['OperatorName'].value |
                Set-ParameterValues -Parameter $DeploymentParameter
            }

            if ( -not $jobProperty.Category ) {
                $jobProperty.Category = 'DI_IRM'
            }

            if ( -not $jobProperty.NotificationLevel ) {
                $jobProperty.NotificationLevel = 'Never'
            }

            # Steps
            $steps = @(
                Select-Xml -Xml $definition -XPath '//Step' |
                Convert-ToSqlAgentStep -From "XML" -DeploymentParameter $DeploymentParameter
            )
            if ( $steps ) {
                for ($stepId = 1; $stepId -le $steps.Length; $stepId++)
                {
                    $steps[$stepId - 1] | Add-Member -NotePropertyName 'Id' -NotePropertyValue $stepId
                }
                $jobProperty.Steps = $steps
            }

            # Schedules
            $schedules = @(
                Select-Xml -Xml $definition -XPath '//Schedule' |
                Convert-ToSqlAgentSchedule -From "XML" -DeploymentParameter $DeploymentParameter
            )
            if ( $schedules ) {
                $jobProperty.Schedules = $schedules
            }
        }
    }

    $job = New-Object -Type PsObject -Property $jobProperty

    #region Consistency Check
    foreach ( $step in $job.Steps ) {
        $job.Steps |
        Where-Object { $_.Name -eq $step.Name -and $_.Id -ne $step.Id } |
        ForEach-Object {
            throw "Step name '$( $step.Name )' is not unique. It is used for step $( $step.Id ) and step $( $_.Id )"
        }
    }
    #endregion

    Write-ToLogfile "Import Job '$Name$Path' done."

    Write-Output $job
}
