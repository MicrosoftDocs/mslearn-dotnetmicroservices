function Invoke-JobDeployment {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory=$true )]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Name,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [hashtable] $DeploymentParameter
    )

    Write-ToLogfile "Import desired job definition from '$Path'."
    $desiredJob = Import-SqlAgentJob -Path $Path -DeploymentParameter $DeploymentParameter
    Export-SqlAgentJob -Job $desiredJob -Path ( Join-Path ( Get-Location ) ".\Desired.$Name.log" )

    # get current job
    Write-ToLogfile "Import current job definition from '$ServerInstance'."
    $currentJob = Import-SqlAgentJob -ServerInstance $ServerInstance -Name $Name
    Export-SqlAgentJob -Job $currentJob -Path ( Join-Path ( Get-Location ) ".\Current.$Name.log" )

    # diff jobs
    $deploymentPrios = @(
        'NewJob'
        'JobServer'
        'Category'
        'ObsoleteStep'
        'NewStep'
        'SuccessStep'
        'SuccessAction'
        'FailureStep'
        'FailureAction'
        'RetryAttempts'
        'RetryInterval'
        'Subsystem'
        'SqlScript'
        'DatabaseName'
        'SsisPackage'
        'PsScript'
        'Proxy'
        'ObsoleteSchedule'
        'NewSchedule'
        'ScheduleType'
        'Interval'
        'SubdayType'
        'SubdayInterval'
        'StartTime'
        'NotificationLevel'
        'OperatorName'
    )

    Write-ToLogfile "Compare current and desired job definitions."
    $changes = Compare-SqlAgentJobs -Desired $desiredJob -Current $currentJob
    $changes | ConvertTo-Json | Out-File ".\Changes.$Name.log"

    #region Order changes
    Write-ToLogfile "Order differences for the deployment."
    $tasks = $changes | ForEach-Object {
        if ( -not $deploymentPrios.Contains( $_.Type ) ) {
            throw "Differential deployment for '$( $_.Type )' is not prioritized."
        }

        [int] $typeOrder = $deploymentPrios.IndexOf( $_.Type )
        $_ | Add-Member TypeOrder $typeOrder

        [int] $stepOrder = if ( $_.Step ) {
            if ( $_.Type -eq 'ObsoleteStep' ) {
                Write-Output ( 999 - $_.Step.Id )
            }
            else {
                Write-Output $_.Step.Id
            }
        } else {
            Write-Output  999
        }
        $_ | Add-Member StepOrder $stepOrder

        $_ | Write-Output
    } | Sort-Object TypeOrder, StepOrder
    $tasks | ConvertTo-Json | Out-File ".\Tasks.$Name.log"
    #endregion

    Write-ToLogfile "Deploy the necessary changes."
    foreach ( $change in $tasks )
    {
        Write-ToLogfile "Start deployment of diff '$( $change.Type )'."

        switch ( $change.Type ) {
            #region Job

            NewJob {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_add_job @job_name='$Name'" `
                    -ExpectedReturn 0
            }

            JobServer {
                $rawHostname = Get-RawHostname $ServerInstance -HostOnly
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_add_jobserver @job_name='$Name', @server_name=N'$rawHostname'" `
                    -ExpectedReturn 0
            }

            Category {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_job @job_name='$Name', @category_name =N'$( $change.Job.Category )'" `
                    -ExpectedReturn 0
            }

            NotificationLevel {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_job @job_name='$Name', @notify_level_email =N'$( $change.Job.NotificationLevelCode )'" `
                    -ExpectedReturn 0
            }

            OperatorName {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_job @job_name='$Name', @notify_level_email =N'$( $change.Job.NotificationLevelCode )', @notify_email_operator_name =N'$( $change.Job.OperatorName )'" `
                    -ExpectedReturn 0
            }

            #endregion
            #region Steps

            ObsoleteStep {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_delete_jobstep @job_name='$Name', @step_id=$stepId" `
                    -ExpectedReturn 0
            }
            NewStep {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_add_jobstep @job_name='$Name', @step_id=$( $change.Step.Id ), @step_name=N'$( $change.Step.Name )'" `
                    -ExpectedReturn 0
            }
            SuccessAction {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @on_success_action =$( [int] $change.Step.SuccessActionCode )" `
                    -ExpectedReturn 0
            }
            SuccessStep {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                [int] $successStepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.Step.SuccessStep
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @on_success_step_id=$successStepId" `
                    -ExpectedReturn 0
            }
            FailureAction {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @on_fail_action=$( [int] $change.Step.FailureActionCode )" `
                    -ExpectedReturn 0
            }
            FailureStep {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                [int] $failureStepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.Step.FailureStep
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @on_fail_step_id=$failureStepId" `
                    -ExpectedReturn 0
            }
            RetryAttempts {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @retry_attempts=$( [int] $change.Step.RetryAttempts )" `
                    -ExpectedReturn 0
            }
            RetryInterval {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @retry_interval=$( [int] $change.Step.RetryInterval )" `
                    -ExpectedReturn 0
            }
            Subsystem {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @subsystem=$( $change.Step.Subsystem )" `
                    -ExpectedReturn 0
            }
            SqlScript {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @command=N'$( $change.Step.SqlScript.Replace("'", "''") )'" `
                    -ExpectedReturn 0
            }
            DatabaseName {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @database_name=$( $change.Step.DatabaseName )" `
                    -ExpectedReturn 0
            }
            SsisPackage {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @command=N'$( $change.Step.SsisCommand )'" `
                    -ExpectedReturn 0
            }
            PsScript {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @command=N'$( $change.Step.PsScript.Replace("'", "''") )'" `
                    -ExpectedReturn 0
            }
            Proxy {
                [int] $stepId = Get-SqlAgentStepId -ServerInstance $ServerInstance -JobName $Name -StepName $change.StepName
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_jobstep @job_name='$Name', @step_id=$stepId, @proxy_name=N'$( $change.Step.Proxy )'" `
                    -ExpectedReturn 0
            }

            #endregion
            #region Schedules

            ObsoleteSchedule {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_detach_schedule @job_name='$Name', @schedule_name=N'$( $change.ScheduleName )', @delete_unused_schedule=1" `
                    -ExpectedReturn 0
            }
            NewSchedule {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_add_jobschedule @job_name='$Name', @name=N'$( $change.Schedule.Name )', @freq_type=$( [int] $change.Schedule.TypeCode ), @freq_interval=$( [int] $change.Schedule.Interval ), @freq_subday_type=$( [int] $change.Schedule.SubdayTypeCode ), @freq_subday_interval=$( [int] $change.Schedule.SubdayInterval )" `
                    -ExpectedReturn 0
            }
            ScheduleType {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_schedule @name=N'$( $change.Schedule.Name )', @freq_type=$( [int] $change.Schedule.TypeCode )" `
                    -ExpectedReturn 0
            }
            StartTime {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_schedule @name=N'$( $change.Schedule.Name )', @active_start_time=$( [int] $change.Schedule.StartTime.ToString().Replace(':', '') )" `
                    -ExpectedReturn 0
            }
            Interval {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_schedule @name=N'$( $change.Schedule.Name )', @freq_interval =$( [int] $change.Schedule.Interval )" `
                    -ExpectedReturn 0
            }
            SubdayType {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_schedule @name=N'$( $change.Schedule.Name )', @freq_subday_type=$( [int] $change.Schedule.SubdayTypeCode )" `
                    -ExpectedReturn 0
            }
            SubdayInterval {
                Invoke-SqlNonQuery -ServerInstance $ServerInstance -Database 'msdb' `
                    -SqlCommand "sp_update_schedule @name=N'$( $change.Schedule.Name )', @freq_subday_interval=$( [int] $change.Schedule.SubdayInterval )" `
                    -ExpectedReturn 0
            }

            #endregion
            default {
                throw "Differential deployment for '$_' changes are not implemented."
            }
        }
    }
    # create alter script
    # execute depoyment
}
