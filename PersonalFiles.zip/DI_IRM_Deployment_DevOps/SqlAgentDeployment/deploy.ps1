[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "ProjectName required" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "Environment required" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_sql.log"
)

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Import-Module ( Join-Path $PSScriptRoot 'SqlAgentDeployment.psd1' )

Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region Load parameter from ARA.xml

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

try {
    $scriptCommands = Get-AraScriptCommand `
        -AraXmlPath $AraXmlPath `
        -ProjectName $ProjectName `
        -Environment $Environment `
        -ScriptFolderName $ScriptFolderName `
        -ModuleName $ModuleName
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Prepare:Load ARA: $( $_.Exception )"
    exit 1
}

#endregion
#region Main Routine

try
{
    $scriptCommands |
    ForEach-Object {
        Select-Xml -Xml $_ -XPath ".//job" -PipelineVariable jobXml |
            ForEach-Object {

                [string] $jobName = $jobXml.Node.Attributes['name'].Value
                [string] $serverInstance = $jobXml.Node.Attributes['serverInstance'].Value

                Write-ToLogfile "Start deployment of SqlAgent '$jobName' to '$serverInstance'."

                $jobParameter = @{}
                Select-Xml -Xml $jobXml.Node -XPath ".//parameter" -PipelineVariable jobParameterXml |
                ForEach-Object {
                    $jobParameter[$jobParameterXml.Node.Attributes['key'].Value] = $jobParameterXml.Node.Attributes['value'].Value
                }

                Invoke-JobDeployment -Path "$ScriptFolderPath\..\..\$jobName.job.xml" -Name $jobName -ServerInstance $serverInstance -DeploymentParameter $jobParameter
            }
    }
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw
}

Write-ToLogFile "Execute: End"
#endregion

#endregion
