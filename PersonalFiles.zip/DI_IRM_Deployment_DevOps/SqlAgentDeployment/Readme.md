# SqlAgentDeployment

## Configuration

```XML
<scriptcommand scriptfolder="SqlAgentDeployment" projectName="...">
    <job name="..." serverInstance="...;">
        <parameter key="Path_Scripts" value="..."/>
        <parameter key="Proxy" value="..."/>
        <parameter key="ENV_Hostname_ETL_Server" value="...">
    </job>
</scriptcommand>
```

The `projectName` attribute specifies the folder name that contains the job definition.

Each job has one corresponding XML node that has the following nodes:
The `name` attribute specifies the name of the SQL Server Agent Job.
The `serverInstance` attribute specifies the name of the server that hosts the SQL Server Agent.
Parameters of a job definition can be configured as own sub nodes of a job.

## Definition

A job is defined as a XML file with the schema `$JOBNAME.job.xml`.

```XML
<?xml version="1.0"?>
<Job NotificationLevel="On failure" OperatorName="$(Operator)" >
    <Steps>
        <Step Name="..." Subsystem="TSQL">
            <SqlScript
                Database="..."
                Path="..."
            />
        </Step>
        <Step Name="..." Subsystem="PowerShell">
            <PsScript
                Path="..."
                Proxy="$(Proxy)"
            />
        </Step>
        <Step Name="..." SuccessAction="Success" Subsystem="SSIS">
            <SsisPackage
                CatalogServer="$(ENV_Hostname_ETL_Server)"
                CatalogPath="\SSISDB\DI_IRM\..dtsx"
                CatalogEnvironment=".."
                Proxy="$(Proxy)"
                Architecture="X86"
            />
        </Step>
    </Steps>
    <Schedules>
        <Schedule Name="...">
            <Days Interval="1">
                <Once Interval="0" StartTime="02:30:00" />
            </Days>
        </Schedule>
    </Schedules>
</Job>
```

Each step is a own XML node. The steps are executed in ascending order.
Each step uses a subsystem like `TSQL`, `PowerShell` or `SSIS`.
All step types support attributes like `SuccessAction`, `SuccessStep` (name), `FailureAction`, `FailureStep` (name), `RetryAttempts` and `RetryInterval`.
Skript steps like TSQL or PowerShell use scripts from a subfolder. According to the convention, the subfolder has the name of the job and the script has the name of the step and the extension `.sql` or `.ps1`.
The scripts an the attributes `Proxy`, `CatalogServer`, `CatalogPath` and `CatalogEnvironment` support variables with the syntay `$(VARIABLE)`.

Each schedule has a XML node with two nestes subnodes:

1. `Once`, `Days`, `Weeks` or `Month` with the optional attributes `Interval` and `StartDate`.
2. `Once`, `Seconds`, `Minutes` or `Hours` with the optional attributes `Interval` and `StartTime`.

## Build

The build is managed by the BuildHelper module. It creates a zip file containing the deployment script and SqlAgent modules.

## Deployment

See the documentation of the `Invoke-SqlAgentDeployment` function.
