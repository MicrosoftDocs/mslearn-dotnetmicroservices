﻿using System;
using System.IO;
using System.Xml.Serialization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SSRS_Subscription.ReportingServiceNamespace;

namespace SSRS_Subscription.Test
{


    [TestClass]
    public class SSRS_SubscriptionTest
    {

        #region helper

        internal static string GenerateScheduleXml()
        {
            string StartDateTime = "2015-04-22T19:51:00.000+05:30";
            string weeksInterval = "1";
            string weekDays = "Sunday";
            string scheduleXML = @"<ScheduleDefinition>
                                       <StartDateTime>" + StartDateTime + @"</StartDateTime>
                                       <WeeklyRecurrence>
                                           <WeeksInterval>" + weeksInterval + @"</WeeksInterval>
                                           <DaysOfWeek>
                                               <" + weekDays + @">true</" + weekDays + @">
                                           </DaysOfWeek>
                                       </WeeklyRecurrence>
                                   </ScheduleDefinition>";
            return scheduleXML;
        }

        internal static Definition.DestinationParameterList GenerateDestinationParameterSource(
            string FileShareUser, string FileSharePassword, string FileSharePath)
        {
            return new Definition.DestinationParameterList()
            {
                Items = {
                    new Definition.DestinationParameter() {
                        Name = "PATH",
                        Value = FileSharePath
                    },
                    new Definition.DestinationParameter() {
                        Name = "FILENAME",
                        Reference = "File_Name"
                    },
                    new Definition.DestinationParameter() {
                        Name = "FILEEXTN",
                        Value = "True"
                    },
                    new Definition.DestinationParameter() {
                        Name = "USERNAME",
                        Value = FileShareUser
                    },
                    new Definition.DestinationParameter() {
                        Name = "PASSWORD",
                        Value = FileSharePassword
                    },
                    new Definition.DestinationParameter() {
                        Name = "WRITEMODE",
                        Value = "OverWrite"
                    },
                    new Definition.DestinationParameter() {
                        Name = "RENDER_FORMAT",
                        Value = "EXCELOPENXML"
                    }
                }
            };
        }

        private string GetParameterValue(ParameterValueOrFieldReference[] extensionParameters, string Name)
        {
            foreach (var item in extensionParameters)
            {
                var valueItem = item as ParameterValue;
                if (valueItem != null && valueItem.Name == Name)
                {
                    return valueItem.Value;
                }
            }

            return null;
        }

        #endregion

        private string Hostname = "SQLDEVDIIRM";
        private string AdUser = @"MUNICH\ny36717";
        #region geheim
        private string Password = @"***§";
        #endregion
        private string FileSharePath = @"\\fxx0004\mrdata3\DI_IRM\DEV\Credit_Risk\Export\SSRS_Reports";

        private string SubscriptionXml = @"
<subscription>
    <schedule>
        <ScheduleDefinition>
            <StartDateTime>2000-01-01T12:00:00.000+00:00</StartDateTime>
            <WeeklyRecurrence>
                <WeeksInterval>1</WeeksInterval>
                <DaysOfWeek>
                    <Sunday>true</Sunday>
                </DaysOfWeek>
            </WeeklyRecurrence>
        </ScheduleDefinition>
    </schedule>
    <sqlQuery>
        SELECT Year, Quarter, Run_Type, Run_ID, File_Name, Aggr_Entity
        FROM config.ReportSubscriptionConfiguration
        WHERE Actual = 1 AND ReportName = 'DI_IRM_CreditRisk_Ergo_V2'
        ORDER BY PK_ReportSubscriptionConfiguration
    </sqlQuery>
    <database>DI_IRM_CreditRisk_Datamart</database>
    <reportParameters>
        <parameter><name>DDateYear</name><reference>Year</reference></parameter>
        <parameter><name>DDateQuarter</name><reference>Quarter</reference></parameter>
        <parameter><name>DRunRunType</name><reference>Run_Type</reference></parameter>
        <parameter><name>DRunRunID</name><reference>Run_ID</reference></parameter>
        <parameter><name>DSegmentAGGRENTITY</name><reference>Aggr_Entity</reference></parameter>
        <parameter><name>DSegmentEVRV</name><value>[D Segment].[EV RV].&amp;[EV]</value></parameter>
    </reportParameters>
    <destinationParameters>
        <parameter><name>FILENAME</name><reference>File_Name</reference></parameter>
        <parameter><name>FILEEXTN</name><value>True</value></parameter>
        <parameter><name>WRITEMODE</name><value>OverWrite</value></parameter>
        <parameter><name>RENDER_FORMAT</name><value>EXCELOPENXML</value></parameter>
    </destinationParameters>
</subscription>
";

        [TestMethod]
        public void TestCreateDataDrivenSubscription()
        {

            var configuration = new Configuration.Subscription(
                ReportServerEndpointUrl: "http://" + Hostname + ".cloud.munichre.com/ReportServer/ReportService2010.asmx",
                ReportName: "DI_IRM_CreditRisk_Ergo_V2",
                ReportFolder: @"/DI_IRM_CreditRisk_Reporting/",
                DatasourceServer: Hostname + ".cloud.munichre.com",
                DatasourceUser: AdUser,
                DatasourcePassword: Password,
                FileShareUser: AdUser,
                FileSharePassword: Password,
                FileSharePath: FileSharePath
            );

            var reportServer = Program.GetReportServer(configuration.ReportServerEndpointUrl);

            var definition = Definition.Subscription.ParseSubscriptionXml(SubscriptionXml);
            definition.ApplyConfiguration(Configuration: configuration);
            definition.AssertIsValid();

            reportServer.CreateDataDrivenSubscription(
                Configuration: configuration,
                Definition: definition
             );
        }

        [TestMethod]
        public void TestParseSubscriptionXml()
        {
            var subscription = Definition.Subscription.ParseSubscriptionXml(SubscriptionXml);

            Assert.AreEqual(4, subscription.DestinationParameters.Items.Count);
            Assert.AreEqual(6, subscription.ReportParameters.Items.Count);
            Assert.AreEqual("SELECT", subscription.SqlQuery.Trim().Substring(0, "SELECT".Length));
            Assert.AreEqual("<ScheduleDefinition>", subscription.ScheduleXml.ToString().Trim().Substring(0, "<ScheduleDefinition>".Length));
        }

        #region data generator

        [TestMethod]
        public void TestGenerateScheduleXml()
        {
            Console.WriteLine(GenerateScheduleXml());
        }

        [TestMethod]
        public void TestGenerateExtensionParameterXml()
        {
            var source = GenerateDestinationParameterSource(
                FileShareUser: AdUser,
                FileSharePassword: Password,
                FileSharePath: FileSharePath
            );

            // Convert to XML
            string sourceXml;
            {
                XmlSerializer xmlSerializer = new XmlSerializer(source.GetType());
                using (StringWriter textWriter = new StringWriter())
                {
                    xmlSerializer.Serialize(textWriter, source);
                    sourceXml = textWriter.ToString();
                }
            }

            // Output XML
            Console.WriteLine(sourceXml);
        }

        #endregion
    }
}
