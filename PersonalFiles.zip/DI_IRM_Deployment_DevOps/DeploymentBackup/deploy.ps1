﻿<#
    .SYNOPSIS
    Powershell Script Deployment Backup deploy.ps1

    .NOTES
    Date:       2020-12-17
    Author:     Steffen Kampmann, Andreas Kelm
    Version:    1.3

    .DESCRIPTION
    This script creates backups from relational databases, cubes and scripts.

    .PARAMETER ProjectName
    Specifies the name of the project that should be backed up.

    .PARAMETER Environment
    Specifies the name of the environment that should be backed up.
#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "backup.log",

    [ValidateScript({Test-Path $_})]
    [string] $BuildDropLocation = '\\fxx0004\bdl\DI_IRM\',

    [ValidateNotNullOrEmpty()]
    [int] $BuildNumber = ( Get-Item $AraXmlPath ).Directory.Name.Split('-')[1]
)

Add-Type -Assembly System.IO.Compression.Filesystem

Import-Module $DeploymentHelperPath
Import-Module ( Join-Path $PSScriptRoot 'DeploymentBackup.psd1' )

Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region Backup

try {
    $scriptCommands = Get-AraScriptCommand `
        -AraXmlPath $AraXmlPath `
        -ProjectName $ProjectName `
        -ModuleName $ModuleName `
        -Environment $Environment `
        -ScriptFolderName $ScriptFolderName
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Prepare:Load ARA: $( $_.Exception )"
    throw
}

#endregion

#region Execute

Write-ToLogFile "Execute: Start"
try {
    foreach ( $scriptCommand in $scriptCommands ) {
        [string] $SQL_BackupFlag = $scriptCommand.sqlBackupFlag
        Write-ToLogFile "BuildPath:'$RepositoryPath', Environment:'$Environment', BackupFlag:'$SQL_BackupFlag'" -Region $region

        if ($SQL_BackupFlag -eq 'N') {
            Write-ToLogfile 'The SQL_BackupFlag is set N it means no backup for this environment' -Region $region
        } else {
            Write-ToLogfile 'The SQL_BackupFlag is set Y or undefined, SQL Backup will initiatad.' -Region $region

            $region = 'Backup'
            #[string] $RepositoryPath = ( Get-ChildItem $BuildDropLocation -Recurse | Where-Object { $_.Name -eq $BuildNumber } ).FullName
            [string] $RepositoryPath = $BuildDropLocation
            [string] $BackupName = ( Get-Date ).ToString("yyyyMMdd-HHmm")
            Write-ToLogFile "BuildPath:'$RepositoryPath', Environment:'$Environment', BackupName:'$BackupName'" -Region $region

            $region = 'Backup', 'SqlModule'
            Write-ToLogfile 'Start' -Region $region
            Backup-SqlModule -RepositoryPath $RepositoryPath -BackupName $BackupName -AraXmlPath $AraXmlPath -Environment $Environment
            Write-ToLogfile 'Stop' -Region $region

            $region = 'Backup', 'OlapModule'
            Write-ToLogfile 'Start' -Region $region
            Backup-OlapModule -RepositoryPath $RepositoryPath -BackupName $BackupName -AraXmlPath $AraXmlPath -Environment $Environment
            Write-ToLogfile 'Stop' -Region $region

            $region = 'Backup', 'FileModule'
            Write-ToLogfile 'Start' -Region $region
            Backup-FileModule -BackupName $BackupName -AraXmlPath $AraXmlPath -Environment $Environment
            Write-ToLogfile 'Stop' -Region $region
        }
    }
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw
}

Write-ToLogFile "Execute: End"
#endregion
