function Backup-FileModule
{
    <#

    .SYNOPSIS
    Creates a backup of the FileModules based on deployment artifacts.

    .PARAMETER RepositoryPath
    The path to the repository that contains the deployment artifacts.

    .PARAMETER AraXmlPath
    The path to the ARA.xml that contains the deployment configuration.

    .PARAMETER Environment
    The name of the environment that should be backed up.

    .PARAMETER BackupName
    The name of the backup. E.g. the Release name, where the system is backed up before deployment.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $BackupName,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string] $AraXmlPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Environment
    )

    Write-ToLogfile 'Get module names.'
    $moduleNames = Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@type='ssis_filecopy']" | ForEach-Object {
        $_.Node.Attributes['name'].Value
    }

    foreach ( $moduleName in $moduleNames ) {

        #region Prepare
        Write-ToLogfile "Prepare backup of [$moduleName]."

        Write-ToLogFile 'Get scriptPath'
        try {
            [string] $scriptPath = ( Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@name='$moduleName' and @type='ssis_filecopy']//deploymentSettings//add[@key='TargetLocation' and @env='$Environment']" ).Node.Attributes['value'].value
            if ( -not $scriptPath ) {
                throw
            }
        }
        catch {
            throw "TargetLocation not found for module '$moduleName' in environment '$Environment'."
        }

        Write-ToLogFile 'Get serverInstance'
        try {
            [string] $serverInstance = ( Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@name='$moduleName' and @type='ssis_filecopy']//deploymentSettings//set[@key='TargetServer' and @env='$Environment']" ).Node.Attributes['value'].value
            if ( -not $serverInstance ) {
                throw
            }
        }
        catch {
            throw "TargetServer not found for module '$moduleName' in environment '$Environment'."
        }

        #endregion
        #region Execute
        Write-ToLogFile "Execute directory backups"

        Backup-Directory -ServerInstance $serverInstance -DirectoryPath $scriptPath -BackupName $BackupName

        #endregion
    }
}