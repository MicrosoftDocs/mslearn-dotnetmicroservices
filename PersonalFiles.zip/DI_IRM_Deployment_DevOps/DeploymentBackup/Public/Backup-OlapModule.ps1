function Backup-OlapModule
{
    <#

    .SYNOPSIS
    Creates a backup of the OlapModules based on deployment artifacts.

    .PARAMETER RepositoryPath
    The path to the repository that contains the deployment artifacts.

    .PARAMETER AraXmlPath
    The path to the ARA.xml that contains the deployment configuration.

    .PARAMETER Environment
    The name of the environment that should be backed up.

    .PARAMETER BackupName
    The name of the backup. E.g. the Release name, where the system is backed up before deployment.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string] $RepositoryPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $BackupName,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string] $AraXmlPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Environment
    )

    #region Prepare
    Write-ToLogFile "Prepare."

    Write-ToLogFile "Get databases to back up."
    $databases = Get-ChildItem $RepositoryPath -Filter '*.zip' | ForEach-Object {
        Write-ToLogFile "Check archive:'$_'"
        [IO.Compression.ZipFile]::OpenRead($_.FullName).Entries
    } | Where-Object Name -like '*.asdatabase' | ForEach-Object {
        Write-ToLogFile "Add database:'$_'"
        $_.Name.Replace('.asdatabase', '')
    }

    Write-ToLogFile "Get server instances to back up."
    $serverInstances = @(
        # Old implementation
        Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@type='ssas']//add[@key='TargetServer' and @env='$Environment' and not( @type='dummy' )]" | ForEach-Object {
            $serverInstance = $_.Node.Attributes['value'].value
            Write-ToLogFile "Add server: '$serverInstance'"
            $serverInstance | Write-Output
        }
    ) + @(
        # New implementation
        Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@type='ssdt_dacpac_scripts']//environment[@name='$Environment']//scriptcommand[@scriptfolder='CubeDeployment']" | ForEach-Object {
            $serverInstance = $_.Node.Attributes['serverInstance'].value
            Write-ToLogFile "Add server: '$serverInstance'"
            $serverInstance | Write-Output
        }
    )

    #endregion
    #region Execute
    Write-ToLogFile "Execute olap backups"

    if ( -not $databases ) {
        Write-ToLogFile "Did not find any cube databases in the module definitions." -Level 'WARNING'
    } elseif ( -not $serverInstances ) {
        throw "Did not find any server instances in the module definitions."
    } else {
        foreach ( $serverInstance in $serverInstances ) {
            foreach ( $database in $databases ) {
                Backup-OlapDatabase `
                    -ServerInstance $serverInstance `
                    -DatabaseName $database `
                    -BackupName $BackupName
            }
        }
    }

    #endregio
    #endregion
}