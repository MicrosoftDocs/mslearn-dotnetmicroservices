function Backup-SqlModule
{
    <#

    .SYNOPSIS
    Creates a backup of the SqlModules based on deployment artifacts.

    .PARAMETER RepositoryPath
    The path to the repository that contains the deployment artifacts.

    .PARAMETER AraXmlPath
    The path to the ARA.xml that contains the deployment configuration.

    .PARAMETER Environment
    The name of the environment that should be backed up.

    .PARAMETER BackupName
    The name of the backup. E.g. the Release name, where the system is backed up before deployment.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $RepositoryPath,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $AraXmlPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Environment,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $BackupName
    )

    #region Prepare
    Write-ToLogFile "Prepare."

    Write-ToLogFile "Get databases to back up."
    $databases = Get-ChildItem $RepositoryPath -Filter '*.zip' | ForEach-Object {
        Write-ToLogFile "Check archive:'$_'"
        [IO.Compression.ZipFile]::OpenRead($_.FullName).Entries
    } | Where-Object Name -like '*.dacpac' | ForEach-Object {
        Write-ToLogFile "Add database:'$_'"
        $_.Name.Replace('.dacpac', '')
    } | Select -Unique

    Write-ToLogFile "Get server instances of environment '$Environment' to back up."
    $serverInstances = (@(
        ) + @(
            Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@type='ssdt_dacpac']//add[@key='TargetServer' and @env='$Environment' and not( @type='dummy' )]" | ForEach-Object {
                Write-Output $_.Node.Attributes['value'].value
            }
        ) + @(
            Select-XmlWithEntities -Path $AraXmlPath -XPath "//module[@type='ssdt_dacpac_scripts']//environment[@name='$Environment']//scriptcommand[@scriptfolder='DatabaseDeployment']" | ForEach-Object {
                Write-Output $_.Node.Attributes['serverInstance'].value
            }
        )) | Select -Unique

    $serverInstances | ForEach-Object {
        Write-ToLogFile "Add instance:'$_'"
    }

    #endregion
    #region Execute
    Write-ToLogFile "Execute sql backups"

    if ( -not $databases ) {
        throw "Did not find any relational databases in the module definitions."
    } elseif ( -not $serverInstances ) {
        throw "Did not find any server instances in the module definitions."
    } else {
        foreach ( $serverInstance in $serverInstances ) {
            foreach ( $database in $databases ) {
                Backup-SqlDatabase `
                    -ServerInstance $serverInstance `
                    -DatabaseName $database `
                    -BackupName $BackupName
            }
        }
    }

    #endregion
}