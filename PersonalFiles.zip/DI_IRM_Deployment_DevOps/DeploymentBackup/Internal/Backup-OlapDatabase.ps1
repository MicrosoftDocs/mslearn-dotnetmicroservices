function Backup-OlapDatabase
{
    <#

    .SYNOPSIS
    Creates a backup of a OLAP database.

    .PARAMETER ServerInstance
    The name of the server that contains the database

    .PARAMETER DatabaseName
    The name of the database, that sould be backed up.

    .PARAMETER BackupName
    The name of the backup. E.g. the Release name, where the system is backed up before deployment.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $BackupName
    )

    [Reflection.Assembly]::LoadWithPartialName('Microsoft.AnalysisServices')

    $database = Get-ChildItem SQLSERVER:\SQLAS\$ServerInstance\Default\Databases\ | Where-Object { $_.Name -eq $DatabaseName }
    if ( -not $database ) {
        Write-ToLogfile "Database [$ServerInstance].[$DatabaseName] does not exist." -Level 'WARNING'
        Write-ToLogfile "This may be an initial deployment."
        Write-ToLogfile "Backup skipped."
    } else {
        $server = New-Object Microsoft.AnalysisServices.Server
        $server.connect($ServerInstance)
        $backupDirectory = $server.ServerProperties['BackupDir'].Value
        $backupFile = "$backupDirectory\$BackupName-$DatabaseName.abf"

        #region Backup
        Write-ToLogfile "Start backup of [$ServerInstance].[$DatabaseName] to '$backupFile'"

        Backup-ASDatabase `
            -BackupFile $backupFile `
            -Name $DatabaseName `
            -ApplyCompression `
            -Server $ServerInstance
        #endregion

        #region Check
        Write-ToLogfile "Check backup of [$ServerInstance].[$DatabaseName] to '$backupFile'"
        $fileIsCreated = Invoke-Command `
            -ComputerName ( Get-RawHostname $ServerInstance ) `
            -ScriptBlock {
                [CmdletBinding()]
                param(
                    [string] $BackupFile
                )
                Test-Path $BackupFile
            } -ArgumentList $backupFile

        if ( -not $fileIsCreated ) {
            throw "Backup failed."
        }
        #endregion

        Write-ToLogfile "Database [$ServerInstance].[$DatabaseName] saved to '$backupFile'."
    }
}
