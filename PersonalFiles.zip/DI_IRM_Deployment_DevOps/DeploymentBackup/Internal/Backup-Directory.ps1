function Backup-Directory
{
    <#

    .SYNOPSIS
    Creates a backup of a directory.

    .PARAMETER ServerInstance
    The name of the server that contains the database

    .PARAMETER DirectoryPath
    The local path to the directory, that sould be backed up.

    .PARAMETER BackupName
    The name of the backup. E.g. the Release name, where the system is backed up before deployment.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DirectoryPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $BackupName
    )

    Write-ToLogFile 'Create remote session'
    $remoteSession = New-PSSession -ComputerName ( Get-RawHostname $ServerInstance )

    Write-ToLogFile 'Invoke backup'
    $output = (
        Invoke-Command -ComputerName ( Get-RawHostname $ServerInstance ) -ScriptBlock {

        [CmdletBinding()]
        param(
            [ValidateScript({Test-Path $_})]
            [string]
            $DirectoryPath,

            [ValidateNotNullOrEmpty()]
            [string]
            $BackupName
        )

        if ( -not ( Test-Path $DirectoryPath )) {
            Write-Output "No scripts in '$DirectoryPath' to backup."
        } else {

            $projectName = ( Get-Item $DirectoryPath ).Name

            if ( -not $projectName )
            {
                throw "'$DirectoryPath' is not a directory."
            }

            $backupDirectory = ( Get-Item $DirectoryPath ).Parent.FullName + "\backup"
            $backupFile = "$backupDirectory\$BackupName-$projectName.zip"

            if ( -not ( Test-Path $backupDirectory ) )
            {
                Write-Output "Create backup path '$backupDirectory'."
                New-Item -ItemType Directory -Path $backupDirectory | Out-Null
            }

            Write-Output "Start backup of [$projectName] to '$backupFile'"
            Add-Type -Assembly System.IO.Compression.FileSystem
            [IO.Compression.ZipFile]::CreateFromDirectory($DirectoryPath, $backupFile)
            Write-Output "Scripts directory [$projectName] saved to '$backupFile'."
        }

    } -ArgumentList $DirectoryPath, $BackupName | Out-String )
    Write-ToLogfile $output
}
