function Backup-SqlDatabase
{
    <#

    .SYNOPSIS
    Creates a backup of a SQL database.

    .PARAMETER ServerInstance
    The name of the server that contains the database

    .PARAMETER DatabaseName
    The name of the database, that sould be backed up.

    .PARAMETER BackupName
    The name of the backup. E.g. the Release name, where the system is backed up before deployment.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $BackupName
    )

    Write-ToLogfile "Check database exist [$ServerInstance].[$DatabaseName] "
    
    $database = Get-SqlDatabase -ServerInstance $ServerInstance -Name $DatabaseName
    if ( -not $database ) {
        Write-ToLogfile "Database [$ServerInstance].[$DatabaseName] does not exist." -Level 'WARNING'
        Write-ToLogfile "This may be an initial deployment."
        Write-ToLogfile "Backup skipped."
    } else {
        $backupDirectory = $database.Parent.BackupDirectory
        $backupFile = "$backupDirectory\$BackupName-$DatabaseName.bak"

        #region Backup
        Write-ToLogfile "Start backup of [$ServerInstance].[$DatabaseName] to '$backupFile'"

        SqlServer\Backup-SqlDatabase `
            -ServerInstance $ServerInstance `
            -Database $DatabaseName `
            -CopyOnly `
            -BackupSetName "$DatabaseName-$BackupName" `
            -ExpirationDate ( Get-Date ).AddDays(14) `
            -BackupSetDescription "pre deployment backup" `
            -BackupFile $backupFile | Out-Null
        #endregion

        #region Check
        Write-ToLogfile "Check backup of [$ServerInstance].[$DatabaseName] to '$backupFile'"

        $fileIsCreated = Invoke-Command `
            -ComputerName ( Get-RawHostname $ServerInstance ) `
            -ScriptBlock {
                [CmdletBinding()]
                param(
                    [string] $BackupFile
                )
                Test-Path $BackupFile
            } -ArgumentList $backupFile -ErrorVariable errormessage 2>$null

        if ( -not $fileIsCreated ) {
            throw "Backup failed: $errormessage"
        }
        #endregion

        Write-ToLogfile "Database [$ServerInstance].[$DatabaseName] saved to '$backupFile'."
    }
}