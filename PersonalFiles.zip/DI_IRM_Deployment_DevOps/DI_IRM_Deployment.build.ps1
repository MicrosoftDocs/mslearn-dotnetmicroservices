param (
    $SolutionName = ( ( Get-Item -Path $PSScriptRoot ).Name ),
    $SolutionTitle = ( ( ( Get-Item -Path $PSScriptRoot ).Name -split '_' )[-1] )
)

task BuildWiki {
    Copy-Item $PSScriptRoot/Readme.md "../DI_IRM_Wiki\DI_IRM.wiki/$SolutionTitle.md"
    Get-ChildItem -Path $PSScriptRoot/ -Recurse -Include *.build.ps1 -Exclude "$SolutionName.build.ps1" |
    ForEach-Object {
        Invoke-Build -Task BuildWiki -File $_.FullName
    }
}

task Clean {
    Get-ChildItem -Path $PSScriptRoot/ -Recurse -Include *.build.ps1 -Exclude "$SolutionName.build.ps1" |
    ForEach-Object {
        Invoke-Build -Task Clean -File $_.FullName
    }

    Get-ChildItem -Path $PSScriptRoot/ -Recurse -Include .log # | Remove-Item
}

task Build {
    Get-ChildItem -Path $PSScriptRoot/ -Recurse -Include *.build.ps1 -Exclude "$SolutionName.build.ps1" |
    ForEach-Object {
        Invoke-Build -Task Build -File $_.FullName
    }
}
