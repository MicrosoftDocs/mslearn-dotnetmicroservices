function Invoke-DeploySubscription
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ReportName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ReportFolder,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ReportServerEndpointUrl,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatasourceServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Username,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Password,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $FileShare,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string] $DeploySsrsSubscriptionPath = "SSRS_Subscription.exe"
    )

    Write-ToLogfile "Deploy subscription for $ReportName" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-Path $Path" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-ReportName $ReportName" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-ReportFolder $ReportFolder" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-ReportServerEndpointUrl $ReportServerEndpointUrl" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-DatasourceServerInstance $DatasourceServerInstance" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-Username $Username" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-Password $( $Password.Length )" -Region 'SSRS_Subscription.exe'
    Write-ToLogfile "-FileShare $FileShare" -Region 'SSRS_Subscription.exe'

    $process = Start-Process `
        -FilePath $DeploySsrsSubscriptionPath `
        -ArgumentList $Path, $ReportServerEndpointUrl, $ReportName, $ReportFolder, $DatasourceServerInstance, $Username, $Password, $FileShare `
        -RedirectStandardOutput "$LogfilePath-$ReportName-output.log" `
        -RedirectStandardError "$LogfilePath-$ReportName-error.log" `
        -NoNewWindow -PassThru -Wait

    [bool] $isErrorCode = $process.ExitCode -ne 0
    [bool] $isErrorOutput = ( Get-Content -Path "$LogfilePath-$ReportName-error.log" ).Length -gt 0
    if ($isErrorCode -or $isErrorOutput)
    {
        throw "Deployment failed."
    } else {
        Write-ToLogfile "Deployment successful." -Region 'SSRS_Subscription.exe'
    }
}