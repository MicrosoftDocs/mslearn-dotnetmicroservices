﻿[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_sql.log"
)

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

$ErrorActionPreference = 'Stop'

Import-Module $DeploymentHelperPath
Import-Module ( Join-Path $PSScriptRoot 'ReportingDeployment.psd1' )

Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region Load parameter from ARA.xml

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

try {
    $scriptCommands = Get-AraScriptCommand `
        -AraXmlPath $AraXmlPath `
        -ProjectName $ProjectName `
        -Environment $Environment `
        -ScriptFolderName $ScriptFolderName `
        -ModuleName $ModuleName
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Prepare:Load ARA: $( $_.Exception )"
    exit 1
}

#endregion
#region Main Routine
$region = 'SSRS'

try {
    # $S = New-PSSession -ComputerName $( $ENV:COMPUTERNAME )
    # Invoke-Command -Session $S {Install-Module -Name ReportingServicesTools -Scope CurrentUser -Verbose}
    # Import-PSSession -Session $S -Module ReportingServicesTools
    #Import-Module "$ScriptFolderPath\ReportingServicesTools\ReportingServicesTools.psd1" -Force
    #Install-Module -Name ReportingServicesTools -Scope CurrentUser -Verbose
    Import-Module ReportingServicesTools -Force
    Write-ToLogfile -Message "Imported successfully" -Region $region
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw 
}

try {

#region Folder and Premissions

    $scriptCommands |
    ForEach-Object {

        [string] $reportServerUrl = $_.Attributes['reportServerUrl'].Value
        Write-ToLogfile -Message "Deploy to '$reportServerUrl'" -Region $region

        Select-Xml -Xml $_ -XPath ".//folder" -PipelineVariable folderXml |
        ForEach-Object {
            Deploy-Folder `
                -FolderConfig $folderXml.Node `
                -ReportServerUri $reportServerUrl

            Deploy-Permissions `
                -FolderConfig $folderXml.Node `
                -RsPath "/$( $folderXml.Node.Attributes['path'].Value )" `
                -ReportServerUri $reportServerUrl
        }
    }

#endrregion
#region Data Sources

    $dataSourceReferences = @{}

    $scriptCommands |
    ForEach-Object {

        [string] $reportServerUrl = $_.Attributes['reportServerUrl'].Value
        Write-ToLogfile -Message "Deploy to '$reportServerUrl'" -Region $region

        Select-Xml -Xml $_ -XPath ".//folder" -PipelineVariable folderXml |
        ForEach-Object {

            Deploy-DataSources `
                -FolderConfig $folderXml.Node `
                -RsPath "/$( $folderXml.Node.Attributes['path'].Value )" `
                -ReportServerUri $reportServerUrl |
            ForEach-Object {
                $dataSourceReferences[$_.Name] = $_.Path
            }

        }
    }

#endrregion
#region Reports and Subscriptions

    $scriptCommands |
    ForEach-Object {

        [string] $reportServerUrl = $_.Attributes['reportServerUrl'].Value
        Write-ToLogfile -Message "Deploy to '$reportServerUrl'" -Region $region

        Select-Xml -Xml $_ -XPath ".//folder" -PipelineVariable folderXml |
        ForEach-Object {

            Deploy-Reports `
                -FolderConfig $folderXml.Node `
                -RsPath "/$( $folderXml.Node.Attributes['path'].Value )" `
                -ReportServerUri $reportServerUrl `
                -DataSourceReferences $dataSourceReferences `
                -ScriptFolderPath $ScriptFolderPath

        }
    }

#endrregion

}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw
}

#endregion
