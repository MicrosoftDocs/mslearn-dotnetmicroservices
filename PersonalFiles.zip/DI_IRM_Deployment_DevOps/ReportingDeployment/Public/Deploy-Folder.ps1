function Deploy-Folder {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement] $FolderConfig,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $ReportServerUri
    )

    $region = 'SSRS', 'Folder'
    Write-ToLogfile -Message "Start" -Region $region

    [string] $path, $name = $FolderConfig.Attributes['path'].Value -split '/', 2
    if ( $path -and -not $name) {
        $name = $path
        $path = '/'
    }
    if ( -not $path.StartsWith('/') ) {
        $path = '/' + $path
    }

    Write-ToLogfile -Message "Start deployment of folder '$name' in '$path'." -Region $region

    $rsFolder = Get-RsFolderContent -RsFolder $path -ReportServerUri $ReportServerUri |
    Where-Object { $_.Name -eq $name }

    if ( -not $rsFolder ) {
        $rsFolder = New-RsFolder -RsFolder $path -FolderName $name -ReportServerUri $ReportServerUri
        Write-ToLogfile -Message "Folder '$name' on the report server was created." -Region $region
    } else {
        Write-ToLogfile -Message "Folder '$name' on the report server already exists." -Region $region
    }

    Write-ToLogfile -Message "End" -Region $region
}