function Deploy-Reports {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement] $FolderConfig,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $RsPath,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $ReportServerUri,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [hashtable] $DataSourceReferences,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        $ScriptFolderPath
    )



    $region = 'SSRS', 'Reports'
    Write-ToLogfile -Message "Start" -Region $region

    Select-Xml -Xml $FolderConfig -XPath "./report" -PipelineVariable reportXml |
    ForEach-Object {
        $reportName = $reportXml.Node.Attributes['name'].Value
        $timeout = $reportXml.Node.Attributes['ReportTimeout'].Value

        $reportPath = "$ScriptFolderPath\..\..\$reportName.rdl"
        $rsReport = Get-RsFolderContent -RsFolder $RsPath -ReportServerUri $ReportServerUri |
        Where-Object { $_.Name -eq $reportName }

        Write-ToLogfile -Message "(Re)Create report '$reportName' in '$RsPath'." -Region $region
        $rsReport = Write-RsCatalogItem -RsFolder $RsPath -ReportServerUri $ReportServerUri `
            -Path $reportPath `
            -Overwrite

        # TODO : set timeout

        #region Deploy DataSource References
        $region = 'SSRS', 'Reports', 'References'
        Write-ToLogfile -Message "Add DataSource References for '$reportName'." -Region $region
        $ssrsNamespace = @{ ssrs = 'http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition' }
        Select-Xml -Path $reportPath -XPath '//ssrs:DataSource' -Namespace $ssrsNamespace |
        ForEach-Object {
            $dataSourceName = $_.Node.Attributes['Name'].value
            $dataSourceReference = (
                Select-Xml -Xml $_.Node -XPath './ssrs:DataSourceReference' -Namespace $ssrsNamespace
            ).Node.InnerText
            Write-ToLogfile -Message "Report DataSource '$dataSourceName' references to '$dataSourceReference'." -Region $region

            $dataSourcePath = $DataSourceReferences[$dataSourceReference]
            Write-ToLogfile -Message "Add Reference to '$dataSourcePath'." -Region $region

            Set-RsDataSourceReference `
                -Path "$RsPath/$reportName" `
                -DataSourceName $dataSourceName `
                -DataSourcePath $dataSourcePath `
                -ReportServerUri $ReportServerUri
        }
        #endregion

        #region Deploy Subscriptions
        $region = 'SSRS', 'Reports', 'Subscriptions'
        Write-ToLogfile -Message "Start" -Region $region

        Select-Xml -Xml $reportXml.Node -XPath "./subscription" -PipelineVariable subscriptionXml |
        ForEach-Object {
            [string] $username = $subscriptionXml.Node.Attributes['username'].Value
            [string] $password = $subscriptionXml.Node.Attributes['password'].Value
            [string] $datasourceServerInstance = $subscriptionXml.Node.Attributes['datasourceServerInstance'].Value
            [string] $fileshare = $subscriptionXml.Node.Attributes['fileshare'].Value

            [string] $subscriptionPath = "$ScriptFolderPath\..\..\$reportName.subscription.xml"

            Write-ToLogfile -Message "Create report subscription for '$reportName' in '$RsPath'." -Region $region

            Invoke-DeploySubscription `
                -Path $subscriptionPath `
                -ReportName $reportName -ReportFolder $RsPath `
                -ReportServerEndpointUrl "$ReportServerUri/ReportService2010.asmx" `
                -DatasourceServerInstance $datasourceServerInstance `
                -Username $username -Password $password `
                -FileShare $fileShare `
                -DeploySsrsSubscriptionPath "$ScriptFolderPath\..\..\SSRS_Subscription\SSRS_Subscription.exe"

        }

        Write-ToLogfile -Message "End" -Region $region
        #endregion

    }

    Write-ToLogfile -Message "End" -Region $region
}
