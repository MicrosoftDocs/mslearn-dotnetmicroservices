function Deploy-Permissions {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement] $FolderConfig,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $RsPath,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $ReportServerUri
    )

    $region = 'SSRS', 'Permissions'
    Write-ToLogfile -Message "Start" -Region $region

    Select-Xml -Xml $FolderConfig -XPath "./permission" -PipelineVariable permissionXml | ForEach-Object {
        [string] $identity = $permissionXml.Node.Attributes['account'].Value
        [string] $role = $permissionXml.Node.Attributes['role'].Value

        Write-ToLogfile -Message "Start deployment of permission '$role' for '$identity' on '$RsPath'." -Region $region
        Grant-RsCatalogItemRole -Identity $identity -RoleName  $role -ReportServerUri $ReportServerUri -Path $RsPath
    }

    Write-ToLogfile -Message "End" -Region $region
}