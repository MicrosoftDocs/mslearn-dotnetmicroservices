function Deploy-DataSources {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement] $FolderConfig,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $RsPath,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $ReportServerUri
    )

    $region = 'SSRS', 'Data Sources'
    Write-ToLogfile -Message "Start" -Region $region

    Select-Xml -Xml $FolderConfig -XPath "./datasource" -PipelineVariable datasourceXml |
    ForEach-Object {
        $name = $datasourceXml.Node.Attributes['name'].Value
        $extension = $datasourceXml.Node.Attributes['extension'].Value
        $connectionstring = $datasourceXml.Node.Attributes['connectionstring'].Value
        $username = $datasourceXml.Node.Attributes['username'].Value
        $password = $datasourceXml.Node.Attributes['password'].Value

        $credential = New-Object System.Management.Automation.PSCredential (
            $username,
            ( ConvertTo-SecureString $password -AsPlainText -Force )
        )

        $rsDatasource = Get-RsFolderContent -RsFolder $RsPath -ReportServerUri $ReportServerUri |
        Where-Object { $_.Name -eq $name }

        Write-ToLogfile -Message "(Re)Create '$extension' report data source '$name' in '$RsPath' using '$username'." -Region $region

        $rsDatasource = New-RsDataSource -Path $RsPath -Name $name -ReportServerUri $ReportServerUri `
            -Extension $extension -ConnectionString $connectionstring `
            -DatasourceCredentials $credential -WindowsCredentials -CredentialRetrieval 'Store' `
            -Overwrite

        New-Object -Type PsObject -Property @{
            Name = $name
            Path = "$RsPath/$name"
        } | Write-Output
    }

    Write-ToLogfile -Message "End" -Region $region
}