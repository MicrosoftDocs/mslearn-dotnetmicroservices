[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ModuleName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Xml.XmlElement] $ConfigNode,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string] $StagingDirectory,

    $AvailableProjects
)

$configs = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$ModuleName']//scriptcommand[@scriptfolder='$ProjectName']"

if ( -not $configs ) {
    Write-ToLogfile "scriptcommand not found for module '$ModuleName' and project '$ProjectName'"
}

#region Copy SSRS_Subscription.exe

$ssrsSubscriptionPath = "$StagingDirectory/SSRS_Subscription"
New-Item -ItemType Directory -Path $ssrsSubscriptionPath | Out-Null

$AvailableProjects |
Where-Object { $_.BaseName -eq 'SSRS_Subscription'  } |
ForEach-Object { Get-ChildItem -Path "$( $_.FullName )/bin/Release/" } |
Where-Object { ( $_.Name -like '*.exe' -or $_.Name -like '*.dll') -and ( $_.Name -notlike '*.vshost.exe' ) } |
ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $ssrsSubscriptionPath
}

#endregion

$projects = $configs | ForEach-Object {
    Write-Output $_.Node.Attributes['projectName'].Value
} | Select -Unique

foreach ( $project in $projects ) {
    $reportingProject = $AvailableProjects | Where-Object { $_.BaseName -eq $project  }

    if ( -not $reportingProject ) {
        throw "Reporting project '$project' not found."
    }

    Get-ChildItem -Path $reportingProject.FullName -Recurse |
    Where-Object { $_.Name.EndsWith("rdl") } -PipelineVariable reportDefinition |
    ForEach-Object {
        Copy-Item -Path $reportDefinition.FullName -Destination $StagingDirectory
        Write-ToLogfile "Report '$reportDefinition' copied."
    }

    Get-ChildItem -Path $reportingProject.FullName -Recurse |
    Where-Object { $_.Name.EndsWith("subscription.xml") } -PipelineVariable subscriptionDefinition |
    ForEach-Object {
        Copy-Item -Path $subscriptionDefinition.FullName -Destination $StagingDirectory
        Write-ToLogfile "Subscription '$subscriptionDefinition' copied."
    }
}
