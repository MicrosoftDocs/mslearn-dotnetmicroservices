<#
    .SYNOPSIS
    Generic Powershell Module

    .NOTES
    Date:       2019-01-28
    Author:     Steffen Kampmann

    .DESCRIPTION
    This script loads the functions from the folders Internal and Public
    and export the public functions as module members.

#>

Write-Verbose "Start import module '$( ( Get-Item $PSScriptRoot ).Name )'"

foreach ($folder in @( 'Lib', 'Types', 'Public', 'Internal' ))
{
    $folderPath = Join-Path -Path $PSScriptRoot -ChildPath $folder
    Write-Verbose "Importing from $folder"

    if ( Test-Path $folderPath ) {

        switch ( $folder ) {
            Lib {
                Add-Type -Assembly System.IO.Compression.FileSystem

                foreach ($package in Get-ChildItem -Path $folderPath -Filter '*.nupkg')
                {
                    Write-Verbose "- extracting nupkg $( $pacakge.BaseName )"
                    $packageFolderPath = Join-Path $package.Directory.FullName $package.BaseName
                    if ( Test-Path $packageFolderPath ) {
                        Remove-Item -Path $packageFolderPath -Recurse
                    }
                    [System.IO.Compression.ZipFile]::ExtractToDirectory($package.FullName, $packageFolderPath)
                }

                foreach ( $dll in Get-ChildItem -Path $folderPath -Recurse -Filter '*.dll' ) {
                    Write-Verbose "- importing dll $( $dll.Name )"
                    try {
                        Add-Type -Path $dll.FullName
                    }
                    catch
                    {
                        $_.Exception.LoaderExceptions |
                        ForEach-Object {
                            Write-Error $_.Message
                        }
                        throw
                    }
                }
            }
            Types {
                foreach ( $assemblySource in Get-ChildItem -Path $folderPath -Recurse -Include *.cs ) {
                    Write-Verbose "- build namespace $( $assemblySource.Name )"
                    $assemblyPath = "$( ( Get-Item $PSCommandPath ).BaseName ).$( $assemblySource.BaseName ).dll"
                    Add-Type `
                        -TypeDefinition ( Get-Content -Path $assemblySource.FullName -Raw ) `
                        -OutputAssembly $assemblyPath `
                        -ReferencedAssemblies $global:TemporaryAssemblies
                    $global:TemporaryAssemblies = @() + ( @( ( Get-Item $assemblyPath ).FullName ) + $global:TemporaryAssemblies | Select-Object -Unique )

                    Write-Verbose "- importing type $( ( Get-Item $assemblyPath ).BaseName)"
                    Add-Type -Path $assemblyPath
                }
            }
            Internal {
                foreach ($function in Get-ChildItem -Path $folderPath -Filter '*.ps1')
                {
                    Write-Verbose "- importing internal function $( $function.BaseName )"
                    . $( $function.FullName )
                }
            }
            Public {
                foreach ($function in Get-ChildItem -Path $folderPath -Filter '*.ps1')
                {
                    Write-Verbose "- importing public function $( $function.BaseName )"
                    . $( $function.FullName )
                    Export-ModuleMember -Function $function.BaseName
                }
            }
            default {
                throw "$_ not implemented"
            }
        }
    } else {
        Write-Verbose "- '$folderPath' not found. skip."
    }
}

Write-Verbose "End import module"
