﻿<#

.SYNOPSIS

build.ps1

.EXAMPLE

./BuildHelper/build.ps1 `
    -VCSolutionPath '$/DI_IRM_Maintenance/DI_IRM_Maintenance.sln' `
    -VCDeploymentPath '$/DI_IRM_Deployment/DI_IRM_Deployment.sln' `
    -VCGeneralPath '$/DI_IRM_General/DI_IRM_General.sln' `
    -SourceDirectoryPath $(Build.SourcesDirectory) `
    -StagingDirectoryPath $(Build.ArtifactStagingDirectory)

.PARAMETER SourceDirectoryPath
The path to the source code root directory.

.PARAMETER StagingDirectoryPath
The path that will contain the build artefact

.PARAMETER VCSolutionPath
The path to the visual studio solution, relative to the SourceDirectoryPath

.PARAMETER VCDeploymentPath
The path to the visual studio solution, that contains the deployment solution, relative to the SourceDirectoryPath

.PARAMETER VCGeneralPath
The path to the visual studio solution, that contains the general projects, used by different solutions, relative to the SourceDirectoryPath

.DESCRIPTION

Generates a ARA.csv file that contains the environment specific deployment parameters. That is based on a template ARA.parameter.csv from the project DeploymentConfiguration and a solution specific ARA.parameter.csv file.
For more information see the documentation for the function Merge-Csv of DeploymentConfiguration.

Generates a ARA.xml file that contains the deployment configuration. That is based on a general template, a solution specific template and the ARA.csv.
For more information see the documentation for the functions New-AraInstanceXml and New-AraXml of DeploymentConfiguration.

Finally it builds every module in the ARA.xml file and generates a zip archive for each.
Currently there are 3 supported module types:
 - ScriptModules, which depend on Powershell deployment scripts and can be used for everything.
 - FileModules, which copy files from a folder to a remote machine (depricated)
 - IspacModules, which build Integration services projects (will be refactored soon)

#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $VCSolutionPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $VCDeploymentPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $VCGeneralPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $SourceDirectoryPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $StagingDirectoryPath,

    [ValidateScript({Test-Path $_})]
    [string]
    $VisualStudioPath = "C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\Common7\IDE\devenv.com"
    # see https://github.com/actions/virtual-environments/blob/master/images/win/Windows2019-Readme.md
)

if ( $VerbosePreference -eq 'SilentlyContinue' ) {
    function Write-Verbose {
        [CmdletBinding()]
        param (
            [Parameter( ValueFromPipeline = $true )]
            $Message
        )

        Add-Content -Path "build.log" -Value $Message
    }
}

$solution = Get-Item $VCSolutionPath.Replace( '$', $SourceDirectoryPath )
$deployment = Get-Item $VCDeploymentPath.Replace( '$', $SourceDirectoryPath )
$general = Get-Item $VCGeneralPath.Replace( '$', $SourceDirectoryPath )
$solutionName = $solution.BaseName

Write-Verbose "Build solution $solutionName"

Import-Module ( Join-Path $deployment.Directory.FullName 'DeploymentHelper\DeploymentHelper.psm1' )
Import-Module ( Join-Path $PSScriptRoot 'BuildHelper.psd1' )

# region Build
$region = 'Build'

#region Build - ARA.xml
$region = 'Build', 'ARA.xml'
Write-ToLogFile 'Start' -Region $region

$araXmlPath = "$StagingDirectoryPath\DI_IRM\ARA.xml"

# Create solution directory
$rootDir = Split-Path $araXmlPath
New-Item -ItemType Directory $rootDir -Force | Out-Null
Write-Verbose "Directory $rootDir was created."

Write-ToLogFile 'Run' -Region $region

# Create ARA.xml

Import-Module "$( $deployment.Directory.FullName )\DeploymentConfiguration\DeploymentConfiguration.psm1"

Write-ToLogFile 'Create ARA.csv from template' -Region $region
Merge-Csv `
    -TemplatePath "$( $general.Directory.FullName )\DI_IRM_ConfigurationTemplate\ARA.parameter.csv" `
    -InheritorPath "$( $solution.Directory.FullName )\ARA.parameter.csv" `
    -TargetPath "$( $solution.Directory.FullName )\ARA.csv" `
    -KeyColumn "Key"

Write-ToLogFile 'Create ARA.xml from instance' -Region $region
New-AraXml `
    -TemplatePath "$( $general.Directory.FullName )\DI_IRM_ConfigurationTemplate\ARA.entities.xml" `
    -InheritorPath "$( $solution.Directory.FullName )\ARA.template.xml" `
    -TargetPath "$( $solution.Directory.FullName )\ARA.inheritor.xml"

Write-ToLogFile 'Create ARA.xml from template' -Region $region
New-AraInstanceXml `
    -TemplatePath "$( $solution.Directory.FullName )\ARA.inheritor.xml" `
    -ParameterPath "$( $solution.Directory.FullName )\ARA.csv" `
    -TargetPath $araXmlPath

if ( Test-Path $araXmlPath ) {
    Write-ToLogFile "'$araXmlPath' created." -Region $region
} else {
    Write-ToLogFile "Build '$araXmlPath' failed." -Region $region -Level 'ERROR'
    exit 1
}

#New-Item -ItemType Directory "$StagingDirectoryPath\DI_IRM\DeploymentHelper" -Force | Out-Null



Copy-Item -Path "$( $deployment.Directory.FullName )\DeploymentHelper\Deploy.ps1" -Destination "$StagingDirectoryPath\DI_IRM\Deploy.ps1"
Copy-Item -Path "$( $deployment.Directory.FullName )\DeploymentHelper\Deploy_Clean.ps1" -Destination "$StagingDirectoryPath\DI_IRM\Deploy_Clean.ps1"
Copy-Item -Path "$( $deployment.Directory.FullName )\DeploymentHelper\Deploy_PwdReplace.ps1" -Destination "$StagingDirectoryPath\DI_IRM\Deploy_PwdReplace.ps1"
Copy-Item -Path "$( $deployment.Directory.FullName )\DeploymentHelper\" -Destination "$StagingDirectoryPath\DI_IRM\" -Recurse

if ( Test-Path "$StagingDirectoryPath\DI_IRM\Deploy.ps1" ) {
    Write-ToLogFile "$StagingDirectoryPath\DI_IRM\Deploy.ps1 created" -Region $region
} else {
    Write-ToLogFile "$StagingDirectoryPath\DI_IRM\Deploy.ps1 failed" -Region $region -Level 'ERROR'
    exit 1
}
if ( Test-Path "$StagingDirectoryPath\DI_IRM\DeploymentHelper" ) {
    Write-ToLogFile "$StagingDirectoryPath\DI_IRM\DeploymentHelper created." -Region $region
} else {
    Write-ToLogFile "$StagingDirectoryPath\DI_IRM\DeploymentHelper failed." -Region $region -Level 'ERROR'
    exit 1
}

Write-ToLogFile "$( $deployment.Directory.FullName )\DeploymentHelper\Deploy.ps1" -Region $region
Write-ToLogFile "$StagingDirectoryPath\DI_IRM\Deploy.ps1" -Region $region
Write-ToLogFile "$StagingDirectoryPath\DI_IRM\DeploymentHelper" -Region $region

Write-ToLogFile 'Stop' -Region $region
#endregion
#region Pepare Solution
$region = 'Build', 'Prepare', 'Dtproj'

Get-ChildItem -Path $solution.Directory.FullName -Recurse -Filter "*.dtproj" | ForEach-Object {
    $projectName = $_.BaseName
    $dtprojPath = $_.FullName
    $projectFolderPath = $_.Directory.FullName

    Write-ToLogfile -Message "Set-ProjectProtectionLevel of project '$projectName'"

    Set-ProjectProtectionLevel -Path $dtprojPath -ProjectName $projectName -ProjectFolderPath $projectFolderPath
}

#endregion
#region Build - VisualStudio
$region = 'Build', 'VisualStudio'
Write-ToLogFile 'Start' -Region $region

foreach ( $vsSolution in @( $solution ) ) { # $deployment, $general,
    Write-ToLogFile "Compile $( $vsSolution.Basename )." -Region $region
    Invoke-VisualStudioBuild -VisualStudioPath $VisualStudioPath -SoltuionPath $vsSolution.FullName -SolutionConfigName 'Release'
    $upgradeLogPath = Join-Path ( Get-Item $vsSolution ).Directory 'UpgradeLog.htm'
    $newUpdateLogPath = "$StagingDirectoryPath\DI_IRM\$solutionName\$( ( Get-Item $vsSolution ).BaseName )_UpgradeLog.htm"
    if (Test-Path -Path $upgradeLogPath ) {
        New-Item -ItemType Directory -Path "$StagingDirectoryPath\DI_IRM\$solutionName" -Force
        Copy-Item -Path $upgradeLogPath -Destination $newUpdateLogPath
    }
}

Write-ToLogFile 'Stop' -Region $region
#endregion

#endregion

#region Link

#region Link - Modules
$region = 'Link', 'Modules'
Write-ToLogFile 'Start' -Region $region

$modules = Select-XmlWithEntities $araXmlPath -XPath '//module'

Add-Type -Assembly System.IO.Compression.FileSystem

$modules | ForEach-Object {
    $moduleNode = $_.Node
    $moduleName = $moduleNode.Attributes['name'].value

    #region Link module
    $region = 'Link', 'Modules', $moduleName

    $moduleNameUnique = $solutionName + '_' + $moduleName
    $moduleType = $moduleNode.Attributes['type'].value
    $moduleFileName = "$moduleNameUnique.zip"
    $moduleStagingPath = "$StagingDirectoryPath\$solutionName\$moduleNameUnique"

    Write-ToLogFile "Module type is: '$moduleType'." -Region $region

    New-Item -ItemType 'Directory' -Path $moduleStagingPath | Out-Null

    Write-ToLogFile "Staging directory '$moduleStagingPath' created." -Region $region

    switch ( $moduleType ) {
        'ssdt_dacpac_scripts' {
            Build-ScriptModule `
                -Name $moduleName `
                -ConfigNode $moduleNode `
                -SourceDirectories $solution.Directory, $deployment.Directory, $general.Directory `
                -StagingDirectory $moduleStagingPath
        }
        'ssis_ispac' {
            Build-IspacModule `
                -SourceDirectories $solution.Directory, $deployment.Directory `
                -StagingDirectory $moduleStagingPath
        }
        'ssis_filecopy' {
            Build-FileModule `
                -Name $moduleName `
                -ConfigNode $moduleNode `
                -SourceDirectories $solution.Directory, $general.Directory `
                -StagingDirectory $moduleStagingPath
         }
        default {
            throw "Module type '$moduleType' is not implemented."
        }
    }

    Write-ToLogFile "Files staged." -Region $region

    Write-ToLogFile "Stage state:" -Region $region
    Get-ChildItem -Path $moduleStagingPath -Recurse | ForEach-Object { Write-ToLogFile "- $( $_.FullName ) | $( $_.Length )" -Region $region }

    [IO.Compression.ZipFile]::CreateFromDirectory($moduleStagingPath, "$StagingDirectoryPath\DI_IRM\$moduleFileName", [System.IO.Compression.CompressionLevel]::NoCompression, $true)
    Write-ToLogFile "Archive '$moduleFileName' created." -Region $region

    #endregion
}

Write-ToLogFile 'Stop' -Region $region
#endregion
#endregion
