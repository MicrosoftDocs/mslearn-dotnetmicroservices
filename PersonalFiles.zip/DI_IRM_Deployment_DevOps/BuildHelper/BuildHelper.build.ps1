param (
    $ModuleName = ( ( Get-Item -Path $PSScriptRoot ).Name ),
    $SolutionTitle = ( ( ( Get-Item -Path $PSScriptRoot ).Parent.Name -split '_' )[-1] )
)

task BuildWiki {
    # this task is based on platyPS ... maybe you need to run Install-Module platyPS -Scope CurrentUser
    Import-Module "$PSScriptRoot\$ModuleName.psd1" -Force
    New-MarkdownHelp -Module $ModuleName -OutputFolder "..\..\DI_IRM_Wiki\DI_IRM.wiki\$SolutionTitle\$ModuleName" -Force -NoMetadata -AlphabeticParamsOrder
    if ( Test-Path "$PSScriptRoot\Readme.md" ) { Copy-Item "$PSScriptRoot\Readme.md" "..\..\DI_IRM_Wiki\DI_IRM.wiki\$SolutionTitle\$ModuleName.md" -Force }
}

task Clean {
    Remove-Item "$PSScriptRoot\bin" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item "$PSScriptRoot\obj" -Recurse -Force -ErrorAction SilentlyContinue
    Get-ChildItem "$PSScriptRoot\Lib" -Directory -ErrorAction SilentlyContinue | Remove-Item -Recurse
    Get-ChildItem $PSScriptRoot -Recurse -Include *.log -File -ErrorAction SilentlyContinue | Remove-Item -Recurse
}

task Build psm1, build.ps1

task psm1 {
    Copy-Item -Path "..\..\DI_IRM_General\PowershellTemplate\PowershellTemplate.psm1" -Destination "$PSScriptRoot\$ModuleName.psm1"
}

task build.ps1 {
    Copy-Item -Path "..\..\DI_IRM_General\PowershellTemplate\PowershellTemplate.build.ps1" -Destination "$PSScriptRoot\$ModuleName.build.ps1"
}
