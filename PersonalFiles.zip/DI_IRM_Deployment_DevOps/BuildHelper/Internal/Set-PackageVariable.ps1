function Set-PackageVariable
{

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $PackageName,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $AraXmlPath
    )

    # Load the ARA configuration.
    $ara = New-Object XML
    $ara.Load($AraXmlPath)

    # Load the dtsx file.
    $dtsx = New-Object XML
    $dtsx.Load($Path)
    $dtsNamespace = New-Object System.Xml.XmlNamespaceManager($dtsx.NameTable)
    $dtsNamespaceUri = 'www.microsoft.com/SqlServer/Dts'
    $dtsNamespace.AddNamespace("DTS", $dtsNamespaceUri)

    $dtsx.SelectNodes('//DTS:VariableValue', $dtsNamespace) | ForEach-Object {
        $variableName = $_.ParentNode.Attributes['DTS:ObjectName'].value
        $valueNode = $_
        $configNode = $ara.SelectSingleNode("//module[@type='ssis_ispac']/buildSettings/variable[@package='$( $PackageName ).dtsx' and @name='$variableName']")
        if ( $configNode ) {
            $value = $configNode.Attributes['value'].Value
            Write-Verbose "Change DTS:Variable [$PackageName][$variableName] from '$( $valueNode.InnerText )' to '$value'"
            $valueNode.InnerText = $value
            $value = $null
        } else {
            Write-Verbose "Skip DTS.Variable [$PackageName][$variableName], due to a lack of configuration."

            if ( $valueNode.InnerText.Trim().StartsWith( '\\' ) ) {
                Write-Warning "Default value [$PackageName][$variableName] = '$( $valueNode.InnerText ) was not replaced."
            }
        }
    }
    $dtsx.Save($Path)
}
