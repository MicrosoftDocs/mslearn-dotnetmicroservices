function Set-PackageProtectionLevel
{

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $PackageName
    )

    # Load the dtsx file.
    $dtsx = New-Object XML
    $dtsx.Load($Path)
    $dtsNamespace = New-Object System.Xml.XmlNamespaceManager($dtsx.NameTable)
    $dtsNamespaceUri = 'www.microsoft.com/SqlServer/Dts'
    $dtsNamespace.AddNamespace("DTS", $dtsNamespaceUri)

    # Change attribute DTS:ProtectionLevel of the DTS:Executable element
    $executable = $dtsx.SelectSingleNode("//DTS:Executable", $dtsNamespace)
    $attributeName = "DTS:ProtectionLevel"
    $attribute = $executable[$attributeName]
    if (-not $attribute) {
        $attribute = $executable.OwnerDocument.CreateAttribute($attributeName, $dtsNamespaceUri)
        $attribute = $executable.Attributes.Append($attribute)
        Write-Verbose "Added attribute [$attributeName] to DTS:Executable [$PackageName]"
    }
    $previousValue = $attribute.Value
    $attribute.Value = "0"
    Write-Verbose "Changed ProtectionLevel in DTS:Executable [$PackageName] from '$previousValue' to '$( $attribute.Value )'"

    # Save the changes in the dtsx file.
    $dtsx.Save($Path)
}
