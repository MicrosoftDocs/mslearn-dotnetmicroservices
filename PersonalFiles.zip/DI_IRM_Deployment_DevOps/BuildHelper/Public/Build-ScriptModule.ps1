function Build-ScriptModule
{
    <#

    .SYNOPSIS
    Builds a ScriptModule based on the Powershell project in the solution directory.

    .PARAMETER SourceDirectories
    The list of directories that may contain the required projects.

    .PARAMETER StagingDirectory
    The path to the directory that should contain the artifacts, that should be packed as artifact.

    .PARAMETER Name
    The name of the module.

    .PARAMETER ConfigNode
    The XML node of the deployment configuration of that module.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceDirectories,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $StagingDirectory,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Name,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement]
        $ConfigNode
    )

    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//scriptcommand" | ForEach-Object {
        $_.Node.Attributes['scriptfolder'].Value
    } | Select -Unique

    # get list of available visual studio project folders
    $availableProjects = $SourceDirectories | ForEach-Object {
        Get-ChildItem -Path $_ | Where-Object { $_.PSIsContainer }
    }

    # copy DeploymentHelper module
    $availableProjects | Where-Object { $_.BaseName -eq 'DeploymentHelper' } | ForEach-Object {
        Write-ToLogFile "Copy [$( $_.Name )] to '$StagingDirectory'."
        Copy-Item $_.Fullname -Destination $StagingDirectory -Recurse
    }

    # copy script directories
    $availableProjects | Where-Object { $_.BaseName -in $requiredProjects } | ForEach-Object {
        [string] $projectName = $_.Name
        Write-ToLogFile "Copy [$projectName] to '$StagingDirectory'."
        $projectStagingDirectory = "$StagingDirectory\Scripts\$projectName"
        Copy-Item $_.Fullname -Destination $projectStagingDirectory -Recurse

        # ARA needs that name ...
        Move-Item "$projectStagingDirectory\deploy.ps1" "$projectStagingDirectory\deploy_sql.ps1"

        $buildScriptPath = "$( $_.Fullname )\build.ps1"
        if ( Test-Path $buildScriptPath ) {

            Write-ToLogfile "Invoke build script '$buildScriptPath'."
            & $buildScriptPath `
                -ModuleName $Name `
                -ProjectName $projectName `
                -ConfigNode $ConfigNode `
                -StagingDirectory "$projectStagingDirectory\..\.." `
                -AvailableProjects $availableProjects
        } else {
            Write-ToLogfile "No build script found at '$buildScriptPath'."
        }
    }

    # check required projects
    $requiredProjects |
    Where-Object { $_ -notin ( $availableProjects | ForEach-Object { $_.BaseName } ) } |
    ForEach-Object {
        throw "Project '$_' was not found."
    }

    # remove temporary files
    Get-ChildItem $StagingDirectory -Recurse -Include 'obj', '*.*proj', 'build.ps1' |
    ForEach-Object { Remove-Item $_ -Recurse }
}
