function Build-FileModule
{
    <#

    .SYNOPSIS
    Builds a FileModule based on a Powershell Project in the solution directory.

    .PARAMETER SourceDirectories
    The list of directories that may contain the required projects.

    .PARAMETER StagingDirectory
    The path to the directory that should contain the artifacts, that should be packed as artifact.

    .PARAMETER Name
    The name of the module.

    .PARAMETER ConfigNode
    The XML node of the deployment configuration of that module.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceDirectories,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $StagingDirectory,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Name,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $ConfigNode

    )

    # get list of required directories
    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//set[@key='Directory']" | ForEach-Object {
        $_.Node.Attributes['value'].Value
    } | Select -Unique

    if ( -not $requiredProjects ) {
        throw "Config node set key='Directory' is missing."
    }

    # get list of available visual studio project folders
    $availableProjects = $SourceDirectories | ForEach-Object {
        Get-ChildItem -Path $_ | Where-Object { $_.PSIsContainer }
    }

    # copy directories
    $availableProjects | Where-Object { $_.BaseName -in $requiredProjects } | ForEach-Object {
        Get-ChildItem -Path $_.FullName | ForEach-Object {
            Write-ToLogFile "Copy [$( $_.Name )] to '$StagingDirectory'."
            Copy-Item $_.Fullname -Destination $StagingDirectory -Recurse -Force
        }
    }

    # remove temporary files
    Get-ChildItem $StagingDirectory -Recurse -Include 'bin', 'obj', '*.*proj' | ForEach-Object { Remove-Item $_ -Recurse }
}