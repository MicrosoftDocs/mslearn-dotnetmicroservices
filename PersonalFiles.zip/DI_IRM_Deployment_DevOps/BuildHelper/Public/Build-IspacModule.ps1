function Build-IspacModule
{
    <#

    .SYNOPSIS
    Builds a IspacModule based on the SSIS Projects in the solution directory.

    .PARAMETER SourceDirectories
    The list of directories that may contain ispac files or required projects.

    .PARAMETER StagingDirectory
    The path to the directory that should contain the artifacts, that should be packed as artifact.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceDirectories,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $StagingDirectory
    )

    # get list of available visual studio project folders
    $availableProjects = $SourceDirectories | ForEach-Object {
        Get-ChildItem -Path $_ | Where-Object { $_.PSIsContainer }
    }

    # copy DeploymentHelper module
    $availableProjects | Where-Object { $_.BaseName -eq 'DeploymentHelper' } | ForEach-Object {
        Write-ToLogFile "Copy [$( $_.Name )] to '$StagingDirectory'."
        Copy-Item $_.Fullname -Destination $StagingDirectory -Recurse
    }

    $SourceDirectories | ForEach-Object {
        # copy deployment script
        Write-ToLogFile "Copy [deploy_ispac.ps1] to '$StagingDirectory'."
        Copy-Item $_/SSIS/deploy_ispac.ps1 -Destination $StagingDirectory -ErrorAction 'SilentlyContinue'

        # copy integration services artefacts
        Get-ChildItem $_ -Recurse -Include '*.ispac' | ForEach-Object {
            Write-ToLogFile "Copy [$( $_.Name )] to '$StagingDirectory'."
            Copy-Item $_ -Destination $StagingDirectory
        }
    }
}