function Invoke-VisualStudioBuild
{
    <#

    .SYNOPSIS
    Runs the Visual Studio compiler.

    .PARAMETER VisualStudioPath
    Specifies the path to the VisualStudio compiler.

    .PARAMETER SoltuionPath
    Specifies the path to the solution file.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $VisualStudioPath,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $SoltuionPath,

        [ValidateNotNullOrEmpty()]
        [string]
        $SolutionConfigName = 'Debug'
    )

    #region Prepare arguments

    $arguments = @( $SoltuionPath, '/Rebuild', $SolutionConfigName ) | Where-Object { $_ }

    #endregion
    #region Prepare process

    $processInfo = New-Object System.Diagnostics.ProcessStartInfo
    $processInfo.FileName = $VisualStudioPath
    $processInfo.RedirectStandardError = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.Arguments = [string]::Join(" ", $arguments)

    #endregion
    #region Start process
    Write-ToLogFile "Invoke-VisualStudioBuild: $scriptName : $( $processInfo.FileName ) $( $processInfo.Arguments )"

    $outputBuffer = New-Object System.Text.StringBuilder
    $errorBuffer = New-Object System.Text.StringBuilder

    $oScripBlock = {
        if (-not [String]::IsNullOrEmpty($EventArgs.Data)) {
            $Event.MessageData.AppendLine($EventArgs.Data)
            Write-ToLogFile $EventArgs.Data -Level INFO
        }
    }

    $eScripBlock = {
        if (-not [String]::IsNullOrEmpty($EventArgs.Data)) {
            $Event.MessageData.AppendLine($EventArgs.Data)
            Write-ToLogFile $EventArgs.Data -Level ERROR
        }
    }

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $processInfo

    $outputEvent = Register-ObjectEvent -InputObject $process `
        -Action $oScripBlock -EventName 'OutputDataReceived' `
        -MessageData $outputBuffer

    $errorEvent = Register-ObjectEvent -InputObject $process `
        -Action $eScripBlock -EventName 'ErrorDataReceived' `
        -MessageData $errorBuffer

    $process.Start() | Out-Null
    $process.BeginOutputReadLine();
    $process.BeginErrorReadLine();

    $process.WaitForExit()
    $returnCode = $process.ExitCode

    Unregister-Event -SourceIdentifier $outputEvent.Name
    Unregister-Event -SourceIdentifier $errorEvent.Name

    $standardOutput = $outputBuffer.ToString().Trim()
    $standardError = $errorBuffer.ToString().Trim()

    $process.Close() | Out-Null

    # Write-ToLogFile "Output $( $standardOutput.Length ) chars: $standardOutput"
    # Write-ToLogFile "Error $( $standardError.Length ) chars: $standardError"

    if ( $standardOutput.Contains('Some errors occurred during migration.') ) {
        Get-Content -Path ( Join-Path ( Get-Item $SoltuionPath ).Directory 'UpgradeLog.htm' ) -Raw |
            Write-Warning
    }

    if ( $returnCode -ne 0 )
    {
        throw "devenv.com exit code $returnCode; err: '$standardError'."
    }

    #endregion
}
