function Get-ScriptModuleBuildConfiguration {

    <#

    .SYNOPSIS
    Get the Build Configuration of a ScriptModule

    .DESCRIPTION
    In opposite to a DeploymentConfiguration,
    a build Configuration does not contain environment information,
    so it only retuns only the first configuration.

    .PARAMETER ConfigNode
    The XmlNode of the configuration file.

    .PARAMETER ModuleName
    The module name in the xml configuration.

    .PARAMETER ProjectName
    The project name in the xml configuration.

    .OUTPUTS
    Microsoft.PowerShell.Commands.SelectXmlInfo

    #>

    [CmdletBinding()]
    param (
        [System.Xml.XmlNode] $ConfigNode,
        [string] $ModuleName,
        [string] $ProjectName
    )

    Select-Xml -Xml $ConfigNode -XPath "//module[@name='$ModuleName']//environment" |
    Select-Object -First 1 |
    Select-Xml -XPath ".//scriptcommand[@scriptfolder='$ProjectName']" |
    Write-Output
}
