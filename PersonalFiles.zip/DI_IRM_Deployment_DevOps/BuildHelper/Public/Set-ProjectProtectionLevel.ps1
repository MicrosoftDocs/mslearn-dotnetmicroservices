function Set-ProjectProtectionLevel
{

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $ProjectFolderPath
    )

    # Load dtproj file
    $dtproj = New-Object XML
    $dtproj.Load($Path)
    $ssisNamespace = New-Object System.Xml.XmlNamespaceManager($dtproj.NameTable)
    $ssisNamespaceUri = 'www.microsoft.com/SqlServer/SSIS'
    $ssisNamespace.AddNamespace("SSIS", $ssisNamespaceUri)

    # Change attribute SSIS:ProtectionLevel of the SSIS:Project element.
    $project = $dtproj.SelectSingleNode("//SSIS:Project", $ssisNamespace)
    $attributeName = "SSIS:ProtectionLevel"
    $attribute = $project[$attributeName]
    $previousValue = $attribute.Value
    if (-not $attribute) {
        $attribute = $project.OwnerDocument.CreateAttribute($attributeName, $ssisNamespaceUri)
        $attribute = $project.Attributes.Append($attribute)
        Write-Verbose "Added attribute [$attributeName] to SSIS:Project [$ProjectName]"
    }
    $attribute.Value = 'DontSaveSensitive'
    Write-Verbose "Changed ProtectionLevel for project [$ProjectName] from '$previousValue' to '$( $attribute.Value )'"

    foreach($element in $dtproj.SelectNodes("//SSIS:Property[@SSIS:Name=`"ProtectionLevel`"]", $ssisNamespace))
    {
        # Change element SSIS:ProtectionLevel of the SSIS:Property element per SSIS package.
        $nameNode = $element.ParentNode.SelectSingleNode("SSIS:Property[@SSIS:Name=`"Name`"]", $ssisNamespace)
        $packageName = $nameNode.InnerText
        $previousValue = $element.InnerText
        $element.InnerText = "0"
        Write-Verbose "Changed SSIS:Property ProtectionLevel for [$ProjectName].[$packageName] from '$previousValue' to '$( $element.InnerText )'"

        Set-PackageProtectionLevel -Path "$ProjectFolderPath/$packageName.dtsx" -PackageName $packageName

    }

    # Save the changes in the dtproj file.
    $dtproj.Save($Path)
    Write-Verbose "Changed ProtectionLevel of project [$ProjectName]"
}
