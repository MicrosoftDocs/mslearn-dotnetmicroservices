# BuildHelper

This module generates a build artefact as required from ARA (Release Automation).
See the documentation of `build.ps1` in the source code for further information.
