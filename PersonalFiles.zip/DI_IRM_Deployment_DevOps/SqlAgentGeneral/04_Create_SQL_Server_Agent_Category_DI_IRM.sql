/*

    # Create_SQL_Server_Agent_Category_DI_IRM

    Creates a SQL Server Agent Category.

    Date: 29.03.2018
    Autor: Steffen Kampmann

    ## Changelog

    06.04.2018 - Steffen Kampmann

    - Moved to project SQLAgentGeneral

    ## Parameters

    - no parameters

*/

USE [msdb]
GO

BEGIN TRANSACTION

DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DI_IRM' AND category_class=1)
BEGIN

    RAISERROR ('SQL Server Agent Category "DI_IRM" already exists.', 0, 1) WITH NOWAIT
    RAISERROR ('Skip create.', 0, 1) WITH NOWAIT

END
ELSE
BEGIN

	RAISERROR ('Create SQL Server Agent Category "DI_IRM".', 0, 1) WITH NOWAIT
    EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DI_IRM'
    IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	RAISERROR ('SQL Server Agent Category "DI_IRM" created.', 0, 1) WITH NOWAIT

END

COMMIT TRANSACTION
RAISERROR ('Script was successful.', 0, 1) WITH NOWAIT
GOTO EndSave

QuitWithRollback:
	RAISERROR ('Script has failed: Rollback Transaction.', 0, 1) WITH NOWAIT
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION

EndSave:
GO