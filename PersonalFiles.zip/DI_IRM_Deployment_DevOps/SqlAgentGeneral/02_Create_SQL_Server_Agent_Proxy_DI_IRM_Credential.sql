/*

    # Create_SQL_Server_Agent_Proxy_DI_IRM_Credential

    Creates a SQL Agent proxy.

    Date: 11.10.2017
    Autor: Andreas Leibner

    ## Changelog

    19.03.2018 - Steffen Kampmann

    - Added script header
    - Added conditional creation

    20.03.2018 - Steffen Kampmann

    - Added logging

    06.04.2018 - Steffen Kampmann

    - Moved to project SQLAgentGeneral

    06.06.2018 - Steffen Kampmann

    - Added parameter ProxyName and ProxyCredentialName

    ## Parameters

    ProxyName
    ProxyCredentialName

*/

USE msdb;
GO

-- creates proxy and assigns the credential to it, if the proxy doesn't exists.

IF EXISTS (
    SELECT
        1
    FROM
        sysproxies
    WHERE
        name = '$(ProxyName)'
) BEGIN

    RAISERROR ('SQL Server Agent Proxy "%s" already exists.', 0, 1, '$(ProxyName)') WITH NOWAIT
    RAISERROR ('Skip create.', 0, 1) WITH NOWAIT
    EXEC msdb..sp_update_proxy @proxy_name='$(ProxyName)', @credential_name='$(ProxyCredentialName)', @enabled=1
    RAISERROR ('SQL Server Agent Proxy "%s" mapped to SQL Server Credential "%s".', 0, 1, '$(ProxyName)', '$(ProxyCredentialName)') WITH NOWAIT

END
ELSE
BEGIN

    RAISERROR ('Create SQL Server Agent Proxy "%s".', 0, 1, '$(ProxyName)') WITH NOWAIT
    EXEC dbo.sp_add_proxy
        @proxy_name = N'$(ProxyName)',
        @enabled = 1,
        @description = '$(ProxyName)',
        @credential_name = '$(ProxyCredentialName)' ;

    RAISERROR ('Grant "Command-Line subsystem" to "%s".', 0, 1, '$(ProxyName)') WITH NOWAIT
    EXEC dbo.sp_grant_proxy_to_subsystem
        @proxy_name = N'$(ProxyName)',
        @subsystem_id = 3 ;

    RAISERROR ('Grant "Analysis query subsystem" to "%s".', 0, 1, '$(ProxyName)') WITH NOWAIT
    EXEC dbo.sp_grant_proxy_to_subsystem
        @proxy_name = N'$(ProxyName)',
        @subsystem_id = 9 ;

    RAISERROR ('Grant "Analysis command subsystem" to "%s".', 0, 1, '$(ProxyName)') WITH NOWAIT
    EXEC dbo.sp_grant_proxy_to_subsystem
        @proxy_name = N'$(ProxyName)',
        @subsystem_id = 10 ;

    RAISERROR ('Grant "SSIS package execution subsystem" to "%s".', 0, 1, '$(ProxyName)') WITH NOWAIT
    EXEC dbo.sp_grant_proxy_to_subsystem
        @proxy_name = N'$(ProxyName)',
        @subsystem_id = 11 ;

    RAISERROR ('Grant "PowerShell subsystem" to "%s".', 0, 1, '$(ProxyName)') WITH NOWAIT
    EXEC dbo.sp_grant_proxy_to_subsystem
        @proxy_name = N'$(ProxyName)',
        @subsystem_id = 12 ;

END
GO