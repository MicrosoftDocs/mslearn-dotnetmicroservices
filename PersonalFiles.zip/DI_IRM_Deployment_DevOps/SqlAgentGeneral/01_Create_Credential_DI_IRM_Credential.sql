﻿/*

    # Create_Credential_DI_IRM_Credential

    Creates a credential using specified username and password.

    Date: 11.10.2017
    Autor: Andreas Leibner

    ## Changelog

    19.03.2018 - Steffen Kampmann

    - Added script header
    - Added conditional creation

    20.03.2018 - Steffen Kampmann

    - Added logging

    06.04.2018 - Steffen Kampmann

    - Moved to project SQLAgentGeneral

    06.06.2018 - Steffen Kampmann

    - Added parameter ProxyCredentialName

    ## Parameters

    ProxyCredentialName
    ProxyCredentialUsername
    ProxyCredentialPassword

*/

USE msdb;
GO

-- Drop credential if exists.

RAISERROR ('Check SQL Server Credential "%s" for "%s".', 0, 1, '$(ProxyCredentialName)', '$(ProxyCredentialUsername)') WITH NOWAIT

IF EXISTS (
    SELECT
        1
    FROM
        sys.credentials
    WHERE
        name = '$(ProxyCredentialName)'
) BEGIN

    RAISERROR ('SQL Server Credential "%s" exists.', 0, 1, '$(ProxyCredentialName)') WITH NOWAIT
    DROP CREDENTIAL [$(ProxyCredentialName)]
    RAISERROR ('Dropped SQL Server Credential "%s".', 0, 1, '$(ProxyCredentialName)') WITH NOWAIT

END

-- Create credential
RAISERROR ('Create SQL Server Credential "%s" for "%s".', 0, 1, '$(ProxyCredentialName)', '$(ProxyCredentialUsername)') WITH NOWAIT
CREATE CREDENTIAL [$(ProxyCredentialName)] WITH IDENTITY = '$(ProxyCredentialUsername)', SECRET = '$(ProxyCredentialPassword)';

GO