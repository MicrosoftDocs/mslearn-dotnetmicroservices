/*

    # Apply_SQL_Server_Agent_Proxy

    Updates all job steps to use a specific proxy.

    Date: 06.06.2018
    Autor: Steffen Kampmann

    ## Parameters

    ProxyName
    JobName

*/

USE msdb;
GO

DECLARE @job_id UNIQUEIDENTIFIER
SELECT
	@job_id = job_id
FROM
	msdb.dbo.sysjobs
WHERE
	name = N'$(JobName)'

IF @job_id IS NOT NULL
BEGIN
    RAISERROR ('Updating SQL Server Agent Job "$(JobName)".', 0, 1) WITH NOWAIT
	DECLARE @step_id INT
	DECLARE steps_cursor CURSOR FOR
	SELECT step_id FROM msdb.dbo.sysjobsteps where job_id = @job_id and subsystem = 'SSIS'
	OPEN steps_cursor
	FETCH NEXT FROM steps_cursor INTO @step_id
	WHILE @@FETCH_STATUS = 0
	BEGIN

        RAISERROR ('Updating SQL Server Agent Job "$(JobName)" Step "%d".', 0, 1, @step_id) WITH NOWAIT

		EXEC msdb.dbo.sp_update_jobstep @job_id=@job_id, @step_id=@step_id, @proxy_name=N'$(ProxyName)'

		FETCH NEXT FROM steps_cursor INTO @step_id

	END
	CLOSE steps_cursor
	DEALLOCATE steps_cursor

END