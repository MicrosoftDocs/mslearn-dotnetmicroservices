﻿<#

    .SYNOPSIS
    Deploy SQL scripts for SQLAgentGeneral

    .NOTES
    Date:       2018-03-21
    Author:     Steffen Kampmann
    Version:    1.0

    Date:       2018-04-06
    Author:     Steffen Kampmann
    Version:    1.1

    - Moved to project SQLAgentGeneral

    .PARAMETER ProjectName
    The project of the sql script.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER Environment
    The environment in which the script needs to be executed.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER AraXmlPath
    Path to the ARA.xml .
    If not definied, it is ../ARA.xml

    .PARAMETER DeplyomentHelperPath
    Path to the Powershell functions of DeploymentHelper.

    .PARAMETER LogfilePath
    Path to the logfile of this script

#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_sql.log"
)

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region Script Definition

function Invoke-Scripts
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProxyName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProxyCredentialName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProxyCredentialUsername,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProxyCredentialPassword,

        [Parameter(Mandatory=$false)]
        [ValidateNotNullOrEmpty()]
        [string]
        $JobName
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\01_Create_Credential_DI_IRM_Credential.sql" `
        -Arguments `
            "ProxyName = ""$ProxyName""", `
            "ProxyCredentialName = ""$ProxyCredentialName""", `
            "ProxyCredentialUsername = ""$ProxyCredentialUsername""", `
            "ProxyCredentialPassword = ""$ProxyCredentialPassword"""

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\02_Create_SQL_Server_Agent_Proxy_DI_IRM_Credential.sql" `
        -Arguments `
            "ProxyName = ""$ProxyName""", `
            "ProxyCredentialName = ""$ProxyCredentialName"""

    if ( $JobName ) {
        Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\03_Apply_SQL_Server_Agent_Proxy.sql" `
            -Arguments `
                "ProxyName = ""$ProxyName""", `
                "JobName = ""$JobName"""
    }

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\04_Create_SQL_Server_Agent_Category_DI_IRM.sql"
}

#endregion
#region Load parameter from ARA.xml

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

try {
    $scriptCommands = Get-AraScriptCommand `
        -AraXmlPath $AraXmlPath `
        -ProjectName $ProjectName `
        -ModuleName $ModuleName `
        -Environment $Environment `
        -ScriptFolderName $ScriptFolderName
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Prepare:Load ARA: $( $_.Exception )"
    throw
}

#endregion
#region Execute
Write-ToLogFile "Execute: Start"

try
{
    foreach ( $scriptCommand in $scriptCommands ) {

        [string] $ServerInstance = $scriptCommand.serverInstance
        [string] $ProxyName = $scriptCommand.proxyName
        [string] $ProxyCredentialName = $scriptCommand.proxyCredentialName
        [string] $ProxyCredentialUsername = $scriptCommand.proxyCredentialUsername
        [string] $ProxyCredentialPassword = $scriptCommand.proxyCredentialPassword
        [string] $JobName = $scriptCommand.jobName

        Invoke-Scripts -ServerInstance $ServerInstance -ScriptFolderPath $ScriptFolderPath `
            -ProxyName $ProxyName -ProxyCredentialName $ProxyCredentialName `
            -ProxyCredentialUsername $ProxyCredentialUsername -ProxyCredentialPassword $ProxyCredentialPassword `
            -JobName $JobName
    }
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw
}

Write-ToLogFile "Execute: End"
#endregion
