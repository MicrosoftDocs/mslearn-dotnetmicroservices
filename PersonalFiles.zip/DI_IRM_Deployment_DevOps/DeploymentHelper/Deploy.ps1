<#

.SYNOPSIS

Deploy.ps1

.EXAMPLE

./BuildHelper/Deploy.ps1 `
    -Environment '$(Release.EnvironmentName)' `
    -DeploymentArtefactPath "$(System.DefaultWorkingDirectory)\$(Release.DefinitionName)/DI_IRM" `
    -DeploymentHelperPath "$(System.DefaultWorkingDirectory)\$(Release.DefinitionName)/DI_IRM/DeploymentHelper/DeploymentHelper.psm1" `

.PARAMETER DeploymentArtefactPath
The path that will contain the build artefact

.PARAMETER DeploymentHelperPath
The path that will contain the build artefact

.PARAMETER Environment
Deployment Environment

.PARAMETER $MasterKey
Master Key for Deployment


.DESCRIPTION

Generates a ARA.csv file that contains the environment specific deployment parameters. That is based on a template ARA.parameter.csv from the project DeploymentConfiguration and a solution specific ARA.parameter.csv file.
For more information see the documentation for the function Merge-Csv of DeploymentConfiguration.

Generates a ARA.xml file that contains the deployment configuration. That is based on a general template, a solution specific template and the ARA.csv.
For more information see the documentation for the functions New-AraInstanceXml and New-AraXml of DeploymentConfiguration.

It Deploys every module in the ARA.xml file.
Currently there are 3 supported module types:
 - ScriptModules, which depend on Powershell deployment scripts and can be used for everything.
 - FileModules, which copy files from a folder to a remote machine
 - IspacModules, which build Integration services projects

#>

[CmdletBinding()]
param(

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string]
    $DeploymentArtefactPath,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string]
    $DeploymentHelperPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $Environment

    # [Parameter(Mandatory=$true)]
    # [ValidateNotNullOrEmpty()]
    # [string]
    # $MasterKey

)

$ErrorActionPreference = 'Stop'

if ( $VerbosePreference -eq 'SilentlyContinue' ) {
    function Write-Verbose {
        [CmdletBinding()]
        param (
            [Parameter( ValueFromPipeline = $true )]
            $Message
        )

        Add-Content -Path "deploy.log" -Value $Message
    }
}


Write-Verbose "Deploymnet Helper path is $DeploymentHelperPath "
Write-Verbose "Deploymnet Artefact path is $DeploymentArtefactPath"
Write-Verbose "Environment is $Environment"

Import-Module  $DeploymentHelperPath
$araXmlPath = "$DeploymentArtefactPath\ARA.xml"


$project = Select-XmlWithEntities $araXmlPath -XPath '//project' | ForEach-Object {
    $projectName = $_.Node.Attributes['name'].value
}


Write-Verbose "Deployment solution $solutionName"


$zips = Get-ChildItem -Path $DeploymentArtefactPath -include ('*.zip') -recurse

foreach ($zip in $zips) 
{
    Expand-Archive -LiteralPath $zip -DestinationPath $DeploymentArtefactPath -Force
}


#region Link
# $fileContent = New-Object System.Xml.XmlDocument
# $fileContent.XmlResolver = $null
# $fileContent.Load($araXmlPath)
# $xmlNodes = $fileContent.SelectNodes("//ARA")
# $xmlNodes | foreach-object {
#     if ($_.Attributes["masterKey"].value -eq "%%MASTER_KEY%%" )
#         {
#             $_.Attributes["masterKey"].value = $MasterKey
#         }
# }
# $fileContent.Save($araXmlPath)


$modules = Select-XmlWithEntities $araXmlPath -XPath '//module'

Add-Type -Assembly System.IO.Compression.FileSystem

$modules | ForEach-Object {
    $moduleNode = $_.Node
    $moduleName = $moduleNode.Attributes['name'].value
    $moduleType = $moduleNode.Attributes['type'].value

Write-Output $moduleType
Write-Output $moduleName

    switch ( $moduleType ) {
         'ssdt_dacpac_scripts' {
             try {
                #  if ($moduleName -eq "4.REPORTS")
                #  {
                    Deploy-ScriptModule `
                    -Name $moduleName `
                    -ConfigNode $moduleNode `
                    -SourceDirectories $DeploymentArtefactPath `
                    -DeploymentHelperPath $DeploymentHelperPath `
                    -Environment $Environment `
                    -ProjectName $projectName
                #  }
             }
             catch {
                $lastExitCode = 1
                Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
                throw
             }

         }
        'ssis_ispac' {
            try {
                Deploy-IspacModule `
                -Name $moduleName `
                -ConfigNode $moduleNode `
                -SourceDirectories $DeploymentArtefactPath `
                -DeploymentHelperPath $DeploymentHelperPath `
                -Environment $Environment `
                -ProjectName $projectName
            }
            catch {
                $lastExitCode = 1
                Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
                throw
            }

        }
        'ssis_filecopy' {
            try {
                Deploy-FileModule `
                -Name $moduleName `
                -ConfigNode $moduleNode `
                -SourceDirectories $DeploymentArtefactPath `
                -DeploymentHelperPath $DeploymentHelperPath `
                -Environment $Environment `
                -ProjectName $projectName
            }
            catch {
                $lastExitCode = 1
                Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
                throw
            }

         }
        default {
            throw "Module type '$moduleType' is not implemented."
        }
    }

    #endregion
}
