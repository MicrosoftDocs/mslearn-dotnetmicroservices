using System.Collections.Generic;

namespace DeploymentHelper.Config
{
    public class XmlChange
    {
        public string Operation { get; set; }
        public string XPath { get; set; }
        public string Attribute { get; set; }
        public string Value { get; set; }
    }

    public class XmlNamespace
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }

    public class XmlFile
    {
        public string Path { get; set; }
        public List<XmlChange> Changes { get; set; }
        public List<XmlNamespace> Namespace { get; set; }
    }
}
