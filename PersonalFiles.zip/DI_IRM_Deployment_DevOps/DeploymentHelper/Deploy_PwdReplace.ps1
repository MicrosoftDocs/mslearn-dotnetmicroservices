
[CmdletBinding()]
param(

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $DevPwd,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $TestPwd,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $IntPwd,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $ProdPwd,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $Environment,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string]
    $AraXMLPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $MasterKey

)

if ( $VerbosePreference -eq 'SilentlyContinue' ) {
    function Write-Verbose {
        [CmdletBinding()]
        param (
            [Parameter( ValueFromPipeline = $true )]
            $Message
        )
    }
}

write-verbose "ARA XML Path is $AraXMLPath"

$fileContent = New-Object System.Xml.XmlDocument
$fileContent.XmlResolver = $null
$fileContent.Load($araXmlPath)
$xmlNodes = $fileContent.SelectNodes("//ARA")
$xmlNodes | foreach-object {
    if ($_.Attributes["masterKey"].value -eq "%%MASTER_KEY%%" )
        {
            $_.Attributes["masterKey"].value = $MasterKey
        }
}
$fileContent.Save($araXmlPath)

$find = "%%PASSWORD_USER%%"

switch ($Environment) {
    'DEV' { $pwdreplace = $DevPwd }
    'TEST'{ $pwdreplace = $TestPwd}
    'INT' { $pwdreplace = $IntPwd}
    'PROD' { $pwdreplace = $ProdPwd}
    Default {}
}

$MyRawString = Get-Content -Raw $araXmlPath
$content = $MyRawString -replace $find,$pwdreplace
$Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
[System.IO.File]::WriteAllLines($araXmlPath, $content, $Utf8NoBomEncoding)


write-verbose "Deplployment Path is $DeploymentFolder"

if (!(Test-Path -path $araXmlPath))
{
    write-verbose "ARA XML $DeploymentFolder Doesn't exists"
}
else 
{
    write-verbose "ARA XML $DeploymentFolder updated with password"
}

