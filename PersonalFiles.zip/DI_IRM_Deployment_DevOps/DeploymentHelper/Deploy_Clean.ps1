
[CmdletBinding()]
param(

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string]
    $DeploymentArtefactPath,

    [Parameter(Mandatory=$true)]
    [string]
    $DeploymentFolder

)

if ( $VerbosePreference -eq 'SilentlyContinue' ) {
    function Write-Verbose {
        [CmdletBinding()]
        param (
            [Parameter( ValueFromPipeline = $true )]
            $Message
        )
    }
}

write-verbose "Deplployment Path is $DeploymentFolder"

$logpath = "$DeploymentFolder\DI_IRM\Log"

if (!(Test-Path -path $DeploymentFolder)) 
{
    New-Item $DeploymentFolder -Type Directory
    write-verbose "Deplployment Path $DeploymentFolder is created"
}
else 
{
    write-verbose "Deplployment Path $DeploymentFolder exists already"
    Remove-Item "$DeploymentFolder\DI_IRM\*" -Recurse -Force 
    write-verbose "Files in Log Path $DeploymentFolder\DI_IRM deleted sucessfully"
}

copy-item $DeploymentArtefactPath $DeploymentFolder -Recurse -Force
write-verbose "Deplployment Artefact copied"

if (!(Test-Path -path $logpath)) 
{
    New-Item $logpath -Type Directory
    write-verbose "Log Path $logpath is created"
}
else 
{
    write-verbose "Log Path $logpath exists already"
    Remove-Item "$logpath\*" -Recurse -Force 
    write-verbose "Files in Log Path $logpath deleted sucessfully"
}
