<#

.SYNOPSIS
Tests for Invoke-SqlCmd

.DESCRIPTION
This is a PowerShell Unit Test file.
You need a unit test framework such as Pester to run PowerShell Unit tests.
You can download Pester from http://go.microsoft.com/fwlink/?LinkID=534084

#>

if ( -not $PSScriptRoot ) { $PSScriptRoot = Get-Location }
Import-Module $PSScriptRoot\..\DeploymentHelper.psm1

Describe "Invoke-SqlCmd" {

	BeforeAll {
		$serverInstance = "SQLDEVDIIRM.cloud.munichre.com"
		$serverInstance | Out-Null # inhibit false warning
		Set-Logfile "invoke_sql.log"
	}

	BeforeEach {
		$LogfilePath = "TestDrive:\test.log"
		$LogfilePath | Out-Null # inhibit false warning
	}

	AfterEach {
		if ( Test-Path $LogfilePath ) {
			Write-Host "### Logfile ###"
			Get-Content -Path $LogfilePath | Write-Host
		}
	}

	Context "Good Script" {

		BeforeAll {
			$scriptPath = "./Invoke-SqlCmd-Good.sql"
			$scriptPath | Out-Null # inhibit false warning
		}

		It "Checks no parameter" {

			{ Invoke-SqlCmd } | Should -Throw

		}

		It "Checks missing ServerInstance parameter " {

			{ Invoke-SqlCmd -Path $scriptPath } | Should -Throw

		}

		It "Checks invalid Path parameter" {

			{ Invoke-SqlCmd -Path "./File-That-Doesnt-Exist" -ServerInstance $serverInstance } | Should -Throw

		}

		It "Check missing script parameters" {

			{ Invoke-SqlCmd -Path $scriptPath -ServerInstance $serverInstance } | Should -Throw
		}

		It "Check valid parameters" {

			Invoke-SqlCmd -Path $scriptPath -ServerInstance $serverInstance -Arguments 'TableType = "View"' | Write-Host
		}
	}

	Context "Bad Script" {

		BeforeAll {
			$scriptPath = "./Invoke-SqlCmd-Bad.sql"
			$scriptPath | Out-Null # inhibit false warning
		}

		It "Check valid parameters" {

			{ Invoke-SqlCmd -Path $scriptPath -ServerInstance $serverInstance } | Should -Throw
		}
	}

	Context "Chatty Script" {

		BeforeAll {
			$scriptPath = "./Invoke-SqlCmd-Chatty.sql"
			$scriptPath | Out-Null # inhibit false warning
		}

		It "a lot of stdout traffic" {

			{ Invoke-SqlCmd -Path $scriptPath -ServerInstance $serverInstance -Timeout 10 } | Should -Not -Throw

		}
	}
}
