DECLARE @index INT = 1000
WHILE @index > 0
BEGIN
SET @index = @index - 1

RAISERROR ('Hello World %d', 0, 1, @index) WITH NOWAIT

END