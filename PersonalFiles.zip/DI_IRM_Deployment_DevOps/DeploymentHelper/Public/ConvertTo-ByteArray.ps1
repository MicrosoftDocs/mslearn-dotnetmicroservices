function ConvertTo-ByteArray
{
    <#

    .SYNOPSIS
    Converts a hex string to a byte array.

    .PARAMETER Hex
    A string in hex format that will be converted to a byte array.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]
        $Hex
    )

    [byte[]] $bytes = $(
        for ($index = 0; $index -lt $Hex.Length; $index = $index + 2) {
            [CHAR][BYTE][CONVERT]::toint16([string]($Hex[$index] + $Hex[$index + 1]),16)
        }
    )

    $bytes
}