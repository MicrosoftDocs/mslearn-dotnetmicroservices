function Import-SecurePassword
{
    <#

    .SYNOPSIS
    Decrypts a secure password using a master key.

    .PARAMETER SecurePassword
    Specifies the secure password as string.

    .PARAMETER MasterKey
    Specifies the master key as string.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $SecurePassword,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [byte[]]
        $MasterKey
    )

    Write-ToLogFile "Import Password: SecurePassword:$( $SecurePassword.Length ) MasterKey:$( $MasterKey.Length )"

    $password = ConvertTo-SecureString -String $SecurePassword -Key $MasterKey

    Write-ToLogFile "Import Password: Password:$( $password.Length )"

    $credential = New-Object System.Management.Automation.PSCredential ( 'user', $password )
    $credential.GetNetworkCredential().Password

}