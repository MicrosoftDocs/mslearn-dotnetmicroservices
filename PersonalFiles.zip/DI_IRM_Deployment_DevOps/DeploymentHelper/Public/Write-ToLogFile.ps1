function Write-ToLogfile
{
    <#

    .SYNOPSIS
    Writes a message to the logfile
    defined in the global variable $LogfilePath.

    .PARAMETER Message
    The message that will be written to the logfile.

    .PARAMETER Level
    The severity level of the log message.

    #>

    [CmdletBinding()]
    param(
        [Parameter( ValueFromPipeline = $true )]
        [string] $Message = ([Environment]::NewLine),

        [ValidateSet("INFO","WARNING","ERROR")]
        [string] $Level = 'INFO',

        [string[]] $Region = (( Get-PSCallStack ).Command[(( Get-PSCallStack ).Command.Count)..0] | Where-Object { $_ -ne '<ScriptBlock>' })
    )

    [string] $regionPrefix = ''

    if ( $Region ) {
        $regionPrefix = ( $Region | ForEach-Object { "[$_]" } ) -join '.'
    }

    $value = "$( $Level ):$( Get-Date ):$regionPrefix $Message"

    if ( $global:LogfilePath ) {
        Write-Verbose $value
        Add-Content -Path $global:LogfilePath -Value $value
    } else {
        Write-Verbose $value
    }

}
