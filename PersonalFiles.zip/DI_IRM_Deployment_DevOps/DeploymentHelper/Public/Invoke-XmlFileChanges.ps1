function Invoke-XmlFileChanges {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $Path,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [DeploymentHelper.Config.XmlChange[]] $Changes,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [DeploymentHelper.Config.XmlNamespace[]] $Namespace,

        [Parameter( Mandatory = $true )]
        [string] $BasePath
    )

    process {

        $region = $region + @( $Path )

        Write-ToLogfile 'Convert namespace' -Region $region

        $namespaceDict = @{}
        $Namespace | ForEach-Object {
            $namespaceDict[$_.Name] = $_.Value
        }

        Write-ToLogfile 'Start' -Region $region

        $FullPath = Join-Path $BasePath $Path

        $Changes | Invoke-XmlChange -Path $FullPath -Namespace $namespaceDict
        Write-ToLogfile 'Done' -Region $region

        $region = $region[0..-1]
    }
}
