function Deploy-ScriptModule
{
    <#

    .SYNOPSIS
    Builds a ScriptModule based on the Powershell project in the solution directory.

    .PARAMETER SourceDirectories
    The path to the directory that should contain the artifacts, that should be packed as artifact.

    .PARAMETER DeploymentHelperPath
    The path to the directory that have all helper scripts for deployment.

    .PARAMETER Name
    The name of the module.

    .PARAMETER ConfigNode
    The XML node of the deployment configuration of that module.

    .PARAMETER ProjectName
    The name of project component.

    .PARAMETER Environment
    Deployment Environment

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceDirectories,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $DeploymentHelperPath,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Name,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement]
        $ConfigNode,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProjectName,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Environment
    )

    $ErrorActionPreference = 'Stop'

    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//environment[@name='$Environment']//scriptcommand"
    
    $requiredProjects | ForEach-Object {
        $folderName = $_.Node.Attributes['scriptfolder'].Value
        $solutionName = $ProjectName + '_' + $Name
        $logpath = "$SourceDirectories\Log\$solutionName"
        Write-Output $solutionName
        Write-Output "ScriptFolderPath is $SourceDirectories\$solutionName\Scripts\$folderName"

        if (!(Test-Path -path $logpath)) 
        {
            New-Item $logpath -Type Directory
            write-verbose "Log Path $logpath is created"
        }

        try {
            if ($Name -eq "1.BACKUP")
            {
                . "$SourceDirectories\$solutionName\Scripts\$folderName\deploy_sql.ps1" `
                    -ProjectName $ProjectName `
                    -Environment $Environment `
                    -AraXmlPath "$SourceDirectories\ARA.xml" `
                    -DeploymentHelperPath $DeploymentHelperPath `
                    -ScriptFolderName $folderName `
                    -ModuleName $Name `
                    -ScriptFolderPath "$SourceDirectories\$solutionName\Scripts\$folderName" `
                    -LogfilePath "$logpath\Deploy_sql.log"  `
                    -BuildDropLocation "$SourceDirectories"
            }
            else 
            {
                . "$SourceDirectories\$solutionName\Scripts\$folderName\deploy_sql.ps1" `
                    -ProjectName $ProjectName `
                    -Environment $Environment `
                    -AraXmlPath "$SourceDirectories\ARA.xml" `
                    -DeploymentHelperPath $DeploymentHelperPath `
                    -ScriptFolderName $folderName `
                    -ModuleName $Name `
                    -ScriptFolderPath "$SourceDirectories\$solutionName\Scripts\$folderName" `
                    -LogfilePath "$logpath\Deploy_sql.log"  
            }

        }
        catch {
            Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
            throw
        }

    } 

}
