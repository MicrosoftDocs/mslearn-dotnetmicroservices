function Invoke-SqlCmd
{
    <#

    .SYNOPSIS
    Wrapper function for SQLCMD to execute SQL files

    .DESCRIPTION
    A documentation for SQLCMD can be found on
    https://docs.microsoft.com/en-us/sql/tools/sqlcmd-utility

    .PARAMETER Path
    The Path to the SQL file.

    .PARAMETER ServerInstance
    The hostname of SQL server instance.

    .PARAMETER DatabaseName
    The database to run the SQL script in.

    .PARAMETER Timeout
    The timeout in seconds for the SQL script.

    .PARAMETER Arguments
    A List of the variables passed to the SQL script.
    The format is key 'key1 = "valueA"', 'key2 = "valueB"'.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$false)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName,

        [Parameter(Mandatory=$false)]
        [ValidateNotNullOrEmpty()]
        [int] $Timeout = 7200,

        [Parameter(Mandatory=$false)]
        [string[]] $Arguments = @()
    )

    [string] $scriptName = $( ( Get-Item $Path ).Name )
    Write-ToLogFile "Invoke-SqlCmd: '$scriptName' on [$ServerInstance].[$DatabaseName]."

    #endregion
    #region Prepare arguments

    [string] $scriptArguments = [string]::Join(" ", $Arguments)
    if ( $scriptArguments )
    {
        [string] $scriptArguments = "-v $scriptArguments"
    }

    if ( $DatabaseName )
    {
        [string] $scriptDatabase = "-d $DatabaseName"
    }

    if ( $Timeout )
    {
        [string] $scriptTimeout = "-t $( $Timeout -as 'string' )"
    }

    if ( $ServerInstance )
    {
        [string] $scriptServerInstance = "-S $ServerInstance"
    }

    if ( $Path )
    {
        [string] $scriptInput = "-i $( ( Get-item $Path ).FullName )"
    }

    [string] $errorLevel = "-m-1"
    [string] $redirectErrors = "-r1"
    [string] $abortOnError = "-b"
    [string] $abortErrorLevel = "-V 1"

    #endregion
    #region Prepare process

    [string[]] $usedArguments = @( $scriptInput, $scriptServerInstance, $scriptDatabase, $abortOnError, $scriptTimeout, $errorLevel, $abortErrorLevel, $redirectErrors, $scriptArguments ) | Where-Object { $_ }

    $processInfo = New-Object System.Diagnostics.ProcessStartInfo
    $processInfo.FileName = "sqlcmd"
    $processInfo.RedirectStandardError = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.Arguments = [string]::Join(" ", $usedArguments )

    #endregion
    #region Start process
    Write-ToLogFile "Invoke-SqlCmd: '$scriptName': $( $processInfo.FileName ) $( $processInfo.Arguments )"
    Write-Output "sqlcmd $scriptName"

    $outputBuffer = New-Object System.Text.StringBuilder
    $errorBuffer = New-Object System.Text.StringBuilder

    $sScripBlock = {
        if (! [String]::IsNullOrEmpty($EventArgs.Data)) {
            $Event.MessageData.AppendLine($EventArgs.Data)
        }
    }

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $processInfo

    $outputEvent = Register-ObjectEvent -InputObject $process `
        -Action $sScripBlock -EventName 'OutputDataReceived' `
        -MessageData $outputBuffer

    $errorEvent = Register-ObjectEvent -InputObject $process `
        -Action $sScripBlock -EventName 'ErrorDataReceived' `
        -MessageData $errorBuffer

    $process.Start() | Out-Null
    $process.BeginOutputReadLine();
    $process.BeginErrorReadLine();

    $timeoutMS = ($Timeout + 5 ) * 1000
    if ( $process.WaitForExit( $timeoutMS ))
    {
        $returnCode = $process.ExitCode
    } elseif ( $process.HasExited )
    {
        $returnCode = $process.ExitCode
    }
    else
    {
        Write-ToLogFile "Invoke-SqlCmd: Timeout $Timeout reached."
        $process.Kill()
        $returnCode = -1
    }

    Unregister-Event -SourceIdentifier $outputEvent.Name
    Unregister-Event -SourceIdentifier $errorEvent.Name

    $standardOutput = $outputBuffer.ToString().Trim()
    $standardError = $errorBuffer.ToString().Trim()

    $process.Close() | Out-Null

    Write-ToLogFile "Invoke-SqlCmd: '$scriptName' Output $( $standardOutput.Length ) chars: $standardOutput"
    Write-ToLogFile "Invoke-SqlCmd: '$scriptName' Error $( $standardError.Length ) chars: $standardError"

    if ( $standardError.EndsWith('Timeout expired') ) {
        Write-ToLogFile "Invoke-SqlCmd: Timeout $Timeout reached."
        $returnCode = -1
    }

    if ( $returnCode -ne 0 )
    {
        throw "sqlcmd exit code $returnCode; err: '$standardError'."
    }

    #endregion
}
