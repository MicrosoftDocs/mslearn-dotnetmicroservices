function Get-AraMasterKey
{
    <#

    .SYNOPSIS
    Loads the master key from the ARA configuration

    .PARAMETER AraXmlPath
    The path to the ara configuration

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $AraXmlPath
    )


    if ( ( Test-Path -Path $AraXmlPath ) -eq $false ) {
        throw "$AraXmlPath not found."
    }

    $araNode = ( Select-XmlWithEntities -Path $AraXmlPath -XPath "//ARA" ).Node

    if ( $araNode -eq $null ) {
        throw "Missing ARA node in $AraXmlPath"
    }
    elseif ( $araNode.masterKey -eq '%%MASTER_KEY%%' ) {
        throw "The masterkey placeholder was not replaced."
    }
    elseif ( -not ( $araNode.masterKey )) {
        Write-ToLogfile "There is no master key in ARA.xml" -Level 'WARNING'
    }
    else {
        ConvertTo-ByteArray -Hex $araNode.masterKey
    }
}