function Export-Subscription
{
    <#

    .SYNOPSIS
    Exports a subscription object as XML file.

    .PARAMETER Subscription
    A subscription object.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        $Subscription
    )

@"
<subscription>
    <schedule>
        $( $Subscription.Schedule )
    </schedule>
    <sqlQuery>
        $( $Subscription.SqlQuery )
    </sqlQuery>
    <database>
        $( $Subscription.Database )
    </database>
    <reportParameters>
        $( foreach ( $parameter in $Subscription.ReportParameters ) {
            "`n"
            if ( $parameter.Reference ) {
"        <parameter><name>$( $parameter.Name )</name><reference>$( $parameter.Reference )</reference></parameter>"
            } else {
"        <parameter><name>$( $parameter.Name )</name><value>$( [System.Web.HttpUtility]::HtmlEncode($parameter.Value) )</value></parameter>"
        }
     })
    </reportParameters>
    <destinationParameters>
    $( foreach ( $parameter in $Subscription.DestinationParameters ) {
        "`n"
        if ( $parameter.Reference ) {
"        <parameter><name>$( $parameter.Name )</name><reference>$( $parameter.Reference )</reference></parameter>"
        } else {
"        <parameter><name>$( $parameter.Name )</name><value>$( [System.Web.HttpUtility]::HtmlEncode($parameter.Value) )</value></parameter>"
    }
 })
    </destinationParameters>
</subscription>
"@ > "$( $Subscription.Report ).subscription.xml"

}