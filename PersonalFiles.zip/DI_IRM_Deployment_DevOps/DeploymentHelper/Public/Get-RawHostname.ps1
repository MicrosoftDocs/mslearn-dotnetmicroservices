function Get-RawHostname
{
    <#

    .SYNOPSIS
    Resolves the hostname of a machine by a hostname alias.

    .PARAMETER Hostname
    Specifies the hostname of the machine.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Hostname,

        [switch] $HostOnly
    )

    $rawHostname = ( ( nslookup $Hostname ) -split 0x0D, 0x0A | Where-Object { $_.startswith('Name:') }).Replace('Name:', '').Trim()

    if ( $HostOnly ) {
        [string] $host, $domain = $rawHostname -split '\.', 2
        $host | Write-Output
    } else {
        $rawHostname | Write-Output
    }
}