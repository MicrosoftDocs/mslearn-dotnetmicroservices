function ConvertTo-XmlFileConfig {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true )]
        [System.Xml.XmlNode] $Node
    )

    process
    {
        # add file fields
        $xmlFile = New-Object DeploymentHelper.Config.XmlFile -Property @{
            Path = $Node.Attributes['path'].Value
            Changes = New-Object System.Collections.Generic.List[DeploymentHelper.Config.XmlChange]
            Namespace = New-Object System.Collections.Generic.List[DeploymentHelper.Config.XmlNamespace]
        }

        # add namespaces
        foreach ( $namespaceXml in Select-Xml -Xml $Node -XPath './namespace' )
        {
            $xmlNamespace = New-Object DeploymentHelper.Config.XmlNamespace -Property @{
                Name = $namespaceXml.Node.Attributes['name'].Value
                Value = $namespaceXml.Node.Attributes['value'].Value
            }

            $xmlFile.Namespace.Add( $xmlNamespace )
        }

        # add changes
        foreach ( $changeXml in Select-Xml -Xml $Node -XPath './change' )
        {
            $change = New-Object DeploymentHelper.Config.XmlChange -Property @{
                Operation = $changeXml.Node.Attributes['operation'].Value
                XPath = $changeXml.Node.Attributes['xpath'].Value
                Attribute = $changeXml.Node.Attributes['attribute'].Value
                Value = $changeXml.Node.Attributes['value'].Value
            }

            $xmlFile.Changes.Add( $change )
        }

        Write-Output $xmlFile
    }
}
