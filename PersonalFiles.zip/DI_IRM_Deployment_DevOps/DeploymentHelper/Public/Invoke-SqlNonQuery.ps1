function Invoke-SqlNonQuery
{
    <#

    .SYNOPSIS
    Executes a SQL statement withouth expecting a dataset as result.

    .PARAMETER ServerInstance
    Hostname to the SQL Server (database of the report server).

    .PARAMETER Database
    The name of the reportserver's database.

    .PARAMETER SqlCommand
    The SQL statement that needs to be selected.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Database,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $SqlCommand,

        [int] $ExpectedReturn = $null
    )

    $connectionString = "Data Source=$ServerInstance; Integrated Security=SSPI; Initial Catalog=$Database"

    $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
    $connection.Open()

    try {
        $command = New-Object System.Data.SqlClient.SqlCommand($SqlCommand, $connection)

        Write-ToLogFile "Execute as '$( whoami )' to '$ServerInstance':'$Database':"
        Write-ToLogFile $SqlCommand

        [int] $rows = $command.ExecuteNonQuery()
    }
    finally {
        $connection.Close()
    }

    if ( $ExpectedReturn -ne $null ) {
        Write-ToLogFile "Affected '$( $rows )' rows."
    } elseif ( $rows -ne $ExpectedReturn ) {
        throw "Unexpected return value '$rows' instead of '$ExpectedReturn'."
    } else {
        Write-ToLogFile "Return '$( $rows )' was expected."
    }
}
