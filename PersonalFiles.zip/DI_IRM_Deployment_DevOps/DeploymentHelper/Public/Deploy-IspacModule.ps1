function Deploy-IspacModule
{
    <#

    .SYNOPSIS
    Builds a IspacModule based on the SSIS Projects in the solution directory.

    .PARAMETER SourceDirectories
    The path to the directory that should contain the artifacts, that should be packed as artifact.

    .PARAMETER DeploymentHelperPath
    The path to the directory that have all helper scripts for deployment.

    .PARAMETER Name
    The name of the module.

    .PARAMETER ConfigNode
    The XML node of the deployment configuration of that module.

    .PARAMETER ProjectName
    The name of project component.

    .PARAMETER Environment
    Deployment Environment

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceDirectories,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $DeploymentHelperPath,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Name,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement]
        $ConfigNode,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProjectName,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Environment
    )

    $ErrorActionPreference = 'Stop'

    $solutionName = $ProjectName + '_' + $Name
    $logpath = "$SourceDirectories\Log\$solutionName"

    $ispacs = Get-ChildItem -Path $SourceDirectories -include ('*.ispac') -recurse #-Filter *.zip,.xml

    foreach ($ispac in $ispacs) {
        $ispacFilePath = $ispac
   

   Write-Verbose "Ispac file path is $ispacFilePath"

    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//add[@env='$Environment']"


    $requiredProjects | ForEach-Object {
        $serverName = $_.Node.Attributes['value'].Value
        #$solutionName = $ProjectName + '_' + $Name
        #$logpath = "$SourceDirectories\Log\$solutionName"

        if (!(Test-Path -path $logpath)) 
        {
            New-Item $logpath -Type Directory
            write-verbose "Log Path $logpath is created"
            Set-Logfile "$logpath\Parameters.log"
            Write-ToLogfile "ProjectName '$ProjectName' and Module Name '$Name'." 
            Write-ToLogfile "solutionName'$solutionName'"
            Write-ToLogfile "solutionName'$ispacFilePath'" 
        }
		else
		{
			Set-Logfile "$logpath\Parameters.log"
            Write-ToLogfile "ProjectName '$ProjectName' and Module Name '$Name'." 
            Write-ToLogfile "solutionName'$solutionName'"
            Write-ToLogfile "solutionName'$ispacFilePath'" 
		}
        try {
            . "$SourceDirectories\$solutionName\deploy_ispac.ps1" `
                    -Environment $Environment `
                    -AraXmlPath "$SourceDirectories\ARA.xml" `
                    -ServerInstance $serverName `
                    -CatalogFolderName "DI_IRM" `
                    -IspacPath $ispacFilePath `
                    -DeploymentHelperPath $DeploymentHelperPath `
                    -LogfilePath "$logpath\deploy_ispac.log" 
			}
        catch {
            Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
            throw
			}

		}
	}

}