function Get-Subscriptions
{
    <#

    .SYNOPSIS
    Exports subscriptions from the report server database.

    .PARAMETER ServerInstance
    Specifies the name of the sql server instance.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance
    )

    [System.Data.DataTable] $subscriptionData = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "ReportServer" -SqlCommand @"
SELECT
    ReportName = Catalog.Name,
	SubscriptionName = Subscriptions.Description,
	Subscriptions.MatchData,
	Subscriptions.DataSettings,
	Subscriptions.Parameters,
	Subscriptions.ExtensionSettings
FROM ReportServer..Subscriptions
JOIN ReportServer..Catalog ON Catalog.ItemID = Subscriptions.Report_OID
WHERE InactiveFlags = 0
"@

    $subscriptionData | ForEach-Object { Convert-ToSubscription -Row $_ }

}
