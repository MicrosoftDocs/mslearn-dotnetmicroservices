function New-DatabaseVersion {

    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int] $Version
    )

    Invoke-SqlNonQuery `
        -ServerInstance $ServerInstance `
        -Database 'DI_IRM_Maintenance' `
        -SqlCommand "INSERT INTO migration.Version (DatabaseName, Version) VALUES ('$DatabaseName', '$( $Version )')" `
        -ExpectedReturn 1
}
