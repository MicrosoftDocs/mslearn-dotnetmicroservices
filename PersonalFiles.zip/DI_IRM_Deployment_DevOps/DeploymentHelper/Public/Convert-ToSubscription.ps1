function Convert-ToSubscription
{
    <#

    .SYNOPSIS
    Converts a subscriptions dataset row to a subscription object.

    .PARAMETER Row
    A row from a database query

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [System.Data.DataRow]
        $Row
    )

    $name = $Row.SubscriptionName
    $report = $Row.ReportName

    Write-Verbose "Export subscription [$name] of report [$report]"

    $schedule = $Row.MatchData
    $sqlQuery = ( Select-Xml -Content $Row.DataSettings -XPath "//CommandText" ).Node.InnerText
    $database = "DATABASE"
    $reportParameters = Select-Xml -Content $Row.Parameters -XPath "//ParameterValue" | ForEach-Object {
        New-Object -Type PsObject -Property @{
            Name = $_.Node.Name;
            Reference = $_.Node.Field;
            Value = $_.Node.Value;
        }
    }
    $destinationParameters = Select-Xml -Content $Row.ExtensionSettings -XPath "//ParameterValue" | ForEach-Object {
        New-Object -Type PsObject -Property @{
            Name = $_.Node.Name;
            Reference = $_.Node.Field;
            Value = $_.Node.Value;
        }
    }

    New-Object -Type PsObject -Property @{
        Name = $name
        Report = $report
        Schedule = $schedule;
        SqlQuery = $sqlQuery;
        Database = $database;
        ReportParameters = $reportParameters;
        DestinationParameters = $destinationParameters;
    }

}