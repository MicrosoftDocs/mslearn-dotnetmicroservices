function Set-ParameterValues {

    [CmdletBinding()]
    param (
        [Parameter(
            Position=0,
            Mandatory=$true,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true)
        ]
        [string] $Value,

        [Parameter( Mandatory = $true )]
        [hashtable] $Parameter
    )

    process {
        $Parameter.GetEnumerator() |
        ForEach-Object {
            $Value = $Value.Replace( '$(' + $_.Key + ')', $_.Value )
        }

        Write-Output $Value
    }

}