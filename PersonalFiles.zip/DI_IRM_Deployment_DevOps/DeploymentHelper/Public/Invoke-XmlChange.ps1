function Invoke-XmlChange {

    [CmdletBinding()]
    param(

        [Parameter( Mandatory = $true )]
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [string] $Path,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateSet('insert', 'update', 'delete')]
        [string] $Operation,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $XPath,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [string] $Attribute,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [string] $Value,

        [Parameter( Mandatory = $false )]
        [hashtable] $Namespace
    )

    process {

        switch ( $Operation ) {
            update {
                Write-ToLogfile "Update '$XPath'."
                if ($Namespace.Count -gt 0) {
                    $nodes = Select-Xml -Path $Path -XPath $XPath -Namespace $Namespace
                } else {
                    $nodes = Select-Xml -Path $Path -XPath $XPath
                }

                if ( -not $nodes ) {
                    throw "XPath '$XPath' not found in '$Path'"
                }
                $nodes | ForEach-Object {
                    if ( $Attribute ) {
                        Write-ToLogfile "Set '$Attribute' = '$Value'"
                        $_.Node.Attributes[$Attribute].Value = $Value
                    } else {
                        Write-ToLogfile "Set '$Value'"
                        $_.Node.InnerXml = $Value
                    }
                    $_.Node.OwnerDocument.Save($Path)
                }
            }
            insert {
                Write-ToLogfile "Insert '$XPath'."
                if ($Namespace.Count -gt 0) {
                    $nodes = Select-Xml -Path $Path -XPath $XPath -Namespace $Namespace
                } else {
                    $nodes = Select-Xml -Path $Path -XPath $XPath
                }
                if ( -not $nodes ) {
                    throw "XPath '$XPath' not found in '$Path'"
                }
                $nodes | ForEach-Object {
                    Write-ToLogfile "Add '$Value'"
                    $document = $_.Node.OwnerDocument
                    $_.Node.AppendChild( $document.ImportNode( ( [xml] $Value ).FirstChild, $true ) ) | Out-Null
                    $_.Node.InnerXml = $_.Node.InnerXml.Replace(' xmlns=""', '')
                    $document.Save( $Path )
                }
            }
            delete {
                Write-ToLogfile "Delete '$XPath'."
                if ($Namespace.Count -gt 0) {
                    $nodes = Select-Xml -Path $Path -XPath $XPath -Namespace $Namespace
                } else {
                    $nodes = Select-Xml -Path $Path -XPath $XPath
                }
                if ( -not $nodes ) {
                    Write-ToLogfile "XPath '$XPath' not found in '$Path'"
                } else {
                    $nodes | ForEach-Object {
                        Write-ToLogfile "Delete"
                        $_.Node.ParentNode.RemoveChild($_.Node) | Out-Null
                        $_.Node.OwnerDocument.Save($Path)
                    }
                }
            }
            default {
                throw "xml operation '$_' is not implemented."
            }
        }
    }
}
