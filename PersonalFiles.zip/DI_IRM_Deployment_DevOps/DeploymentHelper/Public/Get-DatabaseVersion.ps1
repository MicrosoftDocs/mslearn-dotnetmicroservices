function Get-DatabaseVersion {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName
    )

    [System.Data.DataTable] $status = Invoke-SqlQuery `
        -ServerInstance $ServerInstance `
        -Database 'DI_IRM_Maintenance' `
        -SqlCommand "SELECT ISNULL(MAX(Version), -1) AS Version FROM migration.Version WHERE DatabaseName = '$DatabaseName'"
    [int] $databaseVersion = $status.Version

    Write-Output $databaseVersion
}
