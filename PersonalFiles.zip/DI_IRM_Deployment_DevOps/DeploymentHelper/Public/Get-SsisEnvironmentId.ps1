function Get-SsisEnvironmentId {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Name
    )

    Write-Verbose "Export job steps for '$Name' from '$ServerInstance'."

    [System.Data.DataTable] $environmentData = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "SSISDB" -SqlCommand @"
SELECT
    [Reference_ID]
FROM
	internal.environment_references
WHERE
    [Environment_Name] = '$Name'
"@

    ( $environmentData | Select-Object -First 1 )[0] | Write-Output
}
