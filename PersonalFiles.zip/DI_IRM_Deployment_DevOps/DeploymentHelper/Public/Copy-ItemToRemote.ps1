function Copy-ItemToRemote
{
    <#

    .SYNOPSIS
    Copies a file to a remote machine

    .PARAMETER ServerInstance
    Specifies the name of the remote machine.

    .PARAMETER LocalPath
    Specifies the path to the local file.

    .PARAMETER RemotePath
    Specifies the path on the remove machine.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [Alias("FullName")]
        [string]
        $LocalPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]
        $RemotePath
    )

    # create session
    $remoteSession = New-PSSession -ComputerName ( Get-RawHostname $ServerInstance )

    # create path
    Invoke-Command -ComputerName ( Get-RawHostname $ServerInstance ) -ScriptBlock {
        [CmdletBinding()]
        param(
            [string] $RemotePath
        )
        New-Item -Type Directory -Path $RemotePath -Force | Out-Null
    } -ArgumentList $RemotePath

    # copy item
    Write-ToLogfile "Copy '$LocalPath' to '$RemotePath'"
    Copy-Item -Path $LocalPath -Destination $RemotePath -ToSession $remoteSession -Recurse -Force
}
