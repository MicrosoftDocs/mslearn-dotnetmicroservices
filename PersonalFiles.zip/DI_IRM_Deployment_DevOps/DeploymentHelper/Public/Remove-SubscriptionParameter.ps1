function Remove-SubscriptionParameter
{
    <#

    .SYNOPSIS
    Removes certain parameters from a ssrs subscription.

    .PARAMETER Subscription
    Specifies the subscription.

    .PARAMETER DestinationParameters
    Specifies the destination parameters to be removed.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        $Subscription,

        [Parameter(Mandatory=$false)]
        [string[]]
        $DestinationParameters = @()
    )

    foreach ( $parameter in $DestinationParameters )
    {
        $Subscription.DestinationParameters = $Subscription.DestinationParameters | Where-Object Name -ne $parameter
    }

    $Subscription
}