function New-SecurePassword
{
    <#

    .SYNOPSIS
    Encrypts a password using a master key.

    .PARAMETER Password
    Specifies the plain password as string.

    .PARAMETER MasterKey
    Specifies the master key as string.

    .Example

    Import-Module "$( $ENV:USERPROFILE )\Source\Workspaces\DI_IRM\Main\DI_IRM_Deployment\DeploymentHelper\DeploymentHelper.psm1"

    New-SecurePassword

    #>

    [CmdletBinding()]
    param(
        [Parameter(mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Password,

        [Parameter(mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $MasterHex
    )

    [byte[]] $masterKey = ConvertTo-ByteArray -Hex $MasterHex
    [string] $securePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force |
        ConvertFrom-SecureString -Key $masterKey |
        Out-String

    $securePassword
}
