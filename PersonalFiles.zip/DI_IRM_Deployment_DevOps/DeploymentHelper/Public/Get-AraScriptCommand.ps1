function Get-AraScriptCommand
{
    <#

    .SYNOPSIS
    Loads the script configuration node from the ara configuration.

    .PARAMETER AraXmlPath
    The path to the ara configuration

    .PARAMETER ProjectName
    Specifies the project name

    .PARAMETER Environment
    Specifies the envionment name

    .PARAMETER ScriptFolderName
    Specifies the name to the script folder

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $AraXmlPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProjectName,

        [Parameter(Mandatory=$false)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ModuleName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Environment,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderName
    )

    Write-ToLogfile "ARA: ProjectName:'$ProjectName' Environment:'$Environment' ScriptFolderName:'$ScriptFolderName'"

    $xPath = @("//project[@name=""$ProjectName""]")
    if ( $ModuleName ) {
        $xPath = $xPath + "//module[@name=""$ModuleName""]"
    }
    $xPath = $xPath + "//environment[@name=""$Environment""]"
    $xPath = $xPath + "//scriptcommand[@scriptfolder=""$ScriptFolderName""]"

    $xPath = $xPath -join ''

    $scriptCommand = ( Select-XmlWithEntities -Path $AraXmlPath -XPath $xPath ).Node

    if ( $scriptCommand -eq $null ) {
        throw "Missing scriptcommand for $xPath"
    }

    Write-Output $scriptCommand
}
