function Set-Logfile {

    param (
        [ValidateNotNullOrEmpty()]
        [string]
        $LogfilePath
    )

    $global:LogfilePath = $LogfilePath
}
