function Set-DatabaseVersionMigrated {

    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int] $Version
    )

    Invoke-SqlNonQuery `
        -ServerInstance $ServerInstance `
        -Database 'DI_IRM_Maintenance' `
        -SqlCommand "UPDATE migration.Version SET MigrationFinished = GETDATE() WHERE DatabaseName = '$DatabaseName' AND Version = '$Version'" `
        -ExpectedReturn 1
}
