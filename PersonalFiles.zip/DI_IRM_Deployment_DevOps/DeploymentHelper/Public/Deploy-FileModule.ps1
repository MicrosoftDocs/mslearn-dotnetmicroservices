function Deploy-FileModule
{
    <#

    .SYNOPSIS
    Builds a FileModule based on a Powershell Project in the solution directory.

    .PARAMETER SourceDirectories
    The list of directories that may contain the required projects.

    .PARAMETER DeploymentHelperPath
    The path to the directory that have all helper scripts for deployment.

    .PARAMETER Name
    The name of the module.

    .PARAMETER ConfigNode
    The XML node of the deployment configuration of that module.

    .PARAMETER ProjectName
    The name of project component.

    .PARAMETER Environment
    Deployment Environment

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceDirectories,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Name,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $DeploymentHelperPath,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [Xml.XmlElement]
        $ConfigNode,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProjectName,

        [Parameter(mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Environment

    )

    $ErrorActionPreference = 'Stop'
    
    $solutionName = $ProjectName + '_' + $Name
    $logpath = "$SourceDirectories\Log\$solutionName"

    if (!(Test-Path -path $logpath)) 
    {
        New-Item $logpath -Type Directory
        write-verbose "Log Path $logpath is created"
    }
    Set-Logfile "$logpath\deploy_files.log"

    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//add[@env='$Environment']" | ForEach-Object {
        $RemotePath = $_.Node.Attributes['value'].Value
    }
    
    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//set[@env='$Environment']" | ForEach-Object {
        $ServerInstance = $_.Node.Attributes['value'].Value
    }

    $requiredProjects = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$Name']//set[@key='Directory']" | Select -Unique | ForEach-Object {
        $Directory = $_.Node.Attributes['value'].Value
    }

    Write-ToLogfile "RemotePath is '$RemotePath', ServerInstance is to '$ServerInstance', Directory is '$Directory'"

        # create session
        $remoteSession = New-PSSession -ComputerName ( Get-RawHostname $ServerInstance )

        # create path
        Invoke-Command -ComputerName ( Get-RawHostname $ServerInstance ) -ScriptBlock {
            [CmdletBinding()]
            param(
                [string] $RemotePath
            )
            New-Item -Type Directory -Path $RemotePath -Force | Out-Null
        } -ArgumentList $RemotePath

        $solutionPath = "$SourceDirectories\$ProjectName" + '_' + $Name
        Get-ChildItem -Path $solutionPath | ForEach-Object {
            $solutionPath = "$SourceDirectories\$ProjectName" + '_' + $Name + "\$_"
            # copy item
            Write-ToLogfile "Copy '$solutionPath' to '$RemotePath'"

            if ($RemotePath.Substring(0,5)-eq "\\fxx")
            {
                Copy-Item -Path $solutionPath -Destination $RemotePath -Recurse -Force
            }
            else 
            {
                Copy-Item -Path $solutionPath -Destination $RemotePath -ToSession $remoteSession -Recurse -Force
            }
            
        }

        
}