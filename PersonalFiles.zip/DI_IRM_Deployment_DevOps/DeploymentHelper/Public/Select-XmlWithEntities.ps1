function Select-XmlWithEntities
{
    <#

    .SYNOPSIS
    Wraps Select-XML without checking MaxCharactersFromEntities.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $XPath
    )

    $xmlFile = New-Object System.Xml.XmlDocument
    $xmlFile.XmlResolver = $null
    $xmlFile.Load($Path)

    Select-Xml -Xml $xmlFile -XPath $XPath
}