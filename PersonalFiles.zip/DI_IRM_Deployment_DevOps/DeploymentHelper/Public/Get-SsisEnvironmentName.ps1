function Get-SsisEnvironmentName
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]
        $Id
    )

    Write-Verbose "Export job steps for '$Name' from '$ServerInstance'."

    [System.Data.DataTable] $environmentData = Invoke-SqlQuery -ServerInstance $ServerInstance -Database "SSISDB" -SqlCommand @"
SELECT
    [Name] = [Environment_Name]
FROM
	internal.environment_references
WHERE
    [Reference_ID] = $Id
"@

    ( $environmentData | Select-Object -First 1 )[0] | Write-Output
}
