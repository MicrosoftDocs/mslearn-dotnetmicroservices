function Invoke-SqlQuery
{
    <#

    .SYNOPSIS
    Reads a dataset from a SQL Server database using a SQL statement.

    .PARAMETER ServerInstance
    Hostname to the SQL Server (database of the report server).

    .PARAMETER Database
    The name of the reportserver's database.

    .PARAMETER SqlCommand
    The SQL statement that needs to be selected.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Database,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $SqlCommand
    )

    $connectionString = "Data Source=$ServerInstance; Integrated Security=SSPI; Initial Catalog=$Database"

    $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
    $connection.Open()

    try {
        $command = New-Object System.Data.SqlClient.SqlCommand($SqlCommand, $connection)
        $command.CommandTimeout = 120;

        Write-ToLogFile "Execute as '$( whoami )' to '$ServerInstance':'$Database':"
        Write-ToLogFile $SqlCommand

        $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command
        #$adapter.SelectCommand.CommandTimeout=120
        $dataset = New-Object System.Data.DataSet
        $adapter.Fill($dataSet) | Out-Null
    }
    finally {
        $connection.Close()
    }

    Write-Output $dataSet.Tables

}
