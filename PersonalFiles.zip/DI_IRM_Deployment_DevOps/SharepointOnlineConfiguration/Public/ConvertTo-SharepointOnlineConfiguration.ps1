function ConvertTo-SharepointOnlineConfiguration {

    <#

    .SYNOPSIS
    Convert XML to Deployment Config

    .DESCRIPTION

    The XML configuration will be converted to a .NET object, that can be used to parameterize `Invoke-SharepointOnlineConfiguration`.

    .PARAMETER Node
    The XML node that contains the configuration infromation.

    .OUTPUTS
    SharepointOnlineConfiguration.Config.Deployment

    #>

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true )]
        [System.Xml.XmlNode] $Node
    )

    process {
        $config = New-Object SharepointOnlineConfiguration.Config.Deployment -Property @{
            ServerInstance = $Node.Attributes['serverInstance'].Value
            ScriptDirectory = $Node.Attributes['scriptDirectory'].Value
            SharepointUsername = $Node.Attributes['sharepointUsername'].Value
            SharepointPassword = $Node.Attributes['sharepointPassword'].Value
            ServiceUsername = $Node.Attributes['serviceUsername'].Value
            ServicePassword = $Node.Attributes['servicePassword'].Value
        }
        $config | Write-Output
    }
}
