function Invoke-SharepointOnlineConfiguration
{
    [CmdletBinding()]
    param(

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ScriptDirectory,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $SharepointUsername,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $SharepointPassword,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServiceUsername,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServicePassword
    )

    Write-ToLogfile "Connect to [$ServerInstance] as [$ServiceUsername] using '$ServicePassword'."

    $credential = New-Object `
        -TypeName System.Management.Automation.PSCredential `
        -ArgumentList $ServiceUsername, ( ConvertTo-SecureString $ServicePassword -AsPlainText -Force )

    Invoke-Command `
        -ComputerName $ServerInstance `
        -Credential $credential `
        -ScriptBlock {

        param(
            [Parameter(Mandatory=$true)]
            [ValidateNotNullOrEmpty()]
            [string] $ScriptDirectory,

            [Parameter(Mandatory=$true)]
            [ValidateNotNullOrEmpty()]
            [string] $SharepointUsername,

            [Parameter(Mandatory=$true)]
            [ValidateNotNullOrEmpty()]
            [string] $SharepointPassword
        )

        New-Object System.Management.Automation.PSCredential(
            $SharepointUsername,
            ( ConvertTo-SecureString $SharepointPassword -AsPlainText -Force )
        ) | Export-CliXml -Path "$ScriptDirectory\SPOCredentials.pwd"

    } -ArgumentList @(
        $ScriptDirectory,
        $SharepointUsername,
        $SharepointPassword
    )

}
