using System.Collections.Generic;

namespace SharepointOnlineConfiguration.Config
{
    public class Deployment
    {
        public string ServerInstance { get; set; }
        public string ScriptDirectory { get; set; }
        public string SharepointUsername { get; set; }
        public string SharepointPassword { get; set; }
        public string ServiceUsername { get; set; }
        public string ServicePassword { get; set; }
    }
}
