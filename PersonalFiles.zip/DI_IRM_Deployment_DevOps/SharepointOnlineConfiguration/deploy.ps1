﻿<#

    .SYNOPSIS
    Deploy Sharepoint Online sharepoints

    .NOTES
    Date:       2018-04-16
    Author:     Steffen Kampmann
    Version:    1.0

    .PARAMETER ProjectName
    The project of the sql script.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER Environment
    The environment in which the script needs to be executed.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER AraXmlPath
    Path to the ARA.xml .
    If not definied, it is ../ARA.xml

    .PARAMETER DeplyomentHelperPath
    Path to the Powershell functions of DeploymentHelper.

    .PARAMETER LogfilePath
    Path to the logfile of this script

#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_sql.log"
)

$ErrorActionPreference = 'Stop'

Import-Module $DeploymentHelperPath
Import-Module ( Join-Path $PSScriptRoot 'SharepointOnlineConfiguration.psd1' )

Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

try {
    Get-AraScriptCommand `
        -AraXmlPath $AraXmlPath `
        -ProjectName $ProjectName `
        -Environment $Environment `
        -ScriptFolderName $ScriptFolderName `
        -ModuleName $ModuleName |
    ConvertTo-SharepointOnlineConfiguration |
    Invoke-SharepointOnlineConfiguration
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message $_.Exception
    throw
}

#endregion
