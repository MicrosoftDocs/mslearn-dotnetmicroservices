﻿[CmdletBinding()]
param(
    [string]$Path="\\fxx0004\mrdata3\DI_IRM\TST\CDSMarkit\Export\Data_for_Financing_Deals_20220616"
    )

    Import-Module 'C:\Program Files\WindowsPowerShell\Modules\ImportExcel\7.0.1\ImportExcel.psd1'

$SourcePath = $Path +".xlsx"
$TargetPath = $Path +".xlsm"

Import-Excel -Path $SourcePath -NoHeader -WorksheetName "Financials" | 
     Export-Excel -Path $TargetPath  -NoHeader -WorkSheetname "Financials" 

Import-Excel -Path $SourcePath -NoHeader -WorksheetName "Sovereigns" | 
     Export-Excel -Path $TargetPath  -NoHeader -WorkSheetname "Sovereigns" 
