param([string]$orgSiteUrl,
        [string]$listDisplayName,
        [string]$lookupColumStatus,
        [int]$itemID,
        [int]$processStatusId,
        [string]$colLogfile,
        [string]$logUrl,
        [string]$dllPath,
	[string]$database_instance="SQLDEVDIIRM.cloud.munichre.com",
    [string]$database_name="DI_IRM_CreditRisk_Input",
    [string]$logging_table="[dbo].[Logging]",
    [int]$FK_JobIteration=1,
    [int]$FK_Run=30,
    [string]$Package="DI_IRM_CreditRisk_Input",
	[string]$JobStep="Test_PowerShell",
    [string]$CreatedBy)

#https://collab-vs.dev.munich.munichre.com/sites/S0000330/MaCrRi/CrRi/Lists/RUNs/AllItems.aspx

#Import the required DLL
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.Runtime.dll"

function writeSQLLog(
 #   [string]$database_instance,
 #   [string]$database_name,
 #   [string]$logging_table,
 #   [int]$FK_JobIteration,
 #   [int]$FK_Run,
 #   [string]$Package,
 #   [string]$JobStep,
 #   [string]$CreatedBy,
    [string]$Type,
    [string]$Msg
)
{
    $conn = New-Object System.Data.SqlClient.SqlConnection
    $conn.ConnectionString = "Data Source=$database_instance;Initial Catalog=$database_name;Integrated Security=SSPI;"
    $conn.Open()

    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.connection = $conn

    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$Msg',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"

    $cmd.CommandText=$insertStmt
    $retval=$cmd.executenonquery()
    $conn.close()
}

#function writeStatus(
#    [string]$orgSiteUrl,
#    [string]$listDisplayName,
#    [string]$lookupColumStatus,
#    [int]$itemID,
#    [int]$processStatusId,
#    [string]$colLogfile,
#    [string]$logUrl
#)
#{
    #$UserName = 'someDomain\someUser'
    #$SecurePassword = "somePassword" | ConvertTo-SecureString -AsPlainText -Force

    #Write-Host "Script running with following account : "$UserName -ForegroundColor Yellow

	writeSqlLog -Type:"OnPreExecute" -Msg:"orgSiteUrl: $orgSiteUrl"
	writeSqlLog -Type:"OnPreExecute" -Msg:"listDisplayName: $listDisplayName"
	writeSqlLog -Type:"OnPreExecute" -Msg:"lookupColumStatus: $lookupColumStatus"
	writeSqlLog -Type:"OnPreExecute" -Msg:"itemID: $itemID"
	writeSqlLog -Type:"OnPreExecute" -Msg:"processStatusId: $processStatusId"
	writeSqlLog -Type:"OnPreExecute" -Msg:"colLogfile: $colLogfile"
	writeSqlLog -Type:"OnPreExecute" -Msg:"logUrl: $logUrl"

	try
	{

        # Get the Client Context and Bind the Site Collection
        $ClientContext = New-Object Microsoft.SharePoint.Client.ClientContext($orgSiteUrl)

        # Connect to source site
        #$credentials = New-Object System.Net.NetworkCredential($UserName, $SecurePassword)
        #$ClientContext.Credentials = $credentials
        $web = $ClientContext.Web
        $ClientContext.Load($web)
        $ClientContext.ExecuteQuery()

        # Get List and List Items
        $List = $web.Lists.GetByTitle($listDisplayName)
        $ListItems = $List.GetItems([Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery())
        $ClientContext.Load($List)
        $ClientContext.Load($ListItems)
        $ClientContext.ExecuteQuery()

        if($ListItems.Count -eq 0)
        {
            Write-Host "No items for processing."
            return
        }

        $item=$ListItems.GetById($itemID)
        $ClientContext.Load($item)
        $ClientContext.ExecuteQuery()

        #Process_Status
        $lup = $item.Item($lookupColumStatus)
        if($lup -eq $null)
        {
            $lup= New-Object Microsoft.SharePoint.Client.FieldLookupValue
        }
        $lup.LookupId=$processStatusId
        $item.Item($lookupColumStatus)=$lup
        ##$item.Update()
        ##$ClientContext.ExecuteQuery()

        #Logfile
        $logColumn = $item.Item($colLogfile)
        if($logColumn -eq $null)
        {
            $logColumn= New-Object Microsoft.SharePoint.Client.FieldUrlValue
        }
        $logColumn.Description="LogFile"
        $logColumn.Url=$logUrl
        $item.Item($colLogfile)=$logColumn
        $item.Update()
        $ClientContext.ExecuteQuery()
	}
	catch
	{
        Write-Host "Error occured: $($_.Exception)"
		writeSqlLog -Type:"OnError" -Msg:"$($_.Exception)"
        return -1
	}

#}

#$orgSiteUrl2 = "https://collab-vs.dev.munich.munichre.com/sites/S0000330/MaCrRi/CrRi/"

#writeStatus -orgSiteUrl:$orgSiteUrl2 -listDisplayName:"RUNs" -itemID:5 -lookupColumStatus:"Process_Status" -processStatusId:4 -colLogfile:"LogFile" -logUrl:"http://www2.munichre.com"
