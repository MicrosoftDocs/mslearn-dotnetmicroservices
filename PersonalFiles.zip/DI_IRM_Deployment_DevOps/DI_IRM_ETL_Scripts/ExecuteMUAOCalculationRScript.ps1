﻿<#

.SYNOPSIS
To execute R scripts for MUAO calculation

.PARAMETER BasePath
Base path where R scripts exist such as "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00128"

#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $BasePath

)

#execute R script for ERGO results
. "C:\Program Files\R\R-4.1.0\bin\Rscript.exe" "$BasePath\RUN_Group.R"

#execute R script for Group results
. "C:\Program Files\R\R-4.1.0\bin\Rscript.exe" "$BasePath\RUN_ERGO.R"
