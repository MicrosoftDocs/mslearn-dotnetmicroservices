﻿
param (
    [string]$orgSiteUrl,
    [string]$docLibFolderRelativeUrl,
    [string]$srcFilePath,
    [string]$srcFileName,
    [string]$fileName,
    [string]$dllPath,
    [string]$spo_User,
    [string]$spo_Pw,
	[string]$database_instance="SQLDEVDIIRM.cloud.munichre.com",
    [string]$database_name="DI_IRM_CreditRisk_Input",
    [string]$logging_table="[dbo].[Logging]",
    [int]$FK_JobIteration=1,
    [int]$FK_Run=30,
    [int]$SCRProcessID=999999,
    [string]$Package="DI_IRM_CreditRisk_Input",
	[string]$JobStep="Test_PowerShell",
    [string]$CreatedBy)


#https://munichre.sharepoint.com/sites/dev-diirm/MaCrRi/CrRi/Lists/RUNs/AllItems.aspx

#Import the required DLL
#$dllPath="E:\Powershell"
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.Runtime.dll"

function writeSQLLog(
 #   [string]$database_instance,
 #   [string]$database_name,
 #   [string]$logging_table,
 #   [int]$FK_JobIteration,
 #   [int]$FK_Run,
 #   [string]$Package,
 #   [string]$JobStep,
 #   [string]$CreatedBy,
    [string]$Type,
    [string]$Msg
)
{
    return
    $conn = New-Object System.Data.SqlClient.SqlConnection
    $conn.ConnectionString = "Data Source=$database_instance;Initial Catalog=$database_name;Integrated Security=SSPI;"
    $conn.Open()

    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $par1 = New-Object System.Data.SqlClient.SqlParameter
    $par1.ParameterName="@msgData"
    $par1.SqlDbType=[System.Data.SqlDbType]::Text
    $par1.Value=$Msg

    $cmd.connection = $conn
    $cmd.Parameters.Add($par1)

    if($SCRProcessID -eq 999999)
    {
    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$( $Msg.Replace("'", "''") )',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"
    }
    else
    {
    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[SCR_ProcessId],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$SCRProcessID AS SCRProcessID
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$( $Msg.Replace("'", "''") )',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"
    }

    $cmd.CommandText=$insertStmt
    #$retval=$cmd.executenonquery()
    $conn.close()
}


function SPOUploadFile
#(
#    [string]$orgSiteUrl,
#    [string]$docLibFolderRelativeUrl,
#    [string]$srcFilePath,
#    [string]$srcFileName,
#    [string]$fileName
#)
{
	writeSqlLog -Type:"OnPreExecute" -Msg:"destFilePath: $destFilePath"
	writeSqlLog -Type:"OnPreExecute" -Msg:"dataFileName: $dataFileName"
	writeSqlLog -Type:"OnPreExecute" -Msg:"fileName: $fileName"

    $cnt = 0
    $Maximum = 15
    $Delay = 15000

    do
    {
    $cnt++
    writeSqlLog -Type:"Info" -Msg:"UploadFilesToSharePoint_SPO_WithLogging: iteration $cnt."
    
	try
	{
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
        # Get the Client Context and Bind the Site Collection
        $ClientContext = New-Object Microsoft.SharePoint.Client.ClientContext($orgSiteUrl)

        #NEW SECTION SPECIFIC TO OFFICE365 PASSWORD File
        #$secPwdfile="$ExecutingScriptDirectory\SPOCredentials-$($env:USERNAME).pwd"
        $secPwdfile="$dllPath\SPOCredentials.pwd"
        
        if(Test-Path $secPwdfile)
        {
            $credentialPS = Import-CliXml -Path $secPwdfile
            $credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($($credentialPS.UserName), $($credentialPS.Password))
        }
        else
        {
            Write-Host "Please enter the credentials..."
            $name=$spo_User
            $pwd=$spo_Pw
            
            $secpasswd = ConvertTo-SecureString $pwd -AsPlainText -Force
            $Creds = New-Object System.Management.Automation.PSCredential ($name, $secpasswd)
            #$Creds = Get-Credential
            $Creds | Export-CliXml -Path $secPwdfile
            return
        }
        $ClientContext.Credentials = $credentials
        
        #NEW SECTION SPECIFIC TO OFFICE365

        # Connect to source site
        $web = $ClientContext.Web
        $ClientContext.Load($web)
        $ClientContext.ExecuteQuery()

        #$dataList = $web.Lists.GetByTitle($docLibDisplayName)

        #Upload File
        
        $ByteArray = [System.IO.File]::ReadAllBytes("$srcFilePath\$srcFileName")
        
        $s =[System.IO.MemoryStream]($ByteArray)
        
        $FileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
        
        $FileCreationInfo.Overwrite = $true
        
        $FileCreationInfo.ContentStream = $s
        
        $FileCreationInfo.URL = $fileName
        
        
        $folder=$web.GetFolderByServerRelativeUrl("$orgSiteUrl$docLibFolderRelativeUrl")
        
        
        #$Upload = $dataList.RootFolder.Files.Add($FileCreationInfo)
        $Upload = $folder.Files.Add($FileCreationInfo)
        
        $ClientContext.Load($Upload)
        
        $ClientContext.ExecuteQuery() 
        return
	}
	catch
	{
        Write-Host "Error occured: $($_.Exception)"
		writeSqlLog -Type:"OnError" -Msg:"$($_.Exception)"
        
        if($cnt -eq $Maximum)
        {
            writeSqlLog -Type:"OnError" -Msg:"Exit script with error."
            exit -1
        }
	}
} while ($cnt -lt $Maximum)
}
# function call
SPOUploadFile -dllPath $dllPath -orgSiteUrl:$orgSiteUrl -docLibFolderRelativeUrl:$docLibFolderRelativeUrl -srcFilePath:$srcFilePath -srcFileName:$srcFileName -fileName:$fileName 
