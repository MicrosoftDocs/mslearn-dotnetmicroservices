param([string]$orgSiteUrl,
    [string]$listDisplayName,
    [string]$lookupColumStatus,
    [int]$itemID,
    [int]$processStatusId,
    [string]$colLogfile,
    [string]$logUrl,
    [string]$dllPath,
       [string]$spo_User,
       [string]$spo_Pw,
	[string]$database_instance="SQLDEVDIIRM.cloud.munichre.com",
    [string]$database_name="DI_IRM_CreditRisk_Input",
    [string]$logging_table="[dbo].[Logging]",
    [int]$FK_JobIteration=1,
    [int]$FK_Run=30,
    [int]$SCRProcessID=999999,
    [string]$Package="DI_IRM_CreditRisk_Input",
	[string]$JobStep="Test_PowerShell",
    [string]$CreatedBy)

function writeSQLLog(
    [string]$Type,
    [string]$Msg
)
{
    $conn = New-Object System.Data.SqlClient.SqlConnection
    $conn.ConnectionString = "Data Source=$database_instance;Initial Catalog=$database_name;Integrated Security=SSPI;"
    $conn.Open()

    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.connection = $conn

    if($SCRProcessID -eq 999999)
    {
    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$( $Msg.Replace("'", "''") )',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"
    }
    else
    {
    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[SCR_ProcessId],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$SCRProcessID AS SCRProcessID
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$( $Msg.Replace("'", "''") )',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"
    }

    $cmd.CommandText=$insertStmt
    $retval=$cmd.executenonquery()
    $conn.close()
}

function writeStatus(
    [string]$orgSiteUrl,
    [string]$listDisplayName,
    [string]$lookupColumStatus,
    [int]$itemID,
    [int]$processStatusId,
    [string]$colLogfile,
    [string]$logUrl,
    [string]$dllPath
)
{

  	writeSqlLog -Type:"OnPreExecute" -Msg:"orgSiteUrl: $orgSiteUrl"
	writeSqlLog -Type:"OnPreExecute" -Msg:"listDisplayName: $listDisplayName"
	writeSqlLog -Type:"OnPreExecute" -Msg:"lookupColumStatus: $lookupColumStatus"
	writeSqlLog -Type:"OnPreExecute" -Msg:"itemID: $itemID"
	writeSqlLog -Type:"OnPreExecute" -Msg:"processStatusId: $processStatusId"
	writeSqlLog -Type:"OnPreExecute" -Msg:"colLogfile: $colLogfile"
	writeSqlLog -Type:"OnPreExecute" -Msg:"logUrl: $logUrl"

    #Import the required DLL
    Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.dll"
    Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.Runtime.dll"

    $cnt = 0
    $Maximum = 15
    $Delay = 15000

    do
    {
    $cnt++
    writeSqlLog -Type:"Info" -Msg:"UpdateSharePointList_SPO_WithLogging: iteration $cnt."
    #writeSqlLog -Type:"Info" -Msg:"UpdateSharePointList_SPO_WithLogging: SCRProcessID $SCRProcessID."

    try
    {
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
        # Get the Client Context and Bind the Site Collection
        $ClientContext = New-Object Microsoft.SharePoint.Client.ClientContext($orgSiteUrl)

#NEW SECTION SPECIFIC TO OFFICE365 PASSWORD File
        $secPwdfile="$dllPath\SPOCredentials.pwd"

        if(Test-Path $secPwdfile)
        {
            $credentialPS = Import-CliXml -Path $secPwdfile
            $credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($($credentialPS.UserName), $($credentialPS.Password))
        }
        else
        {

			writeSqlLog -Type:"OnPreExecute" -Msg:"WARNING: No PwdFile at path $dllPath"

			Write-Host "Please enter the credentials..."

            $name=$spo_User
            $pwd=$spo_Pw
            $secpasswd = ConvertTo-SecureString $pwd -AsPlainText -Force
            $Creds = New-Object System.Management.Automation.PSCredential ($name, $secpasswd)

            $Creds | Export-CliXml -Path $secPwdfile
            return
        }
        $ClientContext.Credentials = $credentials
#NEW SECTION SPECIFIC TO OFFICE365 PASSWORD File


        # Connect to source site
        $web = $ClientContext.Web
        $ClientContext.Load($web)
        $ClientContext.ExecuteQuery()

        # Get List and List Items
        $List = $web.Lists.GetByTitle($listDisplayName)
        $ListItems = $List.GetItems([Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery())
        $ClientContext.Load($List)
        $ClientContext.Load($ListItems)
        $ClientContext.ExecuteQuery()


        if($ListItems.Count -eq 0)
        {
            Write-Host "No items for processing."
            return
        }

        $item=$ListItems.GetById($itemID)
        $ClientContext.Load($item)
        $ClientContext.ExecuteQuery()

        #Process_Status
        $lup = $item.Item($lookupColumStatus)
        if($lup -eq $null)
        {
            $lup= New-Object Microsoft.SharePoint.Client.FieldLookupValue
        }
        $lup.LookupId=$processStatusId
        $item.Item($lookupColumStatus)=$lup

        #Logfile
        if(-not [string]::IsNullOrEmpty($logUrl))
        {
            $logColumn = $item.Item($colLogfile)
            if($logColumn -eq $null)
            {
                $logColumn= New-Object Microsoft.SharePoint.Client.FieldUrlValue
            }
            $logColumn.Description="LogFile"
            $logColumn.Url=$logUrl
            $item.Item($colLogfile)=$logColumn
        }

        # 2018-03-27
        $item.Update()
        $ClientContext.ExecuteQuery()

        return

    }
    catch
    {
        Write-Host "Error occured: $($_.Exception)"
		writeSqlLog -Type:"OnError" -Msg:"$($_.Exception)"
        Start-Sleep -Milliseconds $Delay
        
        if($cnt -eq $Maximum)
        {
            writeSqlLog -Type:"OnError" -Msg:"Exit script with error."
            exit -1
        }
    }
    } while ($cnt -lt $Maximum)
}

writeStatus -orgSiteUrl:$orgSiteUrl -listDisplayName:$listDisplayName -itemID:$itemID -lookupColumStatus:$lookupColumStatus -processStatusId:$processStatusId -colLogfile:$colLogfile -logUrl:$logUrl -dllPath:$dllPath
