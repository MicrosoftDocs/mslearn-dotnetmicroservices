﻿$original_file = '\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\Templates\script.r'
$destination_file =  '\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00001\script.r'
$filebasepath = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/'
$zz = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/rad01DFB.tmp'
$toplevel1 = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/01_INPUTS/With_VA/ERGO/04_TOPAGG/Top-Aggregation 2021Q4_wVA_ERGO_Total_with_OpRisk_Realisationen_220127-102748.csv'
$toplevel2 = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/01_INPUTS/With_VA/ERGO/04_TOPAGG/Top-Aggregation 2021Q4_wVA_ERGO_Total_wo_OpRisk_Realisationen_220127-102518.csv'
$credit = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/01_INPUTS/With_VA/ERGO/02_CREDIT/INPUT_Multiple_Usage_mitVA_2021Q4.csv'
$market = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/01_INPUTS/With_VA/ERGO/01_MARKET/DI_IRM_MarketRisk_Distribution_Entity_MR Group_Run_246_EUR.xlsx'
$life = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/01_INPUTS/With_VA/ERGO/03_LIFE/GroupedByRiskModelSectorInclPensions - ERGO L&H + Pensions (mit VA) (nach CLR Korr).mat'
$mu = '//fxx0004/mrdata3/DI_IRM/TST/SCR/TA/MUAO/RunId_00046/01_INPUTS/With_VA/ERGO/05_ERGO/2021Q4ERGO_MU_INPUT_mit VA.xlsx'

(Get-Content $original_file -Raw) | Foreach-Object {
    $_ -replace '@filebasepath', $filebasepath `
       -replace '@zz', $zz `
       -replace '@toplevel1', $toplevel1 `
       -replace '@toplevel2', $toplevel2 `
       -replace '@credit', $credit `
       -replace '@market', $market `
       -replace '@life', $life `
       -replace '@mu', $mu `
    } | Set-Content $destination_file