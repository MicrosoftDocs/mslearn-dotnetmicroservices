param([string]$orgSiteUrl,
        [string]$listDisplayName,
        [string]$lookupColumStatus,
        [int]$itemID,
        [int]$processStatusId,
        [string]$colLogfile,
        [string]$logUrl,
        [string]$dllPath)

#https://collab-vs.dev.munich.munichre.com/sites/S0000330/MaCrRi/CrRi/Lists/RUNs/AllItems.aspx

#Import the required DLL
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.Runtime.dll"


#function writeStatus(
#    [string]$orgSiteUrl,
#    [string]$listDisplayName,
#    [string]$lookupColumStatus,
#    [int]$itemID,
#    [int]$processStatusId,
#    [string]$colLogfile,
#    [string]$logUrl
#)
#{
    #$UserName = 'someDomain\someUser'
    #$SecurePassword = "somePassword" | ConvertTo-SecureString -AsPlainText -Force

    #Write-Host "Script running with following account : "$UserName -ForegroundColor Yellow

    # Get the Client Context and Bind the Site Collection
    $ClientContext = New-Object Microsoft.SharePoint.Client.ClientContext($orgSiteUrl)

    # Connect to source site
    #$credentials = New-Object System.Net.NetworkCredential($UserName, $SecurePassword)
    #$ClientContext.Credentials = $credentials
    $web = $ClientContext.Web
    $ClientContext.Load($web)
    $ClientContext.ExecuteQuery()

    # Get List and List Items
    $List = $web.Lists.GetByTitle($listDisplayName)
    $ListItems = $List.GetItems([Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery())
    $ClientContext.Load($List)
    $ClientContext.Load($ListItems)
    $ClientContext.ExecuteQuery()

    if($ListItems.Count -eq 0)
    {
        Write-Host "No items for processing."
        return
    }

    $item=$ListItems.GetById($itemID)
    $ClientContext.Load($item)
    $ClientContext.ExecuteQuery()

    #Process_Status
    $lup = $item.Item($lookupColumStatus)
    if($lup -eq $null)
    {
        $lup= New-Object Microsoft.SharePoint.Client.FieldLookupValue
    }
    $lup.LookupId=$processStatusId
    $item.Item($lookupColumStatus)=$lup
    $item.Update()
    $ClientContext.ExecuteQuery()

    #Logfile
    if(-not [string]::IsNullOrEmpty($logUrl))
    {
        $logColumn = $item.Item($colLogfile)
        if($logColumn -eq $null)
        {
            $logColumn= New-Object Microsoft.SharePoint.Client.FieldUrlValue
        }
        $logColumn.Description="LogFile"
        $logColumn.Url=$logUrl
        $item.Item($colLogfile)=$logColumn
        $item.Update()
        $ClientContext.ExecuteQuery()
    }
#}

#$orgSiteUrl2 = "https://collab-vs.dev.munich.munichre.com/sites/S0000330/MaCrRi/CrRi/"

#writeStatus -orgSiteUrl:$orgSiteUrl2 -listDisplayName:"RUNs" -itemID:5 -lookupColumStatus:"Process_Status" -processStatusId:4 -colLogfile:"LogFile" -logUrl:"http://www2.munichre.com"
