
[CmdletBinding()]
param(
    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [int] $FileId,

    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [string] $SiteUrl,

    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [string] $SourceCollection,

    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [string] $DestinationCollection,

    [Parameter( Mandatory = $false )]
    [ValidateNotNullOrEmpty()]
    [string] $DestinationName,

    [ValidateNotNullOrEmpty()]
    [string] $LogPath = 'MoveFileOnSharepointById'
)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Start-Transcript -Path "C:\Logs\DI_IRM\$LogPath-$timestamp.txt" -NoClobber

try {

    Write-Verbose 'Load Modules'
    Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1" -Force

    Write-Verbose 'Load Credentials'
    $credential = Import-CliXml -Path "$PSScriptRoot\SPOCredentials.pwd" | New-SharepointCredential

    Write-Verbose 'Create Sharepoint Connection Context'
    $context = Connect-SharepointSite -SiteUrl $SiteUrl -Credential $credential

    Write-Verbose 'Move File'
    Move-SharepointFile -Context $context -SourceCollection $SourceCollection -FileId $FileId -DestinationCollection $DestinationCollection -DestinationName $DestinationName

} catch {
    Write-Error $_ -ErrorAction 'Continue'
    exit 1
}
finally {
    Stop-Transcript
}
