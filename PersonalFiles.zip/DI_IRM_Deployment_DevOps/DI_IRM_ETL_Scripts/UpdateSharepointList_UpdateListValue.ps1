﻿[CmdletBinding()]
param(
    #[string] $DatabaseInstance = 'sqldevdiirm.cloud.munichre.com',
    [string] $OrgSiteUrl = 'https://munichre.sharepoint.com/sites/dev-diirm/LHRM/',
    [string] $ColumnName = 'Process_Status',
    [string] $ColumnValue = 'InProgress',
    [int] $ItemID = 11,
    [string] $ListTitle = 'RUNs'
    
)

Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1" -Force

# Load credentials
$credentialPS = Import-CliXml -Path "$PSScriptRoot\SPOCredentials.pwd"
$credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials `
    -ArgumentList $credentialPS.UserName, $credentialPS.Password


$sharepointContext = Connect-SharepointSite -SiteUrl $OrgSiteUrl -Credential $credential

Set-SharepointListItemValue -Context $SharepointContext -ListTitle $ListTitle -ItemId $ItemID -ColumnName $ColumnName -Value $ColumnValue