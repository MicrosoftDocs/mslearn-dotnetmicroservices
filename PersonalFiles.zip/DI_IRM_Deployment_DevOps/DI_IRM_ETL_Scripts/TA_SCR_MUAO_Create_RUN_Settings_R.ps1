﻿$original_file = '\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\Templates\RUN.Settings.r'
$destination_file =  '\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00001\RUN.Settings.r'
$toplevel1 = './04_TOPAGG/Top-Aggregation 2021Q4_wVA_Group_Total_with_OpRisk_Realisationen_220127-103532.csv'
$toplevel2 = './04_TOPAGG/Top-Aggregation 2021Q4_wVA_Group_Total_wo_OpRisk_Realisationen_220127-103317.csv'
$credit = './02_CREDIT/INPUT_Multiple_Usage_mitVA_2021Q4.csv'
$market = './01_MARKET/DI_IRM_MarketRisk_Distribution_Entity_MR Group_Run_246_EUR.xlsx'
$life = './03_LIFE/LifeAndHealth - Life & Health (mit VA) (nach CLR Korr).mat'
$mu = './05_ERGO/2021Q4ERGO_MU_INPUT_mit VA.xlsx'

(Get-Content $original_file -Raw) | Foreach-Object {
    $_ -replace '@toplevel1', $toplevel1 `
       -replace '@toplevel2', $toplevel2 `
       -replace '@credit', $credit `
       -replace '@market', $market `
       -replace '@life', $life `
       -replace '@mu', $mu `
    } | Set-Content $destination_file