﻿[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $OrgSiteUrl,

    [Parameter(Mandatory)]
    [string] $ListTitle,

    [Parameter(Mandatory)]
    [string] $Values,

    [ValidateNotNullOrEmpty()]
    [string] $LogPath = 'InsertToSharepointList_WithLogging',

    [string]$database_instance="SQLTSTEDIIRM.cloud.munichre.com",
    [string]$database_name="DI_IRM_SCR_Input",
    [string]$logging_table="[dbo].[Logging]",
    [int]$FK_JobIteration=1,
    [int]$FK_Run=2,
    [int]$SCRProcessID=999999,
    [string]$Package="DI_IRM_SCR_Input_SPO_TA_UpdateRuns",
	[string]$JobStep="Insert SPO List Item",
    [string]$CreatedBy,
    [int]$ItemRun,
    [string]$RiskCategory

)

function writeSQLLog(
    [string]$Type,
    [string]$Msg
)
{
    $conn = New-Object System.Data.SqlClient.SqlConnection
    $conn.ConnectionString = "Data Source=$database_instance;Initial Catalog=$database_name;Integrated Security=SSPI;"
    $conn.Open()

    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.connection = $conn

    if($SCRProcessID -eq 999999)
    {
    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$( $Msg.Replace("'", "''") )',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"
    }
    else
    {
    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[SCR_ProcessId],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$SCRProcessID AS SCRProcessID
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$( $Msg.Replace("'", "''") )',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"
    }

    $cmd.CommandText=$insertStmt
    $retval=$cmd.executenonquery()
    $conn.close()
}




$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Start-Transcript -Path "C:\Logs\DI_IRM\$LogPath-$timestamp.txt" -NoClobber


$cnt = 0
$Maximum = 3
$Delay = 5000

do
{
    $cnt++

try {
    Write-Verbose 'Convert String to HashTable'
    Write-Verbose "String Value is: $Values"
    $ValuesHash = Invoke-Expression $Values

    Write-Verbose 'Load Modules'
    Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1" -Force

    # Load credentials
    Write-Verbose 'Load Credentials'
    $credentialPS = Import-CliXml -Path "$PSScriptRoot\SPOCredentials.pwd"
    $credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials `
        -ArgumentList $credentialPS.UserName, $credentialPS.Password

    # Create connection
    Write-Verbose 'Create Sharepoint Connection Context'
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    $sharepointContext = Connect-SharepointSite -SiteUrl $OrgSiteUrl -Credential $credential

    writeSqlLog -Type:"OnInfo" -Msg:"Insert SPO List Item for RiskCategory: $RiskCategory, RunId:$ItemRun"

    # Update list item
    Write-Verbose 'Insert Item'
    New-SharepointListItem -Context $sharepointContext -ListTitle $ListTitle -Values $ValuesHash
    return

} catch {
    Write-Error $_ -ErrorAction 'Continue'
    Write-Host "Error occured: $($_.Exception)"
	writeSqlLog -Type:"OnError" -Msg:"$($_.Exception)"
    Start-Sleep -Milliseconds $Delay
        
    if($cnt -eq $Maximum)
    {
        exit -1
    }
}
} while ($cnt -le $Maximum)


finally {
    Stop-Transcript
}