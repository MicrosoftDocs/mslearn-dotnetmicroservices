﻿
<#

.SYNOPSIS
Updates an Sharepoint List Item on multiple columns.

.PARAMETER OrgSiteUrl
Specifies the Sharepoint Site by the URL.

.PARAMETER ListTitle
Specifies the Sharepoint List by the Title.

.PARAMETER ItemId
Specifies the Sharepoint List Item by the ID.

.PARAMETER Values
Specifies the Columns an desired values using a hashtable.

.EXAMPLE
powershell.exe -command "& { C:\Users\ny36717\Source\Workspaces\DI_IRM\Main\DI_IRM_General\DI_IRM_ETL_Scripts\UpdateSharepointList_Values.ps1 -OrgSiteUrl 'https://munichre.sharepoint.com/sites/dev-diirm/LHRM/' -ListTitle 'RUNs' -ItemId 14 -Values @{ Operation_Status = 2; Process_Status = 1 } }"

#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $OrgSiteUrl,

    [Parameter(Mandatory)]
    [string] $ListTitle,

    [Parameter(Mandatory)]
    [int] $ItemId,

    [Parameter(Mandatory)]
    [hashtable] $Values

)

Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1" -Force

# Load credentials
$credentialPS = Import-CliXml -Path "$PSScriptRoot\SPOCredentials.pwd"
$credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials `
    -ArgumentList $credentialPS.UserName, $credentialPS.Password

# Create connection
$sharepointContext = Connect-SharepointSite -SiteUrl $OrgSiteUrl -Credential $credential

# Update list item
Set-SharepointListItemValue -Context $sharepointContext -ListTitle $ListTitle -ItemId $ItemID -Values $Values
