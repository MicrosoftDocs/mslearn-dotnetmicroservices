
[CmdletBinding()]
param(
    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [int] $FileId,

    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [string] $SharepointSiteUrl,

    [Parameter( Mandatory = $true )]
    [ValidateNotNullOrEmpty()]
    [string] $SharepointListTitle,

    [Parameter( Mandatory = $true )]
    [ValidateScript({ Test-Path $_ -IsValid })]
    [string] $DestinationPath,

    [ValidateNotNullOrEmpty()]
    [string] $LogPath = 'CopyFilesFromSharepointById'
)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Start-Transcript -Path "C:\Logs\DI_IRM\$LogPath-$timestamp.txt" -NoClobber

$cnt = 0
$Maximum = 15
$Delay = 15000

do
{
$cnt++
#writeSqlLog -Type:"Info" -Msg:"CopyFilesFromSharePointById: iteration $cnt."

try {

    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    [string] $ConfigPath = "$PSScriptRoot\..\SPOCredentials.pwd"

    Import-Module "$PSScriptRoot\..\DatabaseHelper\DatabaseHelper.psd1"
    Import-Module "$PSScriptRoot\..\LoggingHelper\LoggingHelper.psd1"
    Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1"

    Write-Verbose 'Modules loaded'

    $credential = Import-CliXml -Path $ConfigPath | New-SharepointCredential
    Write-Verbose 'Credentials loaded'

    $context = Connect-SharepointSite -SiteUrl $SharepointSiteUrl -Credential $credential
    Write-Verbose 'Sharepoint context created'

    Get-SharepointList -Context $context -Title $SharepointListTitle |
    Where-Object ID -eq $fileId |
    Copy-SharepointFile -Context $context -Destination $DestinationPath -Download
    Write-Verbose 'File downloaded'

    return

} catch {
    Write-Error $_ -ErrorAction 'Continue'
    
    if($cnt -eq $Maximum)
    {
        return -1
    }
    #exit -1
}
} while ($cnt -lt $Maximum)
finally {
    Stop-Transcript
}
