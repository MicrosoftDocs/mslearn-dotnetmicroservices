﻿
<#

.SYNOPSIS
Creates an folder in a Sharepoint List.

.PARAMETER SiteUrl
Specifies the Sharepoint Site by the URL.

.PARAMETER ListTitle
Specifies the Sharepoint List by the Title.

.PARAMETER FolderName
Specifies the name of the new folder.

.EXAMPLE
powershell.exe -command "& { C:\Users\ny36717\Source\Workspaces\DI_IRM\Main\DI_IRM_General\DI_IRM_ETL_Scripts\CreateFolderOnSharepoint.ps1 -SiteUrl 'https://munichre.sharepoint.com/sites/dev-diirm/OpRisk/' -ListTitle 'RiskExplorer' -FolderName 'Run 1' }"

#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $SiteUrl,

    [Parameter(Mandatory)]
    [string] $ListTitle,

    [Parameter(Mandatory)]
    [string] $FolderName,

    [ValidateNotNullOrEmpty()]
    [string] $LogPath = 'CreateFolderOnSharepoint'
)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Start-Transcript -Path "C:\Logs\DI_IRM\$LogPath-$timestamp.txt" -NoClobber


$cnt = 0
$Maximum = 15
$Delay = 15000

do
{
    $cnt++
    #writeSqlLog -Type:"Info" -Msg:"CopyFilesFromSharePoint_SPO_WithLogging: iteration $cnt."

try {

    Write-Verbose 'Load Modules'
    Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1" -Force

    Write-Verbose 'Laod Credentials'
    $credential = Import-CliXml -Path "$PSScriptRoot\SPOCredentials.pwd" | New-SharepointCredential

    Write-Verbose 'Create Sharepoint Connection Context'
    $context = Connect-SharepointSite -SiteUrl $SiteUrl -Credential $credential

    Write-Verbose 'Create Folder'
    New-SharepointFolder -Context $context -CollectionTitle $ListTitle -Name $FolderName

} catch {
    Write-Error $_ -ErrorAction 'Continue'
    
    if($cnt -eq $Maximum)
    {
       return -1
    }
    #exit -1
}
} while ($cnt -lt $Maximum)


finally {
    Stop-Transcript
}
