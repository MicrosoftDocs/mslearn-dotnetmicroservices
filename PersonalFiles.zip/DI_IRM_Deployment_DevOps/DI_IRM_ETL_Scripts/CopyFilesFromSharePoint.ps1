﻿param(
    [string]$fromfile,
    [string]$tofile,
    [string]$dllPath)

#Import the required DLL
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.Runtime.dll"

function MoveFile
{

    $webclient = New-Object System.Net.WebClient
    $webclient.UseDefaultCredentials = $true
    $webclient.DownloadFile($fromfile, $tofile)

}

MoveFile

