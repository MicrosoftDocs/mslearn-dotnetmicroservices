﻿param(
    [string]$fromfile,
    [string]$tofile,
    [string]$dllPath,
	[string]$database_instance="SQLDEVDIIRM.cloud.munichre.com",
    [string]$database_name="DI_IRM_CreditRisk_Input",
    [string]$logging_table="[dbo].[Logging]",
    [int]$FK_JobIteration=1,
    [int]$FK_Run=30,
    [string]$Package="DI_IRM_CreditRisk_Input",
	[string]$JobStep="Test_PowerShell",
    [string]$CreatedBy
)

#Import the required DLL
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$dllPath\Microsoft.SharePoint.Client.Runtime.dll"

function writeSQLLog(
    [string]$Type,
    [string]$Msg
)
{
    $conn = New-Object System.Data.SqlClient.SqlConnection
    $conn.ConnectionString = "Data Source=$database_instance;Initial Catalog=$database_name;Integrated Security=SSPI;"
    $conn.Open()

    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.connection = $conn

    $insertStmt="INSERT INTO $logging_table ([FK_JobIteration],[FK_Run],[JobStep],[LoggingType],[Logging_Name],[Logging_Description],[Logging_OrderNumber],[Logging_CreatedDate],[Logging_CreatedBy],[Logging_ModifiedDate],[Logging_ModifiedBy],[Package])
        SELECT $FK_JobIteration AS FK_JobIteration
        ,$FK_Run AS FK_Run
        ,'$JobStep' AS JobStep
        ,'$Type' AS Logging_Type
        ,'Task executed' AS Logging_Name
        ,left('$Msg',1000) AS Logging_Description
        ,1 AS Logging_OrderNumber
        ,GETDATE() AS Logging_CreatedDate
        ,'$CreatedBy' AS Logging_CreatedBy
        ,GETDATE() AS Logging_ModifiedDate
        ,'$CreatedBy' AS Logging_ModifiedBy
        ,'$Package' AS Package"

    $cmd.CommandText=$insertStmt
    $retval=$cmd.executenonquery()
    $conn.close()
}

function MoveFile
{
	writeSqlLog -Type:"OnPreExecute" -Msg:"FromFile: $fromfile"
	writeSqlLog -Type:"OnPreExecute" -Msg:"ToFile: $tofile"

	try
	{

		$webclient = New-Object System.Net.WebClient
		$webclient.UseDefaultCredentials = $true
		$webclient.DownloadFile($fromfile, $tofile)
	}
	catch
	{
        Write-Host "Error occured: $($_.Exception)"
		writeSqlLog -Type:"OnError" -Msg:"$($_.Exception)"
        return -1
	}

}

MoveFile

