﻿param(
    [string]$original_file = "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\Code\R-Skript Version mit einem Exp\RUN.R",
    [string]$destination_file =  "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00128\RUN.R",
    [string]$filebasepath = "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\01_INPUTS\",
    [string]$muaobasepath = "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\",
    [string]$codeversion = "RunId_00128/",
    [string]$drillindex = "\\fxx0004\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00046\Drill.Index.RDS",
    [string]$distributions = "\\fxx0004\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00046\Distributions.RDS",
    [string]$runfolder = "RunId_00128/",
    [string]$MUAO_drilling_mode = "Group",
    [string]$MUAO_va_mode = "wVA",
    
    [string]$toplevel1 = ".\04_TOPAGG\Top-Aggregation 2021Q4_wVA_Group_Total_with_OpRisk_Realisationen_220127-103532.csv",
    [string]$toplevel2 = ".\04_TOPAGG\Top-Aggregation 2021Q4_wVA_Group_Total_wo_OpRisk_Realisationen_220127-103317.csv",
    [string]$credit = ".\02_CREDIT\INPUT_Multiple_Usage_mitVA_2021Q4.csv",
    [string]$market = ".\01_MARKET\DI_IRM_MarketRisk_Distribution_Entity_MR Group_Run_246_EUR.xlsx",
    [string]$life = ".\03_LIFE\LifeAndHealth - Life & Health (mit VA) (nach CLR Korr).mat",
    [string]$mu = ".\05_ERGO\2021Q4ERGO_MU_INPUT_mit VA.xlsx"
)

$LogfilePath = "C:\Logs\DI_IRM\testParameter.log"
$global:LogfilePath = $LogfilePath

Write-Verbose "original_file: $original_file"
Write-Verbose "destination_file: $destination_file"
Write-Verbose "filebasepath: $filebasepath"
Write-Verbose "muaobasepath: $muaobasepath"
Write-Verbose "codeversion: $codeversion"
Write-Verbose "drillindex: $drillindex"
Write-Verbose "distributions: $distributions"

Add-Content -Path $global:LogfilePath -Value "original_file: $original_file"

(Get-Content $original_file -Raw) | Foreach-Object {
    $_ -replace ("xx_codeversion", $codeversion) `
       -replace ("xx_muaobasepath", $muaobasepath) `
       -replace ("xx_runfolder", $runfolder) `
       -replace ("xx_drilling_mode", $MUAO_drilling_mode) `
       -replace ("xx_va_mode", $MUAO_va_mode) `
       -replace ("xx_drillindex", $drillindex) `
       -replace ("xx_distributions", $distributions) `
       -replace ("xx_filebasepath", $filebasepath) `
       -replace ("xx_toplevel1", $toplevel1) `
       -replace ("xx_toplevel2", $toplevel2) `
       -replace ("xx_credit", $credit) `
       -replace ("xx_market", $market) `
       -replace ("xx_life", $life) `
       -replace ("xx_mu", $mu)
    } | Set-Content $destination_file