﻿
<#

.SYNOPSIS
Inserts a new entry to a Sharepoint List.

.PARAMETER OrgSiteUrl
Specifies the Sharepoint Site by the URL.

.PARAMETER SourceCollectionTitle
Specifies the source Sharepoint Collection by the Title.

.PARAMETER DestinationCollectionTitle
Specifies the destination Sharepoint Collection by the Title.

.PARAMETER DestinationFolderName
Specifies the Name of the destination folder.

.EXAMPLE
powershell.exe -command "& { C:\Users\ny36717\Source\Workspaces\DI_IRM\Main\DI_IRM_General\DI_IRM_ETL_Scripts\CopySharepointCollection.ps1 -OrgSiteUrl 'https://munichre.sharepoint.com/sites/dev-diirm/LHRM/' -SourceCollectionTitle 'Input' -DestinationCollectionTitle 'Export' -DestinationFolderName 'Input-Backup' }"

#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $OrgSiteUrl,

    [Parameter(Mandatory)]
    [string] $SourceCollectionTitle,

    [Parameter(Mandatory)]
    [string] $DestinationCollectionTitle,

    [Parameter(Mandatory)]
    [string] $DestinationFolderName
)

Import-Module "$PSScriptRoot\..\SharepointHelper\SharepointHelper.psd1" -Force

# Load credentials
$credentialPS = Import-CliXml -Path "$PSScriptRoot\SPOCredentials.pwd"
$credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials `
    -ArgumentList $credentialPS.UserName, $credentialPS.Password

# Create connection
$sharepointContext = Connect-SharepointSite -SiteUrl $OrgSiteUrl -Credential $credential

# Create Folder
New-SharepointFolder -Context $sharepointContext -CollectionTitle $DestinationCollectionTitle -Name $DestinationFolderName

$files = Get-SharepointList -Context $sharepointContext -Title $SourceCollectionTitle -Columns 'FileRef', 'FileLeafRef'
$destinationSiteRelative = "/sites/$( ( $OrgSiteUrl -Split '/sites/', 2 )[1] )$( Get-SharepointCollectionName -Context $sharepointContext -Title $DestinationCollectionTitle )/$DestinationFolderName"
foreach ( $file in $files )
{
    $file | Copy-SharepointFile -Context $sharepointContext -Destination "$destinationSiteRelative/$( $file.FileLeafRef )" -WithinSharepoint
}