﻿param(
    [string]$original_folder = "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\Code\R-Skript Version mit einem Exp\",
    [string]$destination_folder =  "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00128\00_CODE\",
    [string]$destination_folder_settings =  "\\fxx0004.munich.munichre.com\mrdata3\DI_IRM\TST\SCR\TA\MUAO\RunId_00128\"
)

[string]$helper = "$($original_folder)Helper.R"
[string]$lib = "$($original_folder)LIB.R"
[string]$val = "$($original_folder)Validation.R"
[string]$log = "$($original_folder)Logging.R"

[string]$settings = "$($original_folder)RUN.Settings.R"


#Write-Host $settings_dest

Copy-Item $helper,$lib,$val,$log -Destination $destination_folder -Force
Copy-Item $settings -Destination $destination_folder_settings -Force