/*

    # Add Linked Server Login

    Adds a login mapping for a linked server.

    Date: 20.11.2018
    Autor: Steffen Kampmann

    ## Changelog

    ## Parameters

    LinkedServerName
    LocalUserName
    RemoteUserName
    RemotePassword

*/

USE [master]
GO

EXEC master.dbo.sp_addlinkedsrvlogin
    @rmtsrvname = N'$(LinkedServerName)',
    @locallogin = N'$(LocalUserName)',
    @useself = N'False',
    @rmtuser = N'$(RemoteUserName)',
    @rmtpassword = N'$(RemotePassword)'

RAISERROR ('Linked Server login added.', 0, 1) WITH NOWAIT