﻿<#

    .SYNOPSIS
    Deploy SQL scripts for LinkedServerGeneral

    .NOTES
    Date:       2018-05-03
    Author:     Steffen Kampmann
    Version:    1.0

    .PARAMETER ProjectName
    The project of the sql script.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER Environment
    The environment in which the script needs to be executed.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER AraXmlPath
    Path to the ARA.xml .
    If not definied, it is ../ARA.xml

    .PARAMETER DeplyomentHelperPath
    Path to the Powershell functions of DeploymentHelper.

    .PARAMETER LogfilePath
    Path to the logfile of this script

#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

	[ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_sql.log"
)

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region Script Definition

function Set-LinkedServerOlap
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LinkedServerName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LinkedServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LinkedServerCatalog
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\Set_LinkedServer_OLAP.sql" `
        -Arguments `
            "LinkedServerName = ""$LinkedServerName""", `
            "LinkedServerInstance = ""$LinkedServerInstance""", `
            "LinkedServerCatalog = ""$LinkedServerCatalog"""
}


function Set-LinkedServerSql
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LinkedServerName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LinkedServerInstance
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\Set_LinkedServer_SQL.sql" `
        -Arguments `
            "LinkedServerName = ""$LinkedServerName""", `
            "LinkedServerInstance = ""$LinkedServerInstance"""
}

function Set-LinkedServerLogin
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LinkedServerName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $LocalUserName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $RemoteUserName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $RemotePassword
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\Set_LinkedServer_Login.sql" `
        -Arguments `
            "LinkedServerName = ""$LinkedServerName""", `
            "LocalUserName = ""$LocalUserName""", `
            "RemoteUserName = ""$RemoteUserName""", `
            "RemotePassword = ""$RemotePassword"""
}

#endregion
#region Load parameter from ARA.xml

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

try {
    $scriptCommand = Get-AraScriptCommand -AraXmlPath $AraXmlPath -ProjectName $ProjectName -Environment $Environment -ScriptFolderName $ScriptFolderName
    [string] $ServerInstance = $scriptCommand.serverInstance
    [string] $LinkedServerName = $scriptCommand.linkedServerName
    [string] $LinkedServerInstance = $scriptCommand.linkedServerInstance
    [string] $LinkedServerCatalog = $scriptCommand.linkedServerCatalog
    [string] $Provider = $scriptCommand.provider

    $userMappings = $scriptCommand.userMapping | ForEach-Object {
        $userMappingNode = $_
        New-Object -Type PsObject -Property @{
            LinkedServerName = $LinkedServerName
            LocalUserName = [string] $userMappingNode.localUserName
            RemoteUserName = [string] $userMappingNode.remoteUserName
            RemotePassword = [string] $userMappingNode.remotePassword
        } | Write-Output
    }
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Prepare:Load ARA: $( $_.Exception )"
    throw
}

#endregion
#region Execute
Write-ToLogFile "Execute: Start"

try
{

    if ( $Provider -eq 'SQLOLEDB' ) {
        Set-LinkedServerSql `
            -ServerInstance $ServerInstance `
            -LinkedServerName $LinkedServerName `
            -LinkedServerInstance $LinkedServerInstance
    } else {
        Set-LinkedServerOlap `
            -ServerInstance $ServerInstance `
            -LinkedServerName $LinkedServerName `
            -LinkedServerInstance $LinkedServerInstance `
            -LinkedServerCatalog $LinkedServerCatalog
    }

    $userMappings | ForEach-Object {
        Set-LinkedServerLogin `
            -ServerInstance $ServerInstance `
            -LinkedServerName $LinkedServerName `
            -LocalUserName $_.LocalUserName `
            -RemoteUserName $_.RemoteUserName `
            -RemotePassword $_.RemotePassword
    }
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw
}

Write-ToLogFile "Execute: End"
#endregion
