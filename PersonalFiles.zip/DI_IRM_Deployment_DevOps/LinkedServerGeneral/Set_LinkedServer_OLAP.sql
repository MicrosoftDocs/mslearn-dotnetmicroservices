/*

    # Recreate_LinkedServer

    Drops and creates a linked server connection.

    Date: 03.05.2018
    Autor: Steffen Kampmann

    ## Changelog

    ## Parameters

    LinkedServerName
	LinkedServerInstance
    LinkedServerCatalog

*/

USE [master]
GO

IF EXISTS ( SELECT 1 FROM sys.servers WHERE is_linked = 1 AND name = '$(LinkedServerName)' )
BEGIN
    RAISERROR ('Drop Linked Server "%s".', 0, 1, '$(LinkedServerName)') WITH NOWAIT
    EXEC master.dbo.sp_dropserver @server=N'$(LinkedServerName)', @droplogins='droplogins'
END
ELSE
BEGIN
    RAISERROR ('No need to drop Linked Server "%s".', 0, 1, '$(LinkedServerName)') WITH NOWAIT
END
GO

RAISERROR ('Add Linked Server "%s" to "%s".', 0, 1, '$(LinkedServerName)', '$(LinkedServerInstance)') WITH NOWAIT
EXEC master.dbo.sp_addlinkedserver @server = N'$(LinkedServerName)', @srvproduct=N'', @provider=N'MSOLAP', @datasrc=N'$(LinkedServerInstance)', @catalog=N'$(LinkedServerCatalog)'
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'$(LinkedServerName)',@useself=N'True',@locallogin=NULL,@rmtuser=NULL,@rmtpassword=NULL
GO

RAISERROR ('Linked Server created.', 0, 1) WITH NOWAIT
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'collation compatible', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'data access', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'dist', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'pub', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'rpc', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'rpc out', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'sub', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'connect timeout', @optvalue=N'0'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'collation name', @optvalue=null
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'lazy schema validation', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'query timeout', @optvalue=N'0'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'use remote collation', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'$(LinkedServerName)', @optname=N'remote proc transaction promotion', @optvalue=N'true'
GO

RAISERROR ('Linked Server configured.', 0, 1) WITH NOWAIT
