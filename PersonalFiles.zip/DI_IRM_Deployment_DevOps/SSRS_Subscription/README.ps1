
# Eine XML subscription definition erstellt man folgendermaßen:

# Auf dem DEV-Reportserver wird über die reguläre Oberfläche eine Subscription angelegt.

$root = "$( $ENV:USERPROFILE )\Source\Workspaces\DI_IRM"
$deployment = "Main\DI_IRM_Deployment"
$reporting = "Main\DI_IRM_CreditRisk\DI_IRM_CreditRisk_Reporting"

$ErrorActionPreference = 'Stop'

Add-Type -Assembly System.Web

Set-Location $root\$deployment

. .\SSRS_Subscription\export_ssrs_subscription.ps1 -ServerInstance "SQLDEVDIIRM.cloud.munichre.com"

Get-ChildItem -Filter '*.subscription.xml'

# Jetzt liegen in unter Main\DI_IRM_Deployment die *.subscription.xml files für alle aktiven Subscriptions aus SQLDEVDIIRM
# Die neue subscription kannst du jetzt in das Visual Studio SSRS-Projekt kopieren. In der Datei muss jetzt noch im XML-Element database der Datenbankname eingetragen werden, in dem die Report-Parameter ausgelesen werden.

# Das Deployment auf DEV sieht dann z.B. so aus:

Set-Location $root\$reporting

try {
    . $root\$deployment\SSRS_Subscription\deploy_ssrs_subscription.ps1 `
        -Path $root/$reporting/DI_IRM_CreditRisk_LEM_V2.subscription.xml `
        -ProjectName "DI_IRM_CreditRisk" `
        -Environment "DEV" `
        -ReportServerInstance "sqltstdiirm.cloud.munichre.com" `
        -Username "MUNICH\ny36717" `
        -Password "geheim!" `
        -DeploySsrsSubscriptionPath $root\$deployment\SSRS_Subscription\bin\Debug\SSRS_Subscription.exe `
        -DeploymentHelperPath $root\$deployment\DeploymentHelper\DeploymentHelper.psm1 `
        -AraXmlPath $root/$reporting/../ARA.xml
}
catch {

    Get-ChildItem $root/$reporting -Filter "deploy_ssrs_subscription.log*" | ForEach-Object { Get-Content $_ }

    exit 1
}
