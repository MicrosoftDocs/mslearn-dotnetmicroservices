<#
    .SYNOPSIS
    Powershell Script export_ssrs_subscription.ps1

    .NOTES
    Date:       2018-03-06
    Author:     Steffen Kampmann
    Version:    1.0

    .DESCRIPTION
    This script reads a Report Subscription from
    the reportserver database and writes it to a XML file.

    .PARAMETER ServerInstance
    Hostname to the SQL Server (database of the report server).

    .PARAMETER DeplyomentHelperPath
    Path to the Powershell functions of DeploymentHelper.

#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string]
    $ServerInstance = $( throw "mandatory parameter is missing" ),

    [string] $DeploymentHelperPath = "../DeploymentHelper/DeploymentHelper.psm1"
)

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Set-Logfile 'export_subscription.log'

Get-Subscriptions -ServerInstance $ServerInstance |
    ForEach-Object { Remove-SubscriptionParameter -Subscription $_ -DestinationParameters 'PATH', 'USERNAME', 'PASSWORD' } |
    ForEach-Object { Export-Subscription -Subscription $_ }
