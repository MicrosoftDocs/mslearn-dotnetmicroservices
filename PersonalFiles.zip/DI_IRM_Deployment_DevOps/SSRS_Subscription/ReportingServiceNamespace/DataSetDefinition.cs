﻿
namespace SSRS_Subscription.ReportingServiceNamespace
{
    public partial class DataSetDefinition
    {
        public DataSetDefinition() { }
        public DataSetDefinition(Field[] Parameter, string SqlQuery)
        {
            AccentSensitivitySpecified = false;
            CaseSensitivitySpecified = false;
            KanatypeSensitivitySpecified = false;
            WidthSensitivitySpecified = false;
            Fields = Parameter;
            Query = new QueryDefinition
            {
                CommandText = SqlQuery,
                CommandType = "Text",
                Timeout = 45,
                TimeoutSpecified = true
            };
        }
    }
}
