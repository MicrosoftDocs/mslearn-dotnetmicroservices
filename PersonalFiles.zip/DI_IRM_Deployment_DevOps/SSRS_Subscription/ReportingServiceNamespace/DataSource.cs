﻿
namespace SSRS_Subscription.ReportingServiceNamespace
{
    public partial class DataSource
    {
        public DataSource() { }

        public DataSource(Configuration.Subscription Configuration, string DatabaseName)
        {
            Name = Configuration.ReportName + "_Subscription_DataSource";
            Item = new DataSourceDefinition(
                Configuration: Configuration, 
                DatabaseName: DatabaseName
            );
        }
    }
}