﻿
namespace SSRS_Subscription.ReportingServiceNamespace
{
    public partial class DataSourceDefinition
    {
        public DataSourceDefinition() { }

        public DataSourceDefinition(Configuration.Subscription Configuration, string DatabaseName)
        {
            ConnectString = string.Format(
                "data source={0};initial catalog={1}", 
                Configuration.DatasourceServer, 
                DatabaseName
            );
            CredentialRetrieval = CredentialRetrievalEnum.Store;
            Enabled = true;
            EnabledSpecified = true;
            Extension = "SQL";
            ImpersonateUserSpecified = false;
            UserName = Configuration.DatasourceUser;
            Password = Configuration.DatasourcePassword;
            WindowsCredentials = true;
        }
    }
}
