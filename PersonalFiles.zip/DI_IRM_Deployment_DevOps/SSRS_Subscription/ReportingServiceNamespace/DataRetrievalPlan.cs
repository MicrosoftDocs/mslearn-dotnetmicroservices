﻿
using Definition;

namespace SSRS_Subscription.ReportingServiceNamespace
{
    public partial class DataRetrievalPlan {
      
    }
}