﻿
using System;
using System.Web.Services.Protocols;

namespace SSRS_Subscription.ReportingServiceNamespace
{
    public partial class ReportingService2010
    {
        internal DataSetDefinition CreateDataSet(
            Configuration.Subscription Configuration,
            Definition.Subscription Definition
        )
        {
            Console.WriteLine(string.Format("Create Dataset for Report {0} on {1}.", Configuration.ReportName, Url));
                        
            var dataSetResult = new DataSetDefinition();
            bool changed;
            string[] paramNames;

            try
            {
                dataSetResult = PrepareQuery(
                    DataSource: new DataSource(
                        Configuration: Configuration, 
                        DatabaseName: Definition.DatasourceDatabaseName
                    ),
                    DataSet: new DataSetDefinition(
                        Parameter: Definition.ReportParameters.ToDatasetParameter(),
                        SqlQuery: Definition.SqlQuery
                    ),
                    Changed: out changed,
                    ParameterNames: out paramNames
                );

                Console.WriteLine("Create Dataset: Executed creation command succesfully.");
            }
            catch (SoapException e)
            {
                Console.WriteLine("Create Dataset: Failed to execute creation command.");
                Console.WriteLine(e.Detail.InnerXml.ToString());
                throw;
            }
            return dataSetResult;
        }
        
        internal DataRetrievalPlan CreateDataDrivenPlan(
            Configuration.Subscription Configuration,
            Definition.Subscription Definition
        )
        {
            var dataRetrieval = new DataRetrievalPlan
            {
                DataSet = CreateDataSet(
                    Configuration: Configuration,
                    Definition: Definition
                ),
                Item = new DataSourceDefinition(
                    Configuration: Configuration,
                    DatabaseName: Definition.DatasourceDatabaseName
                )
            };
            return dataRetrieval;
        }

        internal void CreateDataDrivenSubscription(
            Definition.Subscription Definition,
            Configuration.Subscription Configuration
        )
        {
            Console.WriteLine(string.Format("Create Subscription for {0} on {1} to {2}.", Configuration.ReportName, Configuration.ReportServerEndpointUrl, Configuration.FileSharePath));

            var itemPath = String.Format("{0}/{1}", Configuration.ReportFolder, Configuration.ReportName);
            CleanDataDrivenSubscription(ItemPath: itemPath);

            try
            {
                Console.WriteLine("Create Subscription: Try to execute creation command");
                CreateDataDrivenSubscription(
                    ItemPath: itemPath,
                    ExtensionSettings: new ExtensionSettings(
                        Definition.DestinationParameters
                    ),
                    DataRetrievalPlan: CreateDataDrivenPlan(
                        Configuration: Configuration,
                        Definition: Definition
                    ),
                    Description: Configuration.ReportName + "_Subscription",
                    EventType: "TimedSubscription",
                    MatchData: Definition.ScheduleXml.ToString(),
                    Parameters: Definition.ReportParameters.ToDatasetMapping()
                );
                Console.WriteLine("Create Subscription: Executed creation command succesfully.");
            }
            catch (SoapException e)
            {
                Console.WriteLine("Create Subscription: Failed to execute creation command.");
                Console.WriteLine(e.Detail.InnerXml.ToString());
                throw;
            }
        }

        private void CleanDataDrivenSubscription(string ItemPath)
        {
            var subscriptions = ListSubscriptions(ItemPath);
            foreach(var subscription in subscriptions)
            {
                Console.WriteLine(string.Format("Create Subscription: Delete Subscription {0}.", subscription.SubscriptionID));
                DeleteSubscription(subscription.SubscriptionID);
            }
        }
    }
}
