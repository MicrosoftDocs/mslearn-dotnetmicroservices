﻿

namespace SSRS_Subscription.ReportingServiceNamespace
{
    public partial class ExtensionSettings
    {
        public ExtensionSettings() { }

        public ExtensionSettings(Definition.DestinationParameterList DestinationParameters)
        {
            ParameterValues = DestinationParameters.ConvertDestinationParameter();
            Extension = "Report Server FileShare";
        }
    }
}
