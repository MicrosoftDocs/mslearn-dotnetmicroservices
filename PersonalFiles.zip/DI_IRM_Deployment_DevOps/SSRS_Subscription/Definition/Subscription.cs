﻿using System;
using System.IO;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Definition
{
    [XmlRoot("subscription")]
    public class Subscription
    {
        public Subscription()
        {
            ReportParameters = new ReportParameterList();
            DestinationParameters = new DestinationParameterList();
        }

        [XmlElement("schedule")]
        public XElement ScheduleXml { get; set; }

        [XmlElement("reportParameters")]
        public ReportParameterList ReportParameters { get; set; }

        [XmlElement("destinationParameters")]
        public DestinationParameterList DestinationParameters { get; set; }

        [XmlElement("sqlQuery")]
        public string SqlQuery { get; set; }

        [XmlElement("database")]
        public string DatasourceDatabaseName { get; set; }


        internal void ApplyConfiguration(SSRS_Subscription.Configuration.Subscription Configuration)
        {
            DestinationParameters.Set("PATH", Configuration.FileSharePath);
            DestinationParameters.Set("USERNAME", Configuration.FileShareUser);
            DestinationParameters.Set("PASSWORD", Configuration.FileSharePassword);
        }

        #region parser        

        internal static Subscription ParseSubscriptionXml(string SourceXml)
        {
            Subscription parameter;
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(Definition.Subscription));
                using (StringReader textReader = new StringReader(SourceXml))
                {
                    parameter = (Subscription)xmlSerializer.Deserialize(textReader);
                }
            }
            return parameter;
        }

        internal void AssertIsValid()
        {
            if (DatasourceDatabaseName == null)
            {
                throw new Exception("Field database cannot be null.");
            }
        }

        #endregion
    }
}