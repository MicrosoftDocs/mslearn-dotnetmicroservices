﻿
using System;
using System.Xml.Serialization;

namespace Definition
{

    public class ReportParameter
    {
        [XmlElement("name")]
        public string Name;

        [XmlElement("reference")]
        public string Reference;

        [XmlElement("value")]
        public string Value;


        public ParameterType Type
        {
            get
            {
                if (Name != null && Reference != null) { return ParameterType.Reference; }
                else if (Name == null && Reference != null) { return ParameterType.NonReportReference; }
                else if (Name != null && Value != null) { return ParameterType.Value; }

                throw new NotImplementedException();
            }
        }

        public enum ParameterType
        {
            Value,
            Reference,
            NonReportReference
        }
    }

}