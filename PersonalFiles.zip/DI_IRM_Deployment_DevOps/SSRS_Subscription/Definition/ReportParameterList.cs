﻿using SSRS_Subscription.ReportingServiceNamespace;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Definition
{
    [XmlRoot("reportParameters")]
    public class ReportParameterList
    {
        public ReportParameterList() { Items = new List<ReportParameter>(); }

        [XmlElement("parameter")]
        public List<ReportParameter> Items { get; set; }

        #region Converter

        internal Field[] ToDatasetParameter()
        {
            var result = new List<Field>();

            foreach (var item in Items)
            {
                switch (item.Type)
                {
                    case ReportParameter.ParameterType.Value:
                        result.Add(new Field()
                        {
                            Name = item.Name,
                            Alias = item.Name
                        });
                        break;

                    case ReportParameter.ParameterType.Reference:
                    case ReportParameter.ParameterType.NonReportReference:
                        result.Add(new Field()
                        {
                            Name = item.Reference,
                            Alias = item.Reference
                        });
                        break;

                    default:
                        throw new NotImplementedException();
                }
            }

            return result.ToArray();
        }

        internal ParameterValueOrFieldReference[] ToDatasetMapping()
        {
            var result = new List<ParameterValueOrFieldReference>();
            foreach (var item in Items)
            {
                switch (item.Type)
                {
                    case ReportParameter.ParameterType.Value:
                        result.Add(new ParameterValue()
                        {
                            Name = item.Name,
                            Value = item.Value
                        });
                        break;

                    case ReportParameter.ParameterType.Reference:
                        result.Add(new ParameterFieldReference()
                        {
                            ParameterName = item.Name,
                            FieldAlias = item.Reference
                        });
                        break;

                    case ReportParameter.ParameterType.NonReportReference:
                        break;

                    default:
                        throw new NotImplementedException();

                }
            }
            return result.ToArray();
        }

        #endregion
    }
}