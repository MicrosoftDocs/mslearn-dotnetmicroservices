﻿using SSRS_Subscription.ReportingServiceNamespace;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Definition
{
    [XmlRoot("destinationParameters")]
    public class DestinationParameterList
    {
        public DestinationParameterList() { Items = new List<DestinationParameter>(); }

        [XmlElement("parameter")]
        public List<DestinationParameter> Items { get; set; }

        internal void Set(string Name, string Value)
        {

            bool wasReplaced = false;

            foreach (var item in Items)
            {
                if (item.Name == Name)
                {
                    wasReplaced = true;
                    item.Value = Value;
                }
            }

            if (wasReplaced == false)
            {
                Items.Add(new DestinationParameter() { Name = Name, Value = Value });
            }
        }

        #region Converter

        internal ParameterValueOrFieldReference[] ConvertDestinationParameter()
        {
            var result = new List<ParameterValueOrFieldReference>();
            foreach (var item in Items)
            {
                switch (item.Type)
                {
                    case DestinationParameter.ParameterType.Value:
                        result.Add(new ParameterValue()
                        {
                            Name = item.Name,
                            Value = item.Value
                        });
                        break;

                    case DestinationParameter.ParameterType.Reference:
                        result.Add(new ParameterFieldReference()
                        {
                            ParameterName = item.Name,
                            FieldAlias = item.Reference
                        });
                        break;

                    default:
                        throw new NotImplementedException();

                }
            }
            return result.ToArray();
        }

        #endregion
    }
}