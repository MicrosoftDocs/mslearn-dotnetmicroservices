﻿
using System;
using System.Xml.Serialization;

namespace Definition
{

    public class DestinationParameter
    {
        [XmlElement("name")]
        public string Name;

        [XmlElement("value")]
        public string Value;

        [XmlElement("reference")]
        public string Reference;

        public ParameterType Type
        {
            get
            {
                if (Value != null) { return ParameterType.Value; }
                else if (Reference != null) { return ParameterType.Reference; }

                throw new NotImplementedException();
            }
        }

        public enum ParameterType
        {
            Value,
            Reference
        }
    }

}