﻿
using CommandLine;
using CommandLine.Attributes;
using System;
using System.IO;
using System.Net;
using System.Web.Services.Protocols;

namespace SSRS_Subscription
{

    class Program
    {
        #region Command Line Options

        class Options
        {

            [RequiredArgument(0, "Path", "Path to the XML subscription definition.")]
            public string Path { get; set; }

            [RequiredArgument(1, "ReportServerEndpointUrl", "Report Server Web Service Endpoint.")]
            public string ReportServerEndpointUrl { get; set; }
            
            [RequiredArgument(2, "ReportName", "Name of the report of the subscription.")]
            public string ReportName { get; set; }

            [RequiredArgument(3, "ReportFolder", "Path of the folder in that the report of the subscription resides.")]
            public string ReportFolder { get; set; }

            [RequiredArgument(4, "DatasourceServerInstance", "Hostname to the SQL Server of the datasource.")]
            public string DatasourceServerInstance { get; set; }

            [RequiredArgument(5, "Username", "Name of the user that accesses the database and the file share.")]
            public string Username { get; set; }

            [RequiredArgument(6, "Password", "Password of the specified user.")]
            public string Password { get; set; }

            [RequiredArgument(7, "FileShare", "UNC path to the folder in that the reports are saved.")]
            public string FileShare { get; set; }

        }

        #endregion
        #region Helper

        internal static ReportingServiceNamespace.ReportingService2010 GetReportServer(string EndpointUrl)
        {
            var reportServer = new ReportingServiceNamespace.ReportingService2010
            {
                UseDefaultCredentials = true,
                Url = EndpointUrl
            };
            try
            {
                var result = reportServer.ListChildren("/", Recursive: false);
                Console.WriteLine("Create Subscription: Opened Report Server connection successfully.");

                System.Net.NetworkCredential credential = (System.Net.NetworkCredential)reportServer.Credentials;
                Console.WriteLine(string.Format("Create Subscription: With user '{0}'", credential.UserName));
            }
            catch (SoapException e)
            {
                Console.WriteLine("Create Subscription: Failed to open Report Server connection.");
                Console.WriteLine(e.Detail.OuterXml);

                System.Net.NetworkCredential credential = (System.Net.NetworkCredential)reportServer.Credentials;
                Console.WriteLine(string.Format("Create Subscription: With user '{0}'", credential.UserName));
                throw;
            }

            return reportServer;
        }

        #endregion
        #region Main

        static void Main(string[] args)
        {
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            Console.WriteLine(string.Format("Main: Run as '{0}'", System.Security.Principal.WindowsIdentity.GetCurrent().Name));

            // parse command line arguments
            Options options;
            if (!Parser.TryParse(args, out options)) { return; }

            Console.WriteLine("Main: Get configuration.");

            var configuration = new Configuration.Subscription(
                ReportServerEndpointUrl: options.ReportServerEndpointUrl,
                ReportName: options.ReportName,
                ReportFolder: options.ReportFolder,

                DatasourceServer: options.DatasourceServerInstance,
                DatasourceUser: options.Username,
                DatasourcePassword: options.Password,

                FileShareUser: options.Username,
                FileSharePassword: options.Password,
                FileSharePath: options.FileShare
            );

            Console.WriteLine(string.Format("Main: Parse Subscription Definition from '{0}'.", options.Path));

            var definition = Definition.Subscription.ParseSubscriptionXml(File.ReadAllText(options.Path));
            definition.ApplyConfiguration(Configuration: configuration);
            definition.AssertIsValid();

            Console.WriteLine(string.Format("Main: Connect to Report Server '{0}'.", configuration.ReportServerEndpointUrl));

            var reportServer = GetReportServer(configuration.ReportServerEndpointUrl);

            Console.WriteLine("Main: Create Subscription.");
            reportServer.CreateDataDrivenSubscription(Definition: definition, Configuration: configuration);
        }

        #endregion

    }


}
