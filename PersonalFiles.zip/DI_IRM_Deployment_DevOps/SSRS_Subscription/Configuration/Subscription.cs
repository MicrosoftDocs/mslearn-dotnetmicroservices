﻿
namespace SSRS_Subscription.Configuration
{
    public class Subscription
    {
        public string ReportServerEndpointUrl { get; set; }
        public string ReportName { get; set; }
        public string ReportFolder { get; set; }
        public string DatasourceServer { get; set; }
        public string DatasourceUser { get; set; }
        public string DatasourcePassword { get; set; }
        public string FileShareUser { get; set; }
        public string FileSharePassword { get; set; }
        public string FileSharePath { get; set; }

        public Subscription(string ReportServerEndpointUrl, string ReportName, string ReportFolder, string DatasourceServer, string DatasourceUser, string DatasourcePassword, string FileShareUser, string FileSharePassword, string FileSharePath)
        {
            this.ReportServerEndpointUrl = ReportServerEndpointUrl;
            this.ReportName = ReportName;
            this.ReportFolder = ReportFolder.TrimEnd(new[] { '/' });
            this.DatasourceServer = DatasourceServer;
            this.DatasourceUser = DatasourceUser;
            this.DatasourcePassword = DatasourcePassword;
            this.FileShareUser = FileShareUser;
            this.FileSharePassword = FileSharePassword;
            this.FileSharePath = FileSharePath;
        }
    }
}
