<#
    .SYNOPSIS
    Powershell Script deploy_ssrs_subscription.ps1

    .NOTES
    Date:       2018-02-21
    Author:     Steffen Kampmann
    Version:    1.0

    .DESCRIPTION
    This script deploys a Report Subscription XML file.

    .COMPONENT
    Deployed with this script:
    - SSRS_Subscription.exe

    .PARAMETER Path
    Path to the XML subscription definition.

    .PARAMETER ProjectName
    The Name of the project, that contains this subscription.
    It is used to read additional parameters from the ARA.xml .

    .PARAMETER Environment
    The environment in which the subscription needs to be deployed.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER ReportServerInstance
    Hostname to the SQL Server Report Server.

    .PARAMETER Username
    Name of the user that accesses the database and the file share.

    .PARAMETER Password
    Password of the specified user.

    .PARAMETER DeploySsrsSubscriptionPath
    Path to the SSRS_Subscription.exe .
    If not defined, it is ./SSRS_Subscription.exe

    .PARAMETER AraXmlPath
    Path to the ARA.xml .
    If not definied, it is ../ARA.xml .

    .PARAMETER DeploymentHelperPath
    Path to the Powershell functions of DeploymentHelper.

    .PARAMETER LogfilePath
    Path to the logfile of this script

#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $PathTemplate = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $ReportServerInstance = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Username = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Password = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $DeploySsrsSubscriptionPath = "./SSRS_Subscription.exe",

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_ssrs_subscription.log",

    [ValidateScript({Test-Path $_})]
    [string] $Path = $PathTemplate.Replace('.xml', '.subscription.xml').Replace('.subscription.subscription', '.subscription')
)

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."


#region Command Wrapper

function Invoke-DeploySubscription
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ReportName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ReportFolder,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ReportServerEndpointUrl,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatasourceServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Username,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $Password,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $FileShare
    )

    Write-ToLogfile "Deploy subscription for $ReportName" -Region $region
    Write-ToLogfile "-Path $Path" -Region $region
    Write-ToLogfile "-ReportName $ReportName" -Region $region
    Write-ToLogfile "-ReportFolder $ReportFolder" -Region $region
    Write-ToLogfile "-ReportServerEndpointUrl $ReportServerEndpointUrl" -Region $region
    Write-ToLogfile "-DatasourceServerInstance $DatasourceServerInstance" -Region $region
    Write-ToLogfile "-Username $Username" -Region $region
    Write-ToLogfile "-Password $( $Password.Length )" -Region $region
    Write-ToLogfile "-FileShare $FileShare" -Region $region

    $process = Start-Process `
        -FilePath $DeploySsrsSubscriptionPath `
        -ArgumentList $Path, $ReportServerEndpointUrl, $ReportName, $ReportFolder, $DatasourceServerInstance, $Username, $Password, $FileShare `
        -RedirectStandardOutput "$LogfilePath-$ReportName-output.log" `
        -RedirectStandardError "$LogfilePath-$ReportName-error.log" `
        -NoNewWindow -PassThru -Wait

    [bool] $isErrorCode = $process.ExitCode -ne 0
    [bool] $isErrorOutput = ( Get-Content -Path "$LogfilePath-$ReportName-error.log" ).Length -gt 0
    if ($isErrorCode -or $isErrorOutput)
    {
        throw "Deployment failed."
    } else {
        Write-ToLogfile "Deployment successful." -Region $region
    }
}

#endregion
#region Main Routine
#region Prepare
$region = "Prepare"

try
{
    #region Load ARA.xml
    $region = "Prepare", "Load ARA"

    Write-ToLogfile "Get ReportName." -Region $region
    [string] $ReportName = ( Get-Item -Path $Path ).Name.Replace(".subscription.xml", "").Replace(".xml", "")

    Write-ToLogfile "Check AraXmlPath '$AraXmlPath'." -Region $region
    if ( ( Test-Path -Path $AraXmlPath ) -eq $false )
    {
        throw "'$AraXmlPath' not found."
    }

    Write-ToLogfile "Get subscription parameter from '$AraXmlPath'." -Region $region
    $xPath = "//project[@name=""$ProjectName""]//module[@type=""ssrs""]//environment[@name=""$Environment""]//subscription[@reportname=""$ReportName""]"
    $subscription = ( Select-XmlWithEntities -Path $AraXmlPath -XPath $xPath ).Node

    if ( $subscription -eq $null )
    {
        throw "Missing subscription for $xPath"
    }

    Write-ToLogfile "Get module parameter from '$AraXmlPath'." -Region $region
    $xPath = "//project[@name=""$ProjectName""]//module[@type=""ssrs""]//add[@key=""TargetServerURL"" and @env=""$Environment""]"
    $targetServerUrlNode = ( Select-XmlWithEntities -Path $AraXmlPath -XPath $xPath ).Node

    if ( $targetServerUrlNode -eq $null )
    {
        throw "Missing TargetServerUrl for $xPath"
    }

    #endregion
    #region Load parameters from ARA.xml
    $region = "Prepare", "Load Parameter"


    [string] $ReportServerEndpointUrl = "$( $targetServerUrlNode.value)/ReportService2010.asmx"
    if ( $targetServerUrlNode.value -eq $null )
    {
        throw "Missing ReportServerEndpointUrl"
    }

    [string] $ReportFolder = $subscription.reportpath
    if ( $ReportFolder -eq $null )
    {
        throw "Missing ReportFolder"
    }

    [string] $DatasourceServerInstance = $subscription.datasourceServerInstance
    if ($DatasourceServerInstance -eq $null)
    {
        throw "Missing DatasourceServerInstance"
    }

    [string] $FileShare = $subscription.fileshare
    if ( $FileShare -eq $null )
    {
        throw "Missing FileShare"
    }

    #endregion
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message $_.Exception -Region $region
    exit 1
}

#endregion
#region Deploy
$region = "Deploy"

try
{
    Invoke-DeploySubscription -Path $Path `
        -ReportName $ReportName -ReportFolder $ReportFolder `
        -ReportServerEndpointUrl $ReportServerEndpointUrl -DatasourceServerInstance $DatasourceServerInstance `
        -Username $Username -Password $Password `
        -FileShare $FileShare
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message $_.Exception -Region $region
    exit 1
}

#endregion
#endregion
