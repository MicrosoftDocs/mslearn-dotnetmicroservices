﻿[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy.log"
)

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Import-Module ( Join-Path $PSScriptRoot 'PowershellDeployment.psd1' )

Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

try {
    Get-AraScriptCommand `
        -AraXmlPath $AraXmlPath `
        -ProjectName $ProjectName `
        -Environment $Environment `
        -ScriptFolderName $ScriptFolderName `
        -ModuleName $ModuleName |
    ConvertTo-PowershellDeploymentConfig |
    Invoke-PowershellDeployment -ScriptFolderPath $ScriptFolderPath
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message $_.Exception
    throw
}

#endregion
