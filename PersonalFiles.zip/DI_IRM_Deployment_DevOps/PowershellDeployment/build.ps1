[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ModuleName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Xml.XmlElement] $ConfigNode,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string] $StagingDirectory,

    $AvailableProjects
)

Import-Module ( Join-Path -Path $PSScriptRoot -ChildPath 'PowershellDeployment.psd1' )

$configs = Get-ScriptModuleBuildConfiguration -ConfigNode $ConfigNode -ModuleName $ModuleName -ProjectName $ProjectName | ConvertTo-PowershellDeploymentConfig

if ( -not $configs ) {
    Write-ToLogfile "scriptcommand not found for module '$ModuleName' and project '$ProjectName'"
}

foreach ( $config in $configs ) {

    $AvailableProjects |
    Where-Object { $config.Project -eq $_.Name } |
    Copy-Item -Destination $StagingDirectory -Recurse

    Remove-Item "$StagingDirectory\$( $config.Project )\bin" -Recurse -ErrorAction 'Continue'

    $AvailableProjects |
    Where-Object { @( $config.Dependencies | ForEach-Object { $_.Project } ).Contains( $_.Name ) } |
    Copy-Item -Destination $StagingDirectory -Recurse

    $config.Dependencies | ForEach-Object { $_.Package } |
    Where-Object { $_ } |
    ForEach-Object {

        $tempDownload = Join-Path $ENV:TEMP $( [guid]::newguid() )
        New-Item $tempDownload -ItemType Container | Out-Null

        $package = Find-Module -Name $_ |
        Save-Module -Destination $tempDownload

        [System.IO.Compression.ZipFile]::ExtractToDirectory($package.FullName, "$StagingDirectory\$_")
    }

}
