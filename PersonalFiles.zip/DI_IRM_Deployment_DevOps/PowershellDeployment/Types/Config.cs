using System.Collections.Generic;
using DeploymentHelper.Config;

namespace PowershellDeployment.Config
{
    public abstract class Dependency
    {
    }

    public class ProjectDependency : Dependency
    {
        public string Project { get; set; }
    }

    public class PackageDependency : Dependency
    {
        public string Package { get; set; }
    }

    public class Deployment
    {
        public string Project { get; set; }
        public string DestinationServer { get; set; }
        public string DestinationPath { get; set; }

        public bool Integrate { get; set; }
        public List<Dependency> Dependencies { get; set; }
        public List<XmlFile> XmlFiles { get; set; }
    }
}
