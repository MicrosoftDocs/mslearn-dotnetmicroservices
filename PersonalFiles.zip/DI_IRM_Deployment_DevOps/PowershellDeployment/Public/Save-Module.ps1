function Save-Module {
    <#
        .Synopsis
            A wrapper for Invoke-WebRequest -OutFile to save modules with the nuget package file names
    #>
    [CmdletBinding()]
    param (
        # The Url to download from
        [Parameter(ValueFromPipelineByPropertyName=$true, Mandatory=$true)]
        $Url,

        # The name of the module (for naming the output file)
        [Parameter(ValueFromPipelineByPropertyName=$true, Mandatory=$true)]
        $Name,

        # The version of the module (for naming the output file)
        [Parameter(ValueFromPipelineByPropertyName=$true)]
        $Version="",

        # The folder to save to
        [Alias("Path")]
        [string]$Destination = $pwd
    )
    process {
        if($Destination -eq "CurrentUser") {
            $Destination = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "WindowsPowerShell\Modules"
        }
        if($Destination -eq "AllUsers" -or $Destination -eq "LocalMachine") {
            $Destination = Join-Path ([Environment]::GetFolderPath("ProgramFiles")) "WindowsPowerShell\Modules"
        }
        if(-not (Test-Path $Destination)) {
            $null = mkdir $Destination -force
        }

        $Path = Join-Path $Destination "$Name.$Version.nupkg"
        if ( Test-Path $Path ) {
            Write-Verbose "Download skipped. Module '$Path' already exists."
        }
        else {
            Write-Verbose "Start download of module '$Path'."
            Invoke-WebRequest $Url -OutFile $Path
        }

        $result = Get-Item $Path
        $result | Add-Member ModuleName $Name
        $result | Add-Member ModuleVersion $Version
        Write-Output $result
    }
}
