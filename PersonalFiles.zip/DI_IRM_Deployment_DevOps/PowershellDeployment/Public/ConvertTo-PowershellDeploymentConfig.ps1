function ConvertTo-PowershellDeploymentConfig {

    <#

    .SYNOPSIS
    Convert XML to Deployment Config

    .DESCRIPTION

    The XML configuration will be converted to a .NET object, that can be used to parameterize `Invoke-PowershellDeployment`.

    .PARAMETER Node
    The XML node that contains the configuration infromation.

    .OUTPUTS
    PowershellDeployment.Config.Deployment

    #>

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true )]
        [System.Xml.XmlNode] $Node
    )

    process {
        $config = New-Object PowershellDeployment.Config.Deployment -Property @{
            Project = $Node.Attributes['project'].Value
            Dependencies = New-Object System.Collections.Generic.List[PowershellDeployment.Config.Dependency]
            DestinationServer = $Node.Attributes['destinationServer'].Value
            DestinationPath = $Node.Attributes['destinationPath'].Value
            XmlFiles = New-Object System.Collections.Generic.List[DeploymentHelper.Config.XmlFile]
        }

        if ( $Node.Attributes['integrate'].Value -eq 'true' )
        {
            $config.Integrate = $true
        }
        else
        {
            $config.Integrate = $false
        }

        # depenencies
        foreach ( $changeXml in Select-Xml -Xml $Node -XPath './dependency' ) {
            if ( $changeXml.Node.Attributes['project'].Value ) {
                $dependency = New-Object PowershellDeployment.Config.ProjectDependency -Property @{
                    Project = $changeXml.Node.Attributes['project'].Value
                }
            }

            if ( $changeXml.Node.Attributes['package'].Value ) {
                $dependency = New-Object PowershellDeployment.Config.PackageDependency -Property @{
                    Package = $changeXml.Node.Attributes['package'].Value
                }
            }

            $config.Dependencies.Add( $dependency )
        }

        Select-Xml -Xml $Node -XPath './xmlFile' |
            ConvertTo-XmlFileConfig |
            ForEach-Object { $config.XmlFiles.Add( $_ ) }

        $config | Write-Output
    }
}
