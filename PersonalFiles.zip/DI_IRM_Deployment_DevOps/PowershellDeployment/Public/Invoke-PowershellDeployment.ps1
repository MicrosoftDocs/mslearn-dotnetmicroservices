function Invoke-PowershellDeployment {

    <#

    .SYNOPSIS
    Deploys a PowershellProject

    .DESCRIPTION
    Deploys a Powershell build artefact to a server.
    The deployment is based on a Poweshell copy command using PSRemoting.

    .PARAMETER Name
    Specifies the name of the project and to the folder name.

    .PARAMETER DestinationServer
    Specifies the Server to deploy the project to.

    .PARAMETER DestinationPath
    Specifies the local path on the destination server.

    .PARAMETER Dependencies
    Sepecifies the names of the powershell modules that the project depend on.

    .PARAMETER ScriptFolderPath
    Specifies the path to the unzipped build artefact.

    .INPUTS
    PowershellDeployment.Config.Deployment

    #>

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $Project,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $DestinationServer,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $DestinationPath,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [bool] $Integrate,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [PowershellDeployment.Config.Dependency[]] $Dependencies,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [DeploymentHelper.Config.XmlFile[]] $XmlFiles,

        [Parameter( Mandatory = $true )]
        [ValidateScript( { Test-Path $_ } )]
        [string] $ScriptFolderPath
    )

    process {

        $localPath = "$ScriptFolderPath\..\..\$Project"

        Write-ToLogfile 'Start change XML files'
        $XmlFiles | Invoke-XmlFileChanges -BasePath $localPath
        Write-ToLogfile 'XML change done'

        Write-ToLogfile "Start copy of '$Project' to '$DestinationPath' on '$DestinationServer'."
        if ( $Integrate ) {
            Get-ChildItem -Path $localPath | ForEach-Object {
                Copy-ItemToRemote -LocalPath $_.FullName -ServerInstance $DestinationServer -RemotePath $DestinationPath
            }
        } else {
            Copy-ItemToRemote -LocalPath $localPath -ServerInstance $DestinationServer -RemotePath $DestinationPath
        }
        Write-ToLogfile "Copy done."

        $Dependencies | ForEach-Object {
            if ( $_.Project ) { Write-Output $_.Project }
            if ( $_.Package ) { Write-Output $_.Package }
        } | ForEach-Object {
            Write-ToLogfile "Start copy of '$_' to '$DestinationPath' on '$DestinationServer'."
            Copy-ItemToRemote -LocalPath "$ScriptFolderPath\..\..\$_" -ServerInstance $DestinationServer -RemotePath $DestinationPath
            Write-ToLogfile "Copy done."
        }
    }
}
