# PowershellDeployment

## Configuration

``` xml
<scriptcommand scriptfolder="PowershellDeployment" project="..." destinationServer="..." destinationPath="..." >
    <dependency project="..." />
</scriptcommand>
```

The `project` attribute specifies the folder name that contains the Powershell module.
The `destinationServer` attribute specifies the servername, to deploy the Powershell module to.
The `destinationPath` attribute specifies the local path on the `destinationServer` of the Powershell module.
There can be a list of dependencies which are other Powershell modules that need to be deployed as well.

## Build

The build is managed by the BuildHelper module. It creates a zip file containing the deployment script and Powershell modules.

## Deployment

See the documentation of the `Invoke-PowershellDeployment` function.
