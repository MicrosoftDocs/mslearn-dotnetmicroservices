function Set-DatabaseDataFile
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]
        $RowsMinSizeGB,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]
        $RowsGrowthGB
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\01_Configure_Database_Files.sql" `
        -Arguments `
            "DatabaseName = ""$DatabaseName""", `
            "FileName = ""$DatabaseName""", `
            "MinSizeKB = ""$( $RowsMinSizeGB * 1024 * 1024 )""", `
            "GrowthKB = ""$( $RowsGrowthGB * 1024 * 1024 )""" `
        -Timeout 600
}