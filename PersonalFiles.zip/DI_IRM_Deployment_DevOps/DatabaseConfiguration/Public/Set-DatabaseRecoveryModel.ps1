function Set-DatabaseRecoveryModel
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\02_Configure_RecoveryModel.sql" `
        -Arguments `
            "DatabaseName = ""$DatabaseName"""
}