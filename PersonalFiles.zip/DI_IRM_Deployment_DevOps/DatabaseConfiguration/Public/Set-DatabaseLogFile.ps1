function Set-DatabaseLogFile
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]
        $LogMinSizeGB,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]
        $LogGrowthGB
    )

    Invoke-SqlCmd -ServerInstance $ServerInstance -Path "$ScriptFolderPath\01_Configure_Database_Files.sql" `
        -Arguments `
            "DatabaseName = ""$DatabaseName""", `
            "FileName = ""$( $DatabaseName )_log""", `
            "MinSizeKB = ""$( $LogMinSizeGB * 1024 * 1024 )""", `
            "GrowthKB = ""$( $LogGrowthGB  * 1024 * 1024 )""" `
        -Timeout 600
}