/*

    # Configure_Database_Files

    Configures the minimal database file sizes and auto growth settings.

    Date: 27.04.2018
    Autor: Steffen Kampmann

    ## Parameters

    DatabaseName
    FileName
    MinSizeKB
    GrowthKB

*/

IF EXISTS ( SELECT TOP 1 1 FROM [$(DatabaseName)].[sys].[database_files] f WHERE f.[name] LIKE '$(FileName)' AND $(MinSizeKB) > f.[size] * 8 )
BEGIN

    RAISERROR ('Start Configuration of %s.', 0, 1, '$(FileName)') WITH NOWAIT

	ALTER DATABASE [$(DatabaseName)]
        MODIFY FILE (
            NAME = $(FileName),
            SIZE = $(MinSizeKB)KB,
            FILEGROWTH = $(GrowthKB)KB
        )

    RAISERROR ('Finished Configuration of %s.', 0, 1, '$(FileName)') WITH NOWAIT

END
ELSE
BEGIN

    RAISERROR ('Skipped Configuration of %s.', 0, 1, '$(FileName)') WITH NOWAIT

END