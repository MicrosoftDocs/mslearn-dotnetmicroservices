﻿<#

    .SYNOPSIS
    Deploy SQL scripts for DatabaseConfiguration

    .NOTES
    Date:       2018-03-21
    Author:     Steffen Kampmann
    Version:    1.0

    Date:       2018-04-06
    Author:     Steffen Kampmann
    Version:    1.1

    - Copied to project DatabaseConfiguration

    .PARAMETER ProjectName
    The project of the sql script.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER Environment
    The environment in which the script needs to be executed.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER AraXmlPath
    Path to the ARA.xml .
    If not definied, it is ../ARA.xml

    .PARAMETER DeplyomentHelperPath
    Path to the Powershell functions of DeploymentHelper.

    .PARAMETER LogfilePath
    Path to the logfile of this script

#>

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $ScriptFolderName = (( Get-Item $MyInvocation.InvocationName ).Directory.Name ),

    [ValidateScript({Test-Path $_})]
    [string] $ScriptFolderPath = (( Get-Item $MyInvocation.InvocationName ).Directory.FullName ),

    [ValidateNotNullOrEmpty()]
    [string] $ModuleName = (( Get-Item $MyInvocation.InvocationName ).Directory.Parent.Parent.Name.Replace( "$( $ProjectName )_", '' ) ),

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy.log"
)

$ErrorActionPreference = 'Stop'

Import-Module $DeploymentHelperPath
Import-Module ( Join-Path $PSScriptRoot 'DatabaseConfiguration.psd1' )

Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."

#region Load parameter from ARA.xml

Write-ToLogfile "Prepare: ScriptFolder is '$ScriptFolderName'"
Write-ToLogfile "Prepare: Get parameter from $AraXmlPath."

$tokenPath = Join-Path ( Get-Item $AraXmlPath ).Directory.FullName "script_$ScriptFolderName.token"
if ( Test-Path $tokenPath )
{
    Write-ToLogfile "Prepare: Token: Skip ScriptFolder '$ScriptFolderName'"
    exit 0
}
else {
    Write-ToLogfile "Prepare: Token: Create"
    Set-Content -Path $tokenPath -Value Get-Date
}

try {
    $scriptCommands = Get-AraScriptCommand -AraXmlPath $AraXmlPath -ProjectName $ProjectName -Environment $Environment -ScriptFolderName $ScriptFolderName -ModuleName $ModuleName
}
catch {
    Write-ToLogfile -Level 'ERROR' -Message "Prepare:Load ARA: $( $_.Exception )"
    throw
}

#endregion
#region Execute
Write-ToLogFile "Execute: Start"

try
{
    foreach ($scriptCommand in $scriptCommands)
    {
        [string] $ServerInstance = $scriptCommand.serverInstance
        [string] $DatabaseName = $scriptCommand.databaseName

        Set-DatabaseRecoveryModel -ServerInstance $ServerInstance -ScriptFolderPath $ScriptFolderPath -DatabaseName $DatabaseName

        [string] $RowsMinSizeGB = $scriptCommand.rowsMinSizeGB
        [string] $RowsGrowthGB = $scriptCommand.rowsGrowthGB

        Set-DatabaseDataFile -ServerInstance $ServerInstance -ScriptFolderPath $ScriptFolderPath -DatabaseName $DatabaseName `
            -RowsMinSizeGB $RowsMinSizeGB -RowsGrowthGB $RowsGrowthGB

        [string] $LogMinSizeGB = $scriptCommand.logMinSizeGB
        [string] $LogGrowthGB = $scriptCommand.logGrowthGB

        Set-DatabaseLogFile -ServerInstance $ServerInstance -ScriptFolderPath $ScriptFolderPath -DatabaseName $DatabaseName `
            -LogMinSizeGB $LogMinSizeGB -LogGrowthGB $LogGrowthGB
    }
}
catch
{
    Write-ToLogfile -Level 'ERROR' -Message "Execute: $( $_.Exception )"
    throw
}

Write-ToLogFile "Execute: End"
#endregion
