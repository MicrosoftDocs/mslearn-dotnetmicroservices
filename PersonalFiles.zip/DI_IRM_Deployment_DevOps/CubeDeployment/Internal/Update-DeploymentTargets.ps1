function Update-DeploymentTargets
{
    [CmdletBinding()]
    param(
        [Parameter( Mandatory = $true )]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionString
    )

    $xml = New-Object XML
    $xml.Load($Path)

    $element =  $xml.SelectSingleNode("//Server")
    $element.InnerText = $ServerInstance
    Write-ToLogFile "Changed Server to $ServerInstance."

    $element =  $xml.SelectSingleNode("//ConnectionString")
    $element.InnerText = $ConnectionString
    Write-ToLogFile "Changed ConnectionString to $ConnectionString."

    $xml.Save($Path)
}