function Get-OlapDatabase {

    [CmdletBinding()]
    param(
        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName
    )
    Write-ToLogFile "Get OLAP database [$DatabaseName] from '$ServerInstance'."

    $server = New-Object Microsoft.AnalysisServices.Server
    $server.Connect("Data source=$ServerInstance")

    try {
        $server.Databases | Where-Object { $_.Name -eq $DatabaseName }
    }
    finally {
        $server.Disconnect()
    }
}
