function Invoke-XmlaScript {

    [CmdletBinding()]
    param(
        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter( Mandatory = $true, ParameterSetName = 'File' )]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter( Mandatory = $true, ParameterSetName = 'String' )]
        [ValidateNotNullOrEmpty()]
        [string] $Command
    )

    switch ( $PSCmdlet.ParameterSetName )
    {
        File {
            Write-ToLogfile "Load command from '$Path'."
            $Command = Get-Content -Path $Path -Raw
        }
    }

    $server = New-Object Microsoft.AnalysisServices.Server
    $server.Connect("Data source=$ServerInstance")

    try {
        $failed = $false
        [Microsoft.AnalysisServices.XmlaResultCollection] $result = $server.Execute($Command)
        foreach ( $resultElement in $result ) {
            foreach ( $message in $resultElement.Messages ) {
                switch ( $message.GetType().Name ) {
                    XmlaError {
                        Write-ToLogfile $message.Description -Level 'Error'
                        $failed = $true
                    }
                    Default {
                        Write-ToLogfile $message.Description
                    }
                }
            }
        }
    }
    finally {
        $server.Disconnect()
    }

    if ( $failed ) {
        throw "Error executing XMLA"
    }
}
