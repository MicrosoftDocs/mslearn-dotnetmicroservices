function Update-DeploymentOptions
{
    [CmdletBinding()]
    param(
        [Parameter( Mandatory = $true )]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter( Mandatory = $true )]
        [ValidateSet('Default', 'Full', 'DoNotProcess')]
        [string] $ProcessingOption
    )

    $xml = New-Object XML
    $xml.Load($Path)

    $element =  $xml.SelectSingleNode("//PartitionDeployment")
    $element.InnerText = "RetainPartitions"
    Write-ToLogFile "Changed PartitionDeployment to RetainPartitions."

    $element =  $xml.SelectSingleNode("//RoleDeployment")
    $element.InnerText = "DeployRolesAndMembers"
    Write-ToLogFile "Changed RoleDeployment to DeployRolesAndMembers."

    $element =  $xml.SelectSingleNode("//ProcessingOption")
    $element.InnerText = $ProcessingOption
    Write-ToLogFile "Changed ProcessingOption to '$ProcessingOption'."

    $xml.Save($Path)
}
