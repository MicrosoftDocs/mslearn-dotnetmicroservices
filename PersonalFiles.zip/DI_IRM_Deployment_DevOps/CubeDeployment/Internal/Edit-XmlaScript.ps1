function Edit-XmlaScript {

    [CmdletBinding()]
    param(

        [Parameter( Mandatory = $true )]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateSet('insert', 'update', 'delete')]
        [string] $Operation,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $XPath,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [string] $Value
    )

    process {

        $xPathNamespace = @{ ssas = "http://schemas.microsoft.com/analysisservices/2003/engine" }

        switch ( $Operation ) {
            update {
                Write-ToLogfile "Update '$XPath'."
                $nodes = Select-Xml -Path $Path -XPath $XPath -Namespace $xPathNamespace
                if ( -not $nodes ) {
                    throw "XPath '$XPath' not found in '$Path'"
                }
                $nodes | ForEach-Object {
                    Write-ToLogfile "Set '$Value'"
                    $_.Node.InnerXml = $Value
                    $_.Node.OwnerDocument.Save($Path)
                }
            }
            insert {
                Write-ToLogfile "Insert '$XPath'."
                $nodes = Select-Xml -Path $Path -XPath $XPath -Namespace $xPathNamespace
                if ( -not $nodes ) {
                    throw "XPath '$XPath' not found in '$Path'"
                }
                $nodes | ForEach-Object {
                    Write-ToLogfile "Add '$Value'"
                    $document = $_.Node.OwnerDocument
                    $_.Node.AppendChild( $document.ImportNode( ( [xml] $Value ).FirstChild, $true ) ) | Out-Null
                    $_.Node.InnerXml = $_.Node.InnerXml.Replace(' xmlns=""', '')
                    $document.Save( $Path )
                }
            }
            delete {
                Write-ToLogfile "Delete '$XPath'."
                $nodes = Select-Xml -Path $Path -XPath $XPath -Namespace $xPathNamespace
                if ( -not $nodes ) {
                    Write-ToLogfile "XPath '$XPath' not found in '$Path'"
                } else {
                    $nodes | ForEach-Object {
                        Write-ToLogfile "Delete"
                        $_.Node.ParentNode.RemoveChild($_.Node) | Out-Null
                        $_.Node.OwnerDocument.Save($Path)
                    }
                }
            }
            default {
                throw "xmlaconfig type '$_' is not implemented."
            }
        }
    }
}
