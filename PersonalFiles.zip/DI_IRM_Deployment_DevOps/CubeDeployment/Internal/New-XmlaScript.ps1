function New-XmlaScript
{
    <#

    .LINK https://docs.microsoft.com/en-us/analysis-services/multidimensional-models/deploy-model-solutions-with-the-deployment-utility

    #>
    [CmdletBinding()]
    param(
        [Parameter( Mandatory = $true )]
        [ValidateScript({Test-Path $_})]
        [string] $ASDatabasePath,

        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $XmlaScriptPath,

        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $LogPath,

        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $SSAServicesDeploymentUtilityPath
    )

    $execCommand = "& `"$SSAServicesDeploymentUtilityPath`" `"$ASDatabasePath`" /s:`"$LogPath`" /o:`"$XmlaScriptPath`""
    Invoke-Expression $execCommand

    if ( -not ( Test-Path $XmlaScriptPath ) ) {
        throw "XMLA script '$XmlaScriptPath' was not created."
    }
}