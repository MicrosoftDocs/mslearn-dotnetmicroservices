function Remove-OlapDatabase {

    [CmdletBinding()]
    param(
        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter( Mandatory=$true )]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName
    )

    Invoke-XmlaScript -ServerInstance $ServerInstance -Command @"
<Delete xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">
<Object>
<DatabaseID>$DatabaseName</DatabaseID>
</Object>
</Delete>
"@

}
