# CubeDeployment

## Configuration

``` powershell
<scriptcommand scriptfolder="CubeDeployment" serverInstance="..." databaseName="..." version="..." processing="..." >
    <!-- Datasources -->
    <xmlaconfig xpath="//ssas:DataSource[ssas:Name='...']/ssas:ConnectionString" value="..." type="update" />
    <xmlaconfig xpath="//ssas:DataSource[ssas:Name='...']/ssas:ImpersonationInfo/ssas:Account" value="..." type="update" />
    <xmlaconfig xpath="//ssas:DataSource[ssas:Name='...']/ssas:ImpersonationInfo" value="&lt;Password&gt;...&lt;/Password&gt;" type="insert" />
    <!-- Roles -->
    <xmlaconfig xpath="//ssas:Role/ssas:Members" type="delete" />
    <xmlaconfig xpath="//ssas:Role[ssas:Name='Reader']" type="insert" value="&lt;Members&gt;&lt;Member&gt;&lt;Name&gt;...&lt;/Name&gt;&lt;Sid&gt;...&lt;/Sid&gt;&lt;/Member&gt;&lt;/Members&gt;" />
</scriptcommand>
```

The attribute `serverInstance` specifies the server of the SSAS instance.
The attribute `databaseName` specifies the database name or project name.
The attribute `version` specifies if a initial deployment is necessary and the database must be dropped first.
The attribute `processing` specifies if the cube must be processed after deployment or not. Options are 'Default', 'Full' and 'DoNotProcess'.

Changes on the generated XMLA code can be specified with `xmlaconfig` elements.
Every element needs a `xpath` attribute to select the location in the document. There are examples for data source connection strings and account information or role members.
Insert and update changes need additionally `value` attributes. That must be XML escaped.

## Build

The build is managed by the BuildHelper module. It creates a zip file containing the deployment script and Cube modules.

## Deployment

See the documentation of the `Invoke-CubeDeployment` function.
