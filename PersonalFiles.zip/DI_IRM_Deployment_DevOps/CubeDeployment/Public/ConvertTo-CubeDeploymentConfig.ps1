function ConvertTo-CubeDeploymentConfig {

    <#

    .SYNOPSIS
    Convert XML to Deployment Config

    .DESCRIPTION

    The XML configuration will be converted to a .NET object, that can be used to parameterize `Invoke-CubeDeployment`.

    .PARAMETER Node
    The XML node that contains the configuration infromation.

    .OUTPUTS
    CubeDeployment.Config.Deployment

    #>

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true )]
        [System.Xml.XmlNode] $Node
    )

    process {
        Write-ToLogfile "Convert to CubeDeployment.Config.Deployment."

        $config = New-Object CubeDeployment.Config.Deployment -Property @{
            Project = $Node.Attributes['databaseName'].Value
            ServerInstance = $Node.Attributes['serverInstance'].Value
            Version = $Node.Attributes['version'].Value
            XmlaChanges = New-Object System.Collections.Generic.List[CubeDeployment.Config.XmlaChange]
            ProcessingOption = $Node.Attributes['processing'].Value
        }
        Select-Xml -Xml $Node -XPath './xmlaconfig' |
            ForEach-Object {
                $xmlaChange = New-Object CubeDeployment.Config.XmlaChange -Property @{
                    Operation = $_.Node.Attributes['type'].Value
                    XPath = $_.Node.Attributes['xpath'].Value
                    Value = $_.Node.Attributes['value'].Value
                }
                $config.XmlaChanges.Add( $xmlaChange )
            }
        $config | Write-Output
    }
}
