function Invoke-CubeDeployment {

    <#

    .SYNOPSIS
    Deploys a SSAS multidimensional project

    .DESCRIPTION

    Deplyos a SSAS multidimensional project using Microsoft.AnalysisServices.Deployment.exe.
    It allows to apply certain changes on the generated XMLA command or to control the processing.

    .PARAMETER DatabaseName
    The SSAS database name, that contains the cubes and corresponds to the project folder.

    .PARAMETER ServerInstance
    The target server to deploy the SSAS projct to.

    .PARAMETER Version
    A increasing version number to the previous release indicates if the SSAS database sould be dropped before deployment.

    .PARAMETER ProcessingOption
    The processing option of the deployment can be 'Default', 'Full' and 'DoNotProcess'. See [Microsoft Docs](https://docs.microsoft.com/en-us/analysis-services/multidimensional-models/deployment-script-files-specifying-processing-options) for details.

    .PARAMETER XmlaChanges
    A optional array of CubeDeployment.Config.XmlaChange objects,
    that specify the changed of the deployment script before execution.

    .PARAMETER ScriptFolderPath
    Specifies the path to the unzipped build artefact.

    .PARAMETER SSAServicesDeploymentUtilityPath
    The path to the Microsoft.AnalysisServices.Deployment.exe

    .OUTPUTS
    CubeDeployment.Config.Deployment

    #>

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [Alias( 'Project' )]
        [string] $DatabaseName,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $ServerInstance,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [int] $Version,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $ProcessingOption,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [CubeDeployment.Config.XmlaChange[]] $XmlaChanges,

        [Parameter( Mandatory = $true )]
        [ValidateScript( { Test-Path $_ } )]
        [string] $ScriptFolderPath,

        [Parameter( Mandatory = $true )]
        [ValidateNotNullOrEmpty()]
        [string] $SSAServicesDeploymentUtilityPath
    )

    process {
        [string] $serverInstanceRaw = Get-RawHostname $ServerInstance

        #region Drop Cube if neccessary
        $region = $DatabaseName, 'Drop Cube'

        Write-ToLogfile "Get current database version from '$ServerInstance'." -Region $region
        [int] $databaseVersion = Get-DatabaseVersion -ServerInstance $ServerInstance -DatabaseName $DatabaseName
        Write-ToLogfile "Database [$DatabaseName] version is currently '$databaseVersion'." -Region $region
        Write-ToLogfile "Database  [$DatabaseName] version will be '$Version'." -Region $region

        if ( -not $Version -and $databaseVersion -ne 0 ) {
            Write-ToLogfile "Skip drop [$DatabaseName] before deployment. No version set." -Region $region

            if ( Get-OlapDatabase -ServerInstance $ServerInstance -DatabaseName $DatabaseName ) {
                Write-ToLogfile "Register initial version '0'." -Region $region
                New-DatabaseVersion -ServerInstance $ServerInstance -DatabaseName $DatabaseName -Version 0
            }
        }
        elseif ( $Version -and $databaseVersion -lt $Version) {

            if ( Get-OlapDatabase -ServerInstance $ServerInstance -DatabaseName $DatabaseName ) {
                Write-ToLogfile "Drop [$DatabaseName] before deployment." -Region $region
                Remove-OlapDatabase -ServerInstance $ServerInstance -DatabaseName $DatabaseName
            } else {
                Write-ToLogfile "Skip drop [$DatabaseName] before deployment. No Database found." -Region $region
            }

            Write-ToLogfile "Register new version '$Version'." -Region $region
            New-DatabaseVersion -ServerInstance $ServerInstance -DatabaseName $DatabaseName -Version $Version
        } else {
            Write-ToLogfile "Skip drop [$DatabaseName] before deployment. Database is uptodate." -Region $region
        }

        #endregion
        #region Deploy Cube
        #region Generate XMLA
        $region = $DatabaseName, 'Deploy Cube', 'Prepare'

        [string] $asdatabasePath = "$ScriptFolderPath\..\..\$DatabaseName.asdatabase"
        [string] $deploymentoptionsPath = "$ScriptFolderPath\..\..\$DatabaseName.deploymentoptions"
        [string] $deploymenttargetsPath = "$ScriptFolderPath\..\..\$DatabaseName.deploymenttargets"

        [string] $xmlaPath = "$ScriptFolderPath\$DatabaseName.xmla"
        [string] $ssasDeploymentUtilityLogPath = "$ScriptFolderPath\build_xmla.$DatabaseName.log"

        #region Prepare deploymentoptions
        $region = $DatabaseName, 'Deploy Cube', 'Prepare', 'Options'
        Write-ToLogfile 'Start' -Region $region
        if ( Test-Path $deploymentoptionsPath ) {
            Update-DeploymentOptions -Path $deploymentoptionsPath -ProcessingOption $ProcessingOption
        }
        Get-Content $deploymentoptionsPath | ForEach-Object { Write-ToLogfile $_ }
        #endregion

        #region Prepare deploymenttargets
        $region = $DatabaseName, 'Deploy Cube', 'Prepare', 'Target'
        Write-ToLogfile 'Start' -Region $region
        if ( Test-Path $deploymenttargetsPath ) {
            Update-DeploymentTargets -Path $deploymenttargetsPath -ServerInstance $serverInstanceRaw -ConnectionString "Data Source=$serverInstanceRaw;Timeout=0"
        }
        Get-Content $deploymenttargetsPath | ForEach-Object { Write-ToLogfile $_ }
        #endregion

        $region = $DatabaseName, 'Deploy Cube', 'Prepare', 'Generate XMLA'
        Write-ToLogfile 'Start' -Region $region
        New-XmlaScript -ASDatabasePath $asdatabasePath -XmlaScriptPath $xmlaPath -LogPath $ssasDeploymentUtilityLogPath -SSAServicesDeploymentUtilityPath $SSAServicesDeploymentUtilityPath
        Get-Content $ssasDeploymentUtilityLogPath | ForEach-Object { Write-ToLogfile $_ }

        #endregion
        #region Adopt XMLA
        $region = $DatabaseName, 'Deploy Cube', 'Prepare', 'Edit XMLA'
        Write-ToLogfile 'Start' -Region $region
        $XmlaChanges | Edit-XmlaScript -Path $xmlaPath
        #endregion
        #region Deploy XMLA

        $region = $DatabaseName, 'Deploy Cube', 'Deploy', 'Execute XMLA'
        Write-ToLogfile 'Start' -Region $region
        Invoke-XmlaScript -ServerInstance $ServerInstance -Path $xmlaPath

        #endregion
        #endregion

        Write-ToLogfile 'Done' -Region $region
    }
}
