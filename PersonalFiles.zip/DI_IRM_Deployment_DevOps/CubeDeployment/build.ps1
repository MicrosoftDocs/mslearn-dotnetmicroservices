[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ModuleName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Xml.XmlElement] $ConfigNode,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string] $StagingDirectory,

    $AvailableProjects
)

Import-Module ( Join-Path $PSScriptRoot 'CubeDeployment.psd1' )

$configs = Get-ScriptModuleBuildConfiguration -ConfigNode $ConfigNode -ModuleName $ModuleName -ProjectName $ProjectName |
ConvertTo-CubeDeploymentConfig

if ( -not $configs ) {
    Write-ToLogfile "scriptcommand not found for module '$ModuleName' and project '$ProjectName'"
}

foreach ( $config in $configs ) {
    $project = $AvailableProjects |
    Where-Object { $config.Project -eq $_.Name }

    if ( -not $project ) {
        throw "Project '$( $config.Project )' not found."
    }

    $files = Get-ChildItem -Path "$( $project.FullName )/bin" -Recurse -Include '*.asdatabase', '*.deploymentoptions', '*.deploymenttargets'

    if ( $files ) {
        foreach( $file in $files ) {
            Copy-Item -Path $file.FullName -Destination $StagingDirectory
            Write-ToLogfile "File '$file' copied."
        }
    } else {
        throw "File '$( $file.FullName )' not found."
    }
}
