using System.Collections.Generic;

namespace CubeDeployment.Config
{
    public class XmlaChange
    {
        public string Operation { get; set; }
        public string XPath { get; set; }
        public string Value { get; set; }
    }

    public class Deployment
    {
        public string Project { get; set; }
        public string ServerInstance { get; set; }
        public int Version { get; set; }
        public List<XmlaChange> XmlaChanges { get; set; }
        public string ProcessingOption { get; set; }
    }
}
