function ConvertTo-FileDeploymentConfig {

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true )]
        [System.Xml.XmlNode] $Node
    )

    process {
        Write-ToLogfile "Convert to FileDeployment.Config.Deployment."

        $config = New-Object FileDeployment.Config.Deployment -Property @{
            Project = $Node.Attributes['project'].Value
            DestinationServer = $Node.Attributes['destinationServer'].Value
            DestinationPath = $Node.Attributes['destinationPath'].Value
            SourceRelativePath = $Node.Attributes['sourceRelativePath'].Value
            XmlFiles = New-Object System.Collections.Generic.List[DeploymentHelper.Config.XmlFile]
        }

        Select-Xml -Xml $Node -XPath './xmlFile' |
            ConvertTo-XmlFileConfig |
            ForEach-Object { $config.XmlFiles.Add( $_ ) }

        $config | Write-Output
    }
}
