function Invoke-FileDeployment {
    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $Project,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $DestinationServer,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $DestinationPath,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [DeploymentHelper.Config.XmlFile[]] $XmlFiles,

        [Parameter( Mandatory = $true )]
        [ValidateScript( { Test-Path $_ } )]
        [string] $ScriptFolderPath
    )

    process {

        $localPath = "$ScriptFolderPath\..\..\$Project"

        $region = $Project, 'Deploy Files', 'Change XML files'
        Write-ToLogfile 'Start' -Region $region
        $XmlFiles | Invoke-XmlFileChanges -BasePath $localPath
        Write-ToLogfile 'Done' -Region $region

        $region = $Project, 'Deploy Files', 'Copy files'
        Write-ToLogfile "Start copy of '$Project' to '$DestinationPath' on '$DestinationServer'." -Region $region
        Copy-ItemToRemote -LocalPath $localPath -ServerInstance $DestinationServer -RemotePath $DestinationPath
        Write-ToLogfile "Done" -Region $region

    }
}
