using System.Collections.Generic;
using DeploymentHelper.Config;

namespace FileDeployment.Config
{
    public class Deployment
    {
        public string Project { get; set; }
        public string DestinationServer { get; set; }
        public string DestinationPath { get; set; }
        public string SourceRelativePath { get; set; }
        public List<XmlFile> XmlFiles { get; set; }
    }
}
