# FileDeployment

## Configuration

``` xml
<scriptcommand scriptfolder="FileDeployment" project="..." destinationServer="..." destinationPath="..." sourceRelativePath="bin/Release" >
    <xmlFile path="...">
        <change operation="..." xpath="..." value="" />
        <namespace name="..." value="..." />
    </xmlFile>
</scriptcommand>
```

The `project` attribute specifies the folder name that contains the module.
The `destinationServer` attribute specifies the servername, to deploy the module to.
The `destinationPath` attribute specifies the local path on the `destinationServer` of the module.
The `sourceRelativePath` attribute specifies if only a subdirectory should be deployed.

The module may have `xmlFile` elements to deploy and customize configuration files.
A `xmlFile` can have `change` elements to execute `insert`, `update` or `delete` operations using a `xpath` and `value` attribute.
If a `xpath` selects elements of a specific namespace there can be `namespace` elements with `name` and `value` attributes.

## Build

The build is managed by the BuildHelper module. It creates a zip file containing the deployment script and File modules.

## Deployment

See the documentation of the `Invoke-FileDeployment` function.
