[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ModuleName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Xml.XmlElement] $ConfigNode,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string] $StagingDirectory,

    $AvailableProjects
)

Import-Module ( Join-Path -Path $PSScriptRoot -ChildPath 'FileDeployment.psd1' )

$configs = Get-ScriptModuleBuildConfiguration -ConfigNode $ConfigNode -ModuleName $ModuleName -ProjectName $ProjectName | ConvertTo-FileDeploymentConfig

if ( -not $configs ) {
    Write-ToLogfile "scriptcommand not found for module '$ModuleName' and project '$ProjectName'"
}

foreach ( $config in $configs ) {

    $AvailableProjects |
    Where-Object { $config.Project -eq $_.Name } |
    ForEach-Object {
        $projectPath = Join-Path $_.FullName $config.SourceRelativePath
        Copy-Item -Path $projectPath -Destination "$StagingDirectory/$($config.Project)" -Recurse -Verbose
    }

}
