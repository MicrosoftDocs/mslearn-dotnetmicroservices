<#
    .SYNOPSIS
    Powershell Script deploy_ispac.ps1

    .NOTES
    Date:       2018-02-12
    Author:     Steffen Kampmann
    Version:    1.0

    .DESCRIPTION
    This script deploys a ISPAC file which was built from
    a SSIS project out of Visual Studio to a SSIS server.

    Some SSIS packages depend on SSRS subscriptions.
    Therefore the subscription ids need to determined
    and configured in SSIS Catalog environment parameters.

    .COMPONENT
    Installed software on the deployment machine:
    - SQL Server Management Studio 16.5.3

    Download at http://go.microsoft.com/fwlink/?LinkID=840946

    .PARAMETER ServerInstance
    Specifies the name of the SQL Server instance that
    will contain the SSIS packages.

    .PARAMETER CatalogFolderName
    Specifies the name of the SSIS catalog folder to which
    the SSIS packages will be deployed.

    .PARAMETER IspacPath
    Specifies the path to the ISPAC file that should be deployed

    .PARAMETER Environment
    The environment in which the subscription needs to be deployed.
    In the notation of the ARA.xml, from that additional parameters are read.

    .PARAMETER AraXmlPath
    Path to the ARA.xml .
    If not definied, it is ../ARA.xml

    .PARAMETER DeplyomentHelperPath
    Path to the Powershell functions of DeploymentHelper.

    .PARAMETER LogfilePath
    Path to the logfile of this script

#>
#region Setup

[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string] $ServerInstance = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $CatalogFolderName = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $IspacPath = $( throw "mandatory parameter is missing" ),

    [ValidateNotNullOrEmpty()]
    [string] $Environment = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string] $AraXmlPath = "../ARA.xml",

    [ValidateScript({Test-Path $_})]
    [string] $DeploymentHelperPath = "./DeploymentHelper/DeploymentHelper.psm1",

    [ValidateNotNullOrEmpty()]
    [string] $LogfilePath = "deploy_ispac.log",

    [switch] $Interactive = $false
)

$CatalogFolderName = "DI_IRM" # Overwrite FolderName

$ErrorActionPreference = 'Stop'
Import-Module $DeploymentHelperPath
Set-Logfile $LogfilePath
Write-ToLogFile "Execute as '$( $ENV:USERNAME )' on '$( $ENV:COMPUTERNAME )'."
#endregion
#region Helper Functions

function ConvertTo-SubscriptionParameter
{
    [CmdletBinding()]
    param(
        $ParameterNode = $( throw "mandatory parameter is missing" )
    )

    $reportName = $ParameterNode.report.Split("/")[-1]

    Write-ToLogfile -Region 'Parameters' -Message "Load SubscriptionID for report '$reportName' ."

    $SsrsServerInstance = $ParameterNode.ssrsServerInstance
    if ( $SsrsServerInstance -eq $null )
    {
        throw "ssrsServerInstance attribute is missing in ARA.xml"
    }

    [System.Data.DataTable] $subscriptions = Invoke-SqlQuery -ServerInstance $SsrsServerInstance -Database "ReportServer" -SqlCommand @"
SELECT
    Subscriptions.SubscriptionID
FROM ReportServer..Subscriptions
WHERE Subscriptions.Description = '$( $reportName )_Subscription'
"@

    # Check result
    if ( $subscriptions.Count -eq 0 )
    {
        throw "Subscription was not found on ReportServer. Was the deployment of that subscription successful?"
    }
    elseif ( $subscriptions.Count -gt 1 )
    {
        throw "SubscriptionName was not unique on ReportServer."
    }

    [string] $subscriptionId = $subscriptions[0].SubscriptionID

    if ( $subscriptionId.Length -eq 0 ) {
        throw "Invalid empty SubscriptionID selected."
    }

    Write-ToLogfile -Region 'Parameters' -Message "Found SubscriptionID '$( $parameter.SubscriptionID )'."

    New-Object -Type PsObject -Property @{
        Name = $ParameterNode.name
        Package = $ParameterNode.package
        Key = "/$( $ParameterNode.package )/$( $ParameterNode.report )".Replace("/", "#")
        SubscriptionID = $subscriptionId
        Report = $ParameterNode.report
        DataType = "String"
        Sensitive = $false
        Default = $false
    }
}

function ConvertTo-ConstantParameter
{
    [CmdletBinding()]
    param(
        $ParameterNode = $( throw "mandatory parameter is missing" ),
        [byte[]] $MasterKey
    )

    $value = $ParameterNode.value

    if ( $value -eq $null )
    {
        $value = ""
    }

    $dataType = "String"
    if ( $ParameterNode.datatype )
    {
        $dataType = $ParameterNode.datatype
    }

    $sensitive = $false
    if ( $ParameterNode.type -eq "encrypted_password" )
    {
        $sensitive = $true
        if ( $MasterKey ) {
            $value = Import-SecurePassword -SecurePassword $value -MasterKey $MasterKey
        }
    }
    elseif ( $ParameterNode.type -eq "password" )
    {
        $sensitive = $true
    }

    New-Object -Type PsObject -Property @{
        Name = $ParameterNode.name
        Package = $ParameterNode.package
        Key = "/$( $ParameterNode.package )/$( $ParameterNode.name )".Replace("/", "#")
        Value = $value
        DataType = $dataType
        Sensitive = $sensitive
        Default = $false
    }
}

function ConvertTo-DefaultParameter
{
    [CmdletBinding()]
    param(
        $ParameterNode = $( throw "mandatory parameter is missing" )
    )

    New-Object -Type PsObject -Property @{
        Name = $ParameterNode.name
        Package = $ParameterNode.package
        Key = "/$( $ParameterNode.package )/$( $ParameterNode.name )".Replace("/", "#")
        Value = $null
        DataType = $null
        Sensitive = $null
        Default = $true
    }
}

#endregion
#region Main Routine
#region Prepare Deployment
#region Test ARA

Write-ToLogfile "'$AraXmlPath'" -Region 'Test ARA'
if ( ( Test-Path -Path $AraXmlPath ) -eq $false )
{
    throw "$AraXmlPath not found."
}

#endregion
#region Initialize projectName

$projectName = ( Get-Item -Path $IspacPath ).Name.Replace(".ispac", "")

#endregion
#region Assembly
$region = 'Assemly'
Write-ToLogfile "Start" -Region $region

try {
    $assemblyName = "Microsoft.SQLServer.Management.IntegrationServices"

    Write-ToLogfile "'$assemblyName'" -Region $region
    $assembly = [System.Reflection.Assembly]::LoadWithPartialName($assemblyName)
    Write-ToLogfile "'$( $assembly.FullName )' loaded." -Region $region
}
catch
{
    Write-ToLogfile "$( $_.Exception )" -Level 'ERROR' -Region $region
    $_.Exception.LoaderExceptions | ForEach-Object {
        Write-ToLogfile "LoaderException: $( $_.Message )" -Level 'ERROR' -Region $region
    }
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#region Connect SSIS
$region = 'Connect SSIS'
Write-ToLogfile "Start" -Region $region

try
{
    $catalogName = "SSISDB"

    Write-ToLogfile "Connect to SQL Server '$ServerInstance' and Integration Services Catalog '$catalogName'." -Region $region

    # Create a connection to the server
    [string] $sqlConnectionString = "Data Source=$ServerInstance;Initial Catalog=master;Integrated Security=SSPI;"
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $sqlConnectionString

    Write-ToLogfile "Database $ServerInstance successfully connected." -Region $region

    # Create the Integration Services object
    $integrationServices = New-Object Microsoft.SqlServer.Management.IntegrationServices.IntegrationServices $sqlConnection
    Write-ToLogfile "Integration Services $integrationServices successfully connected." -Region $region

    # Get the Integration Services catalog
    [Microsoft.SqlServer.Management.IntegrationServices.Catalog] $catalog = $integrationServices.Catalogs[$catalogName]
    Write-ToLogfile "Catalog $catalog successfully opened." -Region $region
}
catch
{
    Write-ToLogfile "$( $_.Exception )" -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#endregion
#region Catalog Folder
$region = 'Catalog Folder'
Write-ToLogfile "Start." -Region $region

try
{
    Write-ToLogfile "Check CatalogFolder '$CatalogFolderName' on '$ServerInstance'." -Region $region
    [Microsoft.SqlServer.Management.IntegrationServices.CatalogFolder] $catalogFolder = $catalog.Folders.Item( $CatalogFolderName )
    if ( -not $catalogFolder )
    {
        $catalogFolder = New-Object Microsoft.SqlServer.Management.IntegrationServices.CatalogFolder( $catalog, $CatalogFolderName, "Folder description" )
        $catalogFolder.Create()

        Write-ToLogfile "CatalogFolder '$CatalogFolderName' created in SSISDB on '$ServerInstance'." -Region $region
    }
}
catch
{
    Write-ToLogfile -Message $_.Exception -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#region SSIS Project
$region = 'SSIS Project'
Write-ToLogfile "Start deplyoment of $projectName ISPAC." -Region $region

try
{
    Write-ToLogfile "Deploy project '$projectName' to '$sqlConnectionString' in folder '$( $catalogFolder.Name )'" -Region $region

    # Read the project file and deploy it
    [byte[]] $projectBinary = [System.IO.File]::ReadAllBytes($IspacPath)
    [Microsoft.SqlServer.Management.IntegrationServices.Operation] $deployment = $catalogFolder.DeployProject($projectName, $projectBinary)

    # Check the result
    if ($deployment.Status -ne "Success")
    {
        throw "Deployment status was '$( $deployment.Status ). Messages: $( $deployment.Messages )'"
    }
    else
    {
        Write-ToLogfile "ISPAC '$IspacPath' successfully deployed." -Region $region
    }
}
catch
{
    Write-ToLogfile $_.Exception -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End" -Region $region

#endregion
#region SSIS Parameter
#region Load ARA
$region = 'SSIS Parameter', 'Load ARA'
Write-ToLogfile "Start" -Region $region

try {
    $xPath = "//module[@type=""ssis_ispac""]//environment[@name=""$Environment""]//parameter"
    $araParameterNodes = ( Select-XmlWithEntities -Path $AraXmlPath -XPath $xPath ).Node
}
catch {
    Write-ToLogfile "Exception:$( $_.Exception )" -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#region Load Parameter Information
$region = 'SSIS Parameter', 'Master Key'
Write-ToLogfile "Start" -Region $region

try {
    $masterKey = Get-AraMasterKey -AraXmlPath $AraXmlPath
    Write-ToLogfile "$( $masterKey.Length ) byte loaded." -Region $region
}
catch {
    Write-ToLogfile "$( $_.Exception )" -Region $region -Level 'ERROR'

    if ( $Interactive ) {
        $masterKey = ConvertTo-ByteArray -Hex ( Read-Host -Prompt "Enter deployment master password" )
    } else {
        throw
    }
}
#endregion
#region Load Parameter Information
$region = 'SSIS Parameter', 'Load Parameter'
try {

    $araConstantParameters = $araParameterNodes |
        Where-Object { $_.type -eq "constant" -or $_.type -eq "password" -or $_.type -eq "encrypted_password" } |
        ForEach-Object { ConvertTo-ConstantParameter -ParameterNode $_ -MasterKey $masterKey }

    $araSubscriptionParameters = $araParameterNodes |
        Where-Object { $_.type -eq "subscription" } |
        ForEach-Object { ConvertTo-SubscriptionParameter -ParameterNode $_ }

    $araDefaultParameters = $araParameterNodes |
        Where-Object { $_.type -eq "default" } |
        ForEach-Object { ConvertTo-DefaultParameter -ParameterNode $_ }

    $araParameters = @() + $araConstantParameters + $araSubscriptionParameters + $araDefaultParameters
}
catch {
    Write-ToLogfile "$( $_.Exception )" -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#region Environment Variables
#region Initialize Environment
$region = 'SSIS Parameter', 'Environment', 'Initialization'
Write-ToLogfile "Start" -Region $region

# Drop environment if existing
if ( $catalogFolder.Environments[$projectName] -ne $null )
{
    Write-ToLogfile "Drop environment $projectName before recreate." -Region $region
    $catalogFolder.Environments[$projectName].Drop()
}

# Create environment
try
{
    $ssisEnvironment = New-Object Microsoft.SqlServer.Management.IntegrationServices.EnvironmentInfo ($catalogFolder, $projectName, "SSRS Subscriptions")

    # Populate environment with subscription parameters
    $araSubscriptionParameters | ForEach-Object {
        Write-ToLogfile "Add '$( $_.Key )' => '$( $_.SubscriptionID )'." -Region $region
        $ssisEnvironment.Variables.Add($_.Key, [System.TypeCode]::String, $_.SubscriptionID, $_.Sensitive, "$( $_.Package ): Subscription ID for $( $_.Report )")
    }
    # Populate environment with constant parameters
    $araConstantParameters | ForEach-Object {
        Write-ToLogfile "Add '$( $_.Key )' => '$( $_.Value )'." -Region $region


        $dataType = [System.TypeCode]::$( $_.DataType )
        $ssisEnvironment.Variables.Add($_.Key, $dataType, $_.Value, $_.Sensitive, "$( $_.Package ): Constant Value for $( $_.Name )")
    }

    $ssisEnvironment.Create()
    Write-ToLogfile "Environment created." -Region $region
}
catch {
    Write-ToLogfile "$( $_.Exception )" -Level 'ERROR' -Region $region
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#region Assign Variables
$region = 'SSIS Parameter', 'Environment', 'Assignment'
Write-ToLogfile "Start" -Region $region

try
{
    $ssisProject = $catalogFolder.Projects[$projectName]
    $ssisParameters = @() + ( $ssisProject.Parameters ) + ( $ssisProject.Packages | ForEach-Object { $_.Parameters } )

    [System.Collections.ArrayList] $ssisParametersWarnings = @()
    foreach ( $parameter in $ssisParameters ) {

        $matchingAraParameters = ( $araParameters | Where-Object Name -eq $parameter.Name )
        if ( $matchingAraParameters -eq $null )
        {
            # If this is a connection string, change its components to configured values.
            if ( $parameter.Name -like "*ConnectionString" ) {
                $changedConnectionString = $false
                $newConnectionString = $parameter.DesignDefaultValue

                foreach ( $component in @(
                    @{
                        Token = "'Data Source='"
                        Parameter = "ServerName"
                    },
                    @{
                        Token = "Data Source="
                        Parameter = "ServerName"
                    },
                    @{
                        Token = "host="
                        Parameter = "ServerName"
                    },
                    @{
                        Token = "User ID="
                        Parameter = "UserName"
                    },
                    @{
                        Token = "uid="
                        Parameter = "UserName"
                    },
                    @{
                        Token = "Initial Catalog="
                        Parameter = "InitialCatalog"
                    }
                    ))
                {
                    if ( $parameter.DesignDefaultValue -like "*$( $component.Token )*" ) {

                        $parameterName = $parameter.Name.Replace("ConnectionString", "") + $component.Parameter
                        $parameterValue = ( $araParameters | Where-Object Name -eq $parameterName ).Value

                        try {
                            $tokenBegin = $newConnectionString.IndexOf($component.Token) + $component.Token.Length
                            $tokenEnd = $newConnectionString.IndexOf(';', $tokenBegin)
                            $designValue = $newConnectionString.Substring($tokenBegin, $tokenEnd - $tokenBegin)
                        }
                        catch {
                            Write-ToLogfile "Parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] ConnectionString '$newConnectionString' from='$( $component.Token )' to=';'." -Region $region -Level 'ERROR'
                            throw
                        }

                        $serverAraParameters = ( $araParameters | Where-Object Name -eq $parameterName )
                        if ($serverAraParameters -ne $null) {
                            $parameterValue = $serverAraParameters[0].Value
                        }

                        if ( $parameterValue ) {
                            $newConnectionString = $newConnectionString.Replace($designValue, $parameterValue)
                        }
                    }
                }

                $parameter.Set(
                    [Microsoft.SqlServer.Management.IntegrationServices.ParameterInfo+ParameterValueType]::Literal,
                    $newConnectionString
                )

                $changedConnectionString = $true
                Write-ToLogfile "Changed parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] to '$newConnectionString' from '$( $parameter.DesignDefaultValue )'." -Region $region -Level 'WARNING'

                if ( -not $changedConnectionString ) {
                    Write-ToLogfile "SSIS parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] and any of its components were not found in ARA.xml. The default value '$( $parameter.DesignDefaultValue )' was used instead." -Region $region -Level 'WARNING'
                }
            }
            elseif ( $parameter.Name -like "*ServerName" -or $parameter.Name -like "*Url" -or $parameter.Name -like "*UserName" -or $parameter.Name -like "*Password")
            {
                # reset value
                $parameter.Clear()

                $parameter.Set(
                    [Microsoft.SqlServer.Management.IntegrationServices.ParameterInfo+ParameterValueType]::Literal,
                    ''
                )
                Write-ToLogfile "Removed parameter [$( $parameter.ObjectName )].[$( $parameter.Name )]='$( $parameter.DesignDefaultValue )'." -Region $region -Level 'WARNING'
            } else {
                # reset value
                $parameter.Clear()

                $warningMessage = "SSIS parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] was not found in ARA.xml. The default value '$( $parameter.DesignDefaultValue )' was used instead."
                $warningCount = $ssisParametersWarnings.Add($warningMessage)
            }
        }
        else
        {
            $matchingAraParameter = $matchingAraParameters[0]
            if ( $matchingAraParameter.Default ) {

                Write-ToLogfile "Leave parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] to default ." -Region $region

            } else {

                [string] $key = $matchingAraParameter.Key

                Write-ToLogfile "Set parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] to reference '$key' ." -Region $region

                if ( $matchingAraParameter.Value -eq "TODO" )
                {
                    $warningMessage = "SSIS parameter [$( $parameter.ObjectName )].[$( $parameter.Name )] is TODO. The default value was '$( $parameter.DesignDefaultValue )'."
                    $ssisParametersWarnings.Add($warningMessage)
                }

                if ( $parameter.DataType -ne $matchingAraParameter.DataType )
                {
                    throw "unexpected DataType $( $parameter.DataType ) for [$( $parameter.ObjectName )].[$( $parameter.Name )] '$( $matchingAraParameter.DataType )'."
                }

                $parameter.Set(
                    [Microsoft.SqlServer.Management.IntegrationServices.ParameterInfo+ParameterValueType]::Referenced,
                    $key
                )
            }
        }
    }

    if ( $warningCount -ne 0 )
    {
        foreach ( $warning in $ssisParametersWarnings )
        {
            Write-ToLogfile "$warning" -Region $region -Level 'WARNING'
        }
    }

    $ssisProject.Alter()
    Write-ToLogfile "Set parameter successful." -Region $region
}
catch
{
    Write-ToLogfile "$( $_.Exception )" -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End" -Region $region
#endregion
#endregion
#endregion
#region Environment Reference
$region = 'Environment Reference'
Write-ToLogfile "Start" -Region $region

try
{
    if ( $ssisProject.References.Count -eq 0 )
    {
        $ssisProject.References.Add($projectName)
        $ssisProject.Alter()
        Write-ToLogfile "Created" -Region $region
    } else {
        Write-ToLogfile "Skipped" -Region $region
    }
}
catch
{
    Write-ToLogfile -Message $_.Exception -Region $region -Level 'ERROR'
    throw
}

Write-ToLogfile "End"-Region $region
#endregion
#endregion
