<#
    .SYNOPSIS
    Powershell Script prepare_dtproj.ps1

    .NOTES
    Date:       2018-05-09
    Author:     Steffen Kampmann
    Version:    1.0

    .DESCRIPTION
    This script changes the protection level of SSIS packages to DontSaveSensitive.

    .PARAMETER ProjectFolderPath
    Path to the project folder that contains a dtproj file with the same name as the folder.

#>

[CmdletBinding()]
param(
    [ValidateScript({Test-Path $_})]
    [string]
    $ProjectFolderPath = $( throw "mandatory parameter is missing" ),

    [ValidateScript({Test-Path $_})]
    [string]
    $AraXmlPath = $( throw "mandatory parameter is missing" )
)

$ErrorActionPreference = "Stop"
# $DebugPreference = "Continue"

Get-ChildItem $ProjectFolderPath -Filter '*.dtsx' | ForEach-Object {
    Write-Verbose "Check '$( $_.Name )'."
    Set-PackageVariable -Path $_.FullName -PackageName $_.BaseName -AraXmlPath $AraXmlPath
}
