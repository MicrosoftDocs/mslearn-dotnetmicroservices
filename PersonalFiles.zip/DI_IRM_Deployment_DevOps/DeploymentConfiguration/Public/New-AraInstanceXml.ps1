function New-AraInstanceXml
{
    <#

    .SYNOPSIS
    Creates a new ARA configuration using a template and a parameter set.

    .PARAMETER TemplatePath
    Specifies the path to the template file in XML format.
    The template can contain strings with the schema '$ENV_{variable name};'

    .PARAMETER ParameterPath
    Specifies the path to the parameter file in CSV format.
    The column Key is used as {variable name} in the template XML and the further column names are used as environments.
    The modules of the template will be copied for each environment.

    .PARAMETER TargetPath
    Specifies the path to the configuration file that should be created.

    .DESCRIPTION
    Creates a new ARA configuration using a XML template that contains
    a configuration for each module but not specialized for the environments.
    A CSV parameter file contains the environment specific values like hostnames, usernames, etc.
    For each environment in the parameter file the module templates are copied
    and filled wil the environment specific values. These variables in the XML template start with $ENV_ .

    .EXAMPLE
        New-AraInstanceXml -TemplatePath "ARA.template.xml" -ParameterPath "ARA.csv" -TargetPath "ARA.xml"

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $TemplatePath,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $ParameterPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $TargetPath
    )

    #region Load Parameters

    $parameters = Import-Csv -Path $ParameterPath
    $environmentNames = $parameters[0].PSObject.Properties | ForEach-Object { $_.Name } | Where-Object { $_ -ne 'Key' }
    $environmentParameters = $environmentNames | ForEach-Object {
        $environment = $_
        $dictionary = @{ Name = $environment }
        $parameters | Select Key, $environment | ForEach-Object {
            $dictionary[$_.Key] = $_.$environment
        }

        New-Object PsObject -Property $dictionary | Write-Output
        Write-Verbose "Environment parameters loaded for '$environment'."
    }

    #endregion
    #region Prepare environment entities

    $environmentEntities = $environmentParameters | ForEach-Object {
        $environment = $_
        $environmentName = $environment.Name
        $_.PSObject.Properties | ForEach-Object {
            $key = "$( $environmentName )_$( $_.Name )"
            $value = $_.Value.Replace('$ENV_', "&$( $environmentName )_")

            Write-Output "<!ENTITY $key `"$value`">"
        }
    }
    Write-Verbose "Environment parameter entities prepared."

    #endregion
    #region Load Template

    [System.Xml.XmlDocument] $targetDocument = New-Object System.Xml.XmlDocument
    $targetDocument.Load($TemplatePath)
    Write-Verbose "Configuration $TemplatePath loaded."

    #endregion
    #region Environment Entity Expressions

    $templateEntities = Get-Entities ($targetDocument)
    $templateEntities = $templateEntities.Keys | Sort-Object | ForEach-Object {
        $key = $_
        if ( $key.Startswith( '_ENV_' ) ) {
            $environmentNames | ForEach-Object {
                $environmentKey = $key.Replace( '_ENV_', "$( $_ )_" )
                $value = $templateEntities[$key][0].Replace( '$ENV_', "&$( $_ )_" )

                Write-Output "<!ENTITY $environmentKey `"$value`">"
            }
        } else {
            $value = $templateEntities[$key][0]
            Write-Output "<!ENTITY $key `"$value`">"
        }
    }

    #endregion
    #region Replace DocumentType with entities

    $newDocumentTypeDefinition = (( $() + $templateEntities + $environmentEntities ) | Sort-Object ) -join "`n"
    $documentType = $targetDocument.CreateDocumentType('ARA', $null, $null, "`n" + $newDocumentTypeDefinition)
    $targetDocument.RemoveChild($targetDocument.DocumentType) | Out-Null
    $targetDocument.InsertAfter($documentType, $targetDocument.FirstChild) | Out-Null
    Write-Verbose "Environment Entities prepared."

    #endregion
    #region Add environment configurations to modules

    $modules = Select-Xml -XPath '//module' -Xml $targetDocument
    foreach ( $module in $modules ) {
        $templateNodes = $module.Node.CloneNode( $true ).ChildNodes

        # remove template from node // for some strange reason it has to be called twice
        foreach ( $i in @( 1, 2 )) {
            $module.Node.ChildNodes | ForEach-Object {
                $_.ParentNode.RemoveChild( $_ ) | Out-Null
            }
        }

        # add module content for each environment
        foreach ( $environment in $environmentNames ) {
            $templateNodes | ForEach-Object {
                $moduleName = $( $_.ParentNode.Attributes['name'].Value )
                $clone = $_.CloneNode( $true )
                try {
                    if ( $clone.InnerText ) {
                        $newInnerText = $clone.InnerText.Replace( '$ENV_Name;', $environment )
                        $clone.InnerText = $newInnerText
                    }
                }
                catch {
                    Write-Warning "Failed to replace entity in module text $moduleName to $newInnerText."
                    $targetDocument.Save( $TargetPath )
                    throw
                }
                try {
                    if ( $clone.InnerXml ){
                        $newInnerXml = $clone.InnerXml.Replace( '$ENV_', "&$( $environment )_" )
                        $clone.InnerXml = $newInnerXml
                    }
                }
                catch {
                    Write-Warning "Failed to replace entity in module xml $moduleName to $newInnerXml."
                    $targetDocument.Save( $TargetPath )
                    throw
                }
                $module.Node.AppendChild( $clone ) | Out-Null

                if ( $_.Name -eq 'deploymentSettings' ) {
                    Write-Verbose "Module '$moduleName' deploymentSettings for '$environment' added."
                }
            }
        }
    }

    #endregion
    #region Create target document

    $targetDocument.Save( $TargetPath )

    [string] $xml = Get-Content -Path $TargetPath -Encoding UTF8 -Raw
    $xml = $xml.Replace('ARA PUBLIC "" ""[', 'ARA [')
    Set-Content -Path $TargetPath -Value $xml -Encoding UTF8

    #endregion
}
