function Merge-Csv
{
    <#

    .SYNOPSIS
    Create a CSV file by merging two others.

    .PARAMETER TemplatePath
    Specifies the path to the template file in CSV format.

    .PARAMETER InheritorPath
    Specifies the path to the inheritor file in CSV format.

    .PARAMETER TargetPath
    Specifies the path to the file that should be created.

    .PARAMETER KeyColumn
    Specifies the column by name, on which a collision is detected.

    .DESCRIPTION
    Merges two CSV files using inheritance.
    There is a template table and a inheritor table,
    that overwrites a row from the template,
    if a row with the same value in the key column exists.

    .EXAMPLE

    Merge-Csv -TemplatePath "template.csv" -InheritorPath "inheritor.csv" -TargetPath "new.csv" -KeyColumn "Key"

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $TemplatePath,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $InheritorPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $TargetPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $KeyColumn
    )

    $templateParameters = Convert-ToDictionary -Table ( Import-Csv $TemplatePath ) -KeyColumn $KeyColumn
    $inheritorParameters = Convert-ToDictionary -Table ( Import-Csv $InheritorPath ) -KeyColumn $KeyColumn

    $parameters = @{}
    foreach ( $key in ( @() + $templateParameters.Keys + $inheritorParameters.Keys )) {
        $parameters[$key] = $templateParameters[$key] | Select-Object -Property * # -ExcludeProperty Key
        if ( $inheritorParameters.Keys -contains $key ) {
            $parameters[$key] = $inheritorParameters[$key] | Select-Object -Property * # -ExcludeProperty Key
        }
    }

    $parameters.Values | Sort-Object $KeyColumn | Export-Csv -Path $TargetPath -NoTypeInformation
}