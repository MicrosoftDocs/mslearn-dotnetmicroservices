function New-AraXml
{
    <#

    .SYNOPSIS
    Creates a new ARA configuration using a template and a spcification file.

    .PARAMETER TemplatePath
    Specifies the path to the configuration template file in XML format.

    .PARAMETER InheritorPath
    Specifies the path to the configuration specialization file in xml format.

    .PARAMETER TargetPath
    Specifies the path to the configuration file that should be created.

    .DESCRIPTION
    The created configuration file will contain the inheritor configuration extended by the XML entities from the template configuration.

    .EXAMPLE

    New-AraXml `
        -TemplatePath "ARA.template.xml" `
        -InheritorPath "ARA.inheritor.xml" `
        -TargetPath "ARA.xml"

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $TemplatePath,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]
        $InheritorPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $TargetPath
    )

    #region Load Data

    [System.Xml.XmlDocument] $configuration = New-Object System.Xml.XmlDocument;
    $configuration.Load($TemplatePath)
    Write-Verbose "Configuration template $TemplatePath loaded."
    $templateVariables = Get-Entities ($configuration)
    Write-Verbose "Configuration template $InheritorPath parsed."

    [System.Xml.XmlDocument] $instance = New-Object System.Xml.XmlDocument;
    try { $instance.Load($InheritorPath) } catch { }
    Write-Verbose "Configuration inheritor $InheritorPath loaded."
    $instanceVariables = Get-Entities ($instance)
    Write-Verbose "Configuration inheritor $InheritorPath parsed."

    #endregion
    #region Merge Files

    $variables = Merge-Entities -Template $templateVariables -Inheritor $instanceVariables
    Write-Verbose "Configuration template and inheritor merged."

    #endregion
    #region Generate Configuration

    $instanceSource = Get-Content $InheritorPath

    . {
        $instanceSource[0..$instanceSource.IndexOf("<!DOCTYPE ARA [")]
        foreach ($key in $variables.Keys | Sort-Object)
        {
            "<!ENTITY $key `"$( $variables[$key][0] )`">"
        }
        $instanceSource[$instanceSource.IndexOf("]>")..$instanceSource.Count]
    } | Set-Content $TargetPath

    if ( -not ( Test-Path $TargetPath)) {
        Write-Error "The ARA.xml at '$TargetPath' was not created."
        Get-ChildItem $rootDir
    }

    #endregion
    #region Validate Configuration

    [System.Xml.XmlDocument] $target = New-Object System.Xml.XmlDocument;
    $target.Load($TargetPath)
    Write-Verbose "'$TargetPath' was created and validated."

    #endregion
}
