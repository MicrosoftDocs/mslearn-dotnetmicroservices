function Get-Entities
{
    <#

    .SYNOPSIS
    Returns the XML entities from a XML document.

    .PARAMETER XmlDocument
    Specifies the xml document from which the entities should be returned.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [System.Xml.XmlDocument]
        $XmlDocument
    )

    if ( $XmlDocument.DocumentType -eq $null ) {
        throw "doctype not found"
    }

    $entities = @{}
    foreach ($entity in $XmlDocument.DocumentType.Entities) {
        $key = $entity.Name
        $value = ""

        foreach ($part in $entity.ChildNodes)
        {
            if ( $part.name -eq "#text" )
            {
                $value = $value + $part.value
            }
            else
            {
                $value = $value + "&" + $part.name + ";"
            }
        }

        Write-Verbose "$key = $value"

        $entities[$key] = $($value, $entity)
    }

    Write-Output $entities
}