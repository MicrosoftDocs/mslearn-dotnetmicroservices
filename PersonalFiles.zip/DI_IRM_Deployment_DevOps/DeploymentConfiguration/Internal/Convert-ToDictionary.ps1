function Convert-ToDictionary
{
    <#

    .SYNOPSIS
    Converts a table to a dictionary

    .PARAMETER Table
    Specifies a table object (e.g. from Import-CSV) that should be converted to a dictionary.

    .PARAMETER KeyColumn
    Specifies the column name in the table that should be used as key in the dictionary.

    .OUTPUTS
    A directory object.

    #>

    [CmdletBinding()]
    param(
        # [Parameter(Mandatory=$true)]
        # [Array]
        $Table,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $KeyColumn
    )

    $dictionary = @{}

    foreach ( $row in $Table ) {
        $dictionary[$row.$KeyColumn] = $row
    }

    Write-Output $dictionary

}