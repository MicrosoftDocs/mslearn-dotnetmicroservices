function Merge-Entities
{
    <#

    .SYNOPSIS
    Merges to sets of entities.

    .PARAMETER Template
    The first set of entities.

    .PARAMETER Inheritor
    The second set of entities.

    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Template,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        $Inheritor
    )

    $variables = $Template.Clone()
    foreach ($key in $Inheritor.Keys)
    {
        $value, $entity = $Inheritor[$key]
        $variables[$key] = $($value, $entity)
    }

    Write-Output $variables
}