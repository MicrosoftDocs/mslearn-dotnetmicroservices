[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ModuleName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Xml.XmlElement] $ConfigNode,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string] $StagingDirectory,

    $AvailableProjects
)

$configs = Select-Xml -Xml $ConfigNode -XPath "//module[@name='$ModuleName']//scriptcommand[@scriptfolder='$ProjectName']"

if ( -not $configs ) {
    Write-ToLogfile "scriptcommand not found for module '$ModuleName' and project '$ProjectName'"
}

$databases = $configs | ForEach-Object {
    Write-Output $_.Node.Attributes['databaseName'].Value
} | Select -Unique

foreach ( $database in $databases ) {
    $databaseProject = $AvailableProjects | Where-Object { $_.BaseName -eq $database  }

    if ( -not $databaseProject ) {
        throw "Database project '$database' not found."
    }

    $dacpacs = Get-ChildItem -Path "$( $databaseProject.FullName )/bin" -Recurse -Include '*.dacpac'

    if ( $dacpacs ) {
        foreach( $dacpac in $dacpacs ) {
            $destinationPath = Join-Path $StagingDirectory $dacpac.Name
            if ( Test-Path $destinationPath )
            {
                Write-ToLogfile "Dacpac '$dacpac' skipped."
            } else {
                Copy-Item -Path $dacpac.FullName -Destination $destinationPath
                Write-ToLogfile "Dacpac '$dacpac' copied."
            }

            $migration = "$( $dacpac.Directory.FullName )\..\..\Migration"
            if ( Test-Path $migration ) {
                $migrationDestination = "$StagingDirectory\Migration.$database"
                if ( Test-Path $migrationDestination ) {
                    Write-ToLogfile "Migration '$migration' skipped."
                } else {
                    Copy-Item -Path $migration -Destination $migrationDestination -Recurse
                    Write-ToLogfile "Migration '$migration' copied."
                }
            }
            else {
                Write-ToLogfile "Migration '$migration' not found." -Level 'WARNING'
            }
        }
    } else {
        throw "Dacpac '$( $dacpac.FullName )' not found."
    }
}
