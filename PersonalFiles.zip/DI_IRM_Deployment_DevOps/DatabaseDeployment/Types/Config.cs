using System.Collections.Generic;

namespace DatabaseDeployment.Config
{
    public class Role
    {
        public string Name { get; set; }
        public string AdGroup { get; set; }
    }

    public class Deployment
    {
            public string DatabaseName { get; set; }
            public string ServerInstance { get; set; }
            public int Index { get; set; }
            public int DacpacTimeout { get; set; }
            public List<Role> Roles { get; set; }
    }
}
