/*

    # Assign_Database_Role

    Adds a user or group to a database role.

    Date: 13.12.2018
    Autor: Steffen Kampmann

    ## Parameters

    - RoleName
    - UserName

*/

ALTER ROLE [$(RoleName)] ADD MEMBER [$(UserName)]
