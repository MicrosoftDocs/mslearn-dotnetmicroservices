function Invoke-DatabaseDeployment
{

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [Alias( 'Project' )]
        [string] $DatabaseName,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [string] $ServerInstance,

        [Parameter( Mandatory = $true, ValueFromPipelineByPropertyName = $true )]
        [int] $DacpacTimeout,

        [Parameter( Mandatory = $false, ValueFromPipelineByPropertyName = $true )]
        [DatabaseDeployment.Config.Role[]] $Roles,

        [Parameter( Mandatory = $true )]
        [ValidateScript( { Test-Path $_ } )]
        [string] $ScriptFolderPath,

        [Parameter( Mandatory = $true )]
        [ValidateScript( { Test-Path $_ -PathType Leaf } )]
        [string] $SqlPackagePath
    )

    process {

        [string] $dacPacPath = "$ScriptFolderPath\..\..\$( $DatabaseName ).dacpac"
        [string] $migrationsPath = "$ScriptFolderPath\..\..\Migration.$( $DatabaseName )"

        #region Migration
        if ( Test-Path $migrationsPath ) {
            Write-ToLogfile "Found migration '$migrationsPath'."
            Invoke-SqlMigrations `
                -Path $migrationsPath `
                -ServerInstance $ServerInstance `
                -DatabaseName $DatabaseName
        } else {
            Write-ToLogfile "No migrations found" -Level 'WARNING'
            Initialize-SqlMigrations `
                -ServerInstance $ServerInstance `
                -DatabaseName $DatabaseName
        }
        #endregion
        #region Dacpac
        Invoke-SqlPackage `
            -ServerInstance $ServerInstance `
            -DatabaseName $DatabaseName `
            -DacPacPath $dacPacPath `
            -SqlPackagePath $SqlPackagePath `
            -Timeout $DacpacTimeout
        #endregion
        #region Logins, User, Roles
        Write-ToLogfile "Login Creation."

        $Roles | ForEach-Object {
            Invoke-LoginCreation `
                -ServerInstance $ServerInstance `
                -DatabaseName $DatabaseName `
                -ScriptFolderPath $ScriptFolderPath `
                -AdGroup $_.AdGroup
        }

        Write-ToLogfile "User Creation."

        $Roles | ForEach-Object {
            Invoke-UserCreation `
                -ServerInstance $ServerInstance `
                -DatabaseName $DatabaseName `
                -ScriptFolderPath $ScriptFolderPath `
                -AdGroup $_.AdGroup
        }

        Write-ToLogfile "Role Assignment."

        $Roles | ForEach-Object {
            Invoke-RoleDeployment `
                -ServerInstance $ServerInstance `
                -DatabaseName $DatabaseName `
                -ScriptFolderPath $ScriptFolderPath `
                -Name $_.Name `
                -AdGroup $_.AdGroup
        }
        #endregion
    }
}
