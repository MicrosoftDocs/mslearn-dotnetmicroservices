function ConvertTo-DatabaseDeploymentConfig {

    <#

    .SYNOPSIS
    Convert XML to Deployment Config

    .DESCRIPTION

    The XML configuration will be converted to a .NET object, that can be used to parameterize `Invoke-DatabaseDeployment`.

    .PARAMETER Node
    The XML node that contains the configuration infromation.

    .OUTPUTS
    DatabaseDeployment.Config.Deployment

    #>

    [CmdletBinding()]
    param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true )]
        [System.Xml.XmlNode] $Node
    )

    process {
        Write-ToLogfile "Convert to DatabaseDeployment.Config.Deployment."

        [int] $dacpacTimeout = $Node.dacpacTimeout
        if ( -not $dacpacTimeout ) { $dacpacTimeout = ( 30 * 60 ) }

        $config = New-Object -Type DatabaseDeployment.Config.Deployment -Property @{
            DatabaseName = $Node.databaseName
            ServerInstance = $Node.ServerInstance
            Index = $Node.index
            DacpacTimeout = $dacpacTimeout
            Roles = New-Object System.Collections.Generic.List[DatabaseDeployment.Config.Role]
        }

        #region Role Deployment
        $roles = Select-Xml -Xml $Node -XPath './role' -PipelineVariable roleXml |
        ForEach-Object {
            $role = New-Object -Type DatabaseDeployment.Config.Role -Property @{
                Name = $roleXml.Node.Attributes['name'].Value
                AdGroup = $roleXml.Node.Attributes['adGroup'].Value
            }
            $config.Roles.Add($role)
        }
        #endregion

        $config | Write-Output
    }
}
