/*

    # Create database user

    Create a database user, and assigns it to a database login, that represents a AD Group.

    Date: 13.12.2018
    Autor: Steffen Kampmann

    ## Parameters

    - GroupName

*/

if not exists ( select 1 from sys.sysusers where name = '$(GroupName)' )
CREATE USER [$(GroupName)] FOR LOGIN [$(GroupName)] WITH DEFAULT_SCHEMA=[dbo]

