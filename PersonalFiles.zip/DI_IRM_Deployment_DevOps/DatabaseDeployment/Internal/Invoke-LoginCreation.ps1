function Invoke-LoginCreation {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $AdGroup
    )

    Invoke-SqlCmd `
        -ServerInstance $ServerInstance `
        -Database $DatabaseName `
        -Path "$ScriptFolderPath\01_Create_Instance_Login.sql" `
        -Arguments `
            "LoginName = ""$AdGroup""", `
            "DefaultDatabaseName = ""$DatabaseName""" `
        -Timeout 10
}