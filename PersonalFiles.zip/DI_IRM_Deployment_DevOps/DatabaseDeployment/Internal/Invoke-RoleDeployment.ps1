function Invoke-RoleDeployment {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Name,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $AdGroup
    )

    Invoke-SqlCmd `
        -ServerInstance $ServerInstance `
        -Database $DatabaseName `
        -Path "$ScriptFolderPath\03_Assign_Database_Role.sql" `
        -Arguments `
            "RoleName = ""$Name""", `
            "UserName = ""$AdGroup""" `
        -Timeout 10
}