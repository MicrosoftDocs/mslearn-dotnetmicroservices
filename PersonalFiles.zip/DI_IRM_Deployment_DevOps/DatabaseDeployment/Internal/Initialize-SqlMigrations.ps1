function Initialize-SqlMigrations {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName
    )

    Write-ToLogfile "Get current database version."
    [int] $databaseVersion = Get-DatabaseVersion -ServerInstance $ServerInstance -DatabaseName $DatabaseName
    Write-ToLogfile "Database [$DatabaseName] version is currently '$databaseVersion'."

    if ( $databaseVersion -eq -1 ) {

        [int] $latestDatabaseVersion = 0

        Write-ToLogfile "Register initial deployment to version '$latestDatabaseVersion'."
        Invoke-SqlNonQuery `
            -ServerInstance $ServerInstance `
            -Database 'DI_IRM_Maintenance' `
            -SqlCommand "INSERT INTO migration.Version (DatabaseName, Version, IsInitialDeployment) VALUES ('$DatabaseName', '$latestDatabaseVersion', 1)" `
            -ExpectedReturn 1
    }
}
