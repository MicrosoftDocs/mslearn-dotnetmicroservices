function Invoke-UserCreation {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ScriptFolderPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $AdGroup
    )

    Invoke-SqlCmd `
        -ServerInstance $ServerInstance `
        -Database $DatabaseName `
        -Path "$ScriptFolderPath\02_Create_Database_User.sql" `
        -Arguments `
            "GroupName = ""$AdGroup""" `
        -Timeout 10
}