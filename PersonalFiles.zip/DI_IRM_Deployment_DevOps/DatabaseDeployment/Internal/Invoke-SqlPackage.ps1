function Invoke-SqlPackage
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [string] $SqlPackagePath,

        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [string] $DacPacPath,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int] $Timeout
    )

    #region Prepare process

    $processInfo = New-Object System.Diagnostics.ProcessStartInfo
    $processInfo.FileName = $SqlPackagePath
    $processInfo.RedirectStandardError = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.Arguments = "/Action:Publish /SourceFile:$DacPacPath /TargetServerName:$ServerInstance /TargetDatabaseName:$DatabaseName /TargetTimeout:$Timeout /OverwriteFiles:True" #  /Diagnostics:True

    #endregion
    #region Start process
    Write-ToLogFile "Invoke-SqlPackage: '$DacPacPath': [$ServerInstance].[$DatabaseName]"
    Write-ToLogFile "Invoke-SqlPackage: $SqlPackagePath $( $processInfo.Arguments )"

    $outputBuffer = New-Object System.Text.StringBuilder
    $errorBuffer = New-Object System.Text.StringBuilder

    $sScripBlock = {
        if (! [String]::IsNullOrEmpty($EventArgs.Data)) {
            $Event.MessageData.AppendLine($EventArgs.Data)
        }
    }

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $processInfo

    $outputEvent = Register-ObjectEvent -InputObject $process `
        -Action $sScripBlock -EventName 'OutputDataReceived' `
        -MessageData $outputBuffer

    $errorEvent = Register-ObjectEvent -InputObject $process `
        -Action $sScripBlock -EventName 'ErrorDataReceived' `
        -MessageData $errorBuffer

    $process.Start() | Out-Null
    $process.BeginOutputReadLine();
    $process.BeginErrorReadLine();

    $timeoutMS = ($Timeout + 5 ) * 1000
    if ( $process.WaitForExit( $timeoutMS ))
    {
        $returnCode = $process.ExitCode
    } elseif ( $process.HasExited )
    {
        $returnCode = $process.ExitCode
    }
    else
    {
        Write-ToLogFile "Invoke-SqlPackage: Timeout $Timeout reached."
        $process.Kill()
        $returnCode = -1
    }

    Unregister-Event -SourceIdentifier $outputEvent.Name
    Unregister-Event -SourceIdentifier $errorEvent.Name

    $standardOutput = $outputBuffer.ToString().Trim()
    $standardError = $errorBuffer.ToString().Trim()

    $process.Close() | Out-Null

    Write-ToLogFile "Invoke-SqlPackage: '$scriptName' Output $( $standardOutput.Length ) chars: $standardOutput"
    Write-ToLogFile "Invoke-SqlPackage: '$scriptName' Error $( $standardError.Length ) chars: $standardError"

    if ( $standardError.EndsWith('Timeout expired') ) {
        Write-ToLogFile "Invoke-SqlPackage: Timeout $Timeout reached."
        $returnCode = -1
    }

    if ( $returnCode -ne 0 )
    {
        throw "SqlPackage exit code $returnCode; err: '$standardError'."
    }

    #endregion
}
