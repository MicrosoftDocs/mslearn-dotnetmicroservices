function Invoke-SqlMigrations {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerInstance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseName
    )

    $migrations = Get-ChildItem -Path $Path |
    Where-Object { $_.Name -match ".*\d+.*" } |
    Sort-Object |
    ForEach-Object {
        $migrationDirectory = $_
        Write-ToLogfile "Found migration '$( $migrationDirectory.Name )'."

        [string[]] $scripts = @(
            '01_drop_constraints',
            '02_create_tables',
            '03_migrate_data',
            '04_switch_tables',
            '05_add_constraints',
            '06_cleanup'
        ) | ForEach-Object {
            Write-Output "$( $migrationDirectory.FullName )\$_.sql"
        } | Where-Object {
            Test-Path $_
        }

        New-Object -Type PsObject -Property @{
            Version = [int] $migrationDirectory.Name
            Scripts = $scripts
        } | Write-Output
    }

    $migrations |
    Select-Object -PipelineVariable migration |
    ForEach-Object {

        Write-ToLogfile "Get current database version."
        [int] $databaseVersion = Get-DatabaseVersion -ServerInstance $ServerInstance -DatabaseName $DatabaseName
        Write-ToLogfile "Database [$DatabaseName] version is currently '$databaseVersion'."

        if ( $databaseVersion -eq -1 ) {
            Write-ToLogfile "Database [$DatabaseName] is initialized."
        } elseif ( $migration.Version -le $databaseVersion ) {
            Write-ToLogfile "Migration to version '$( $migration.Version )' skipped."
        } else {
            Write-ToLogfile "Migration to version '$( $migration.Version )' started."

            New-DatabaseVersion -ServerInstance $ServerInstance -DatabaseName $DatabaseName -Version $migration.Version

            $migration.Scripts | ForEach-Object {
                Invoke-SqlCmd -Path $_ -ServerInstance $ServerInstance -DatabaseName $DatabaseName
            }

            Set-DatabaseVersionMigrated -ServerInstance $ServerInstance -DatabaseName $DatabaseName -Version $migration.Version
            Write-ToLogfile "Migration to version '$( $migration.Version )' done."
        }
    }

    if ( $databaseVersion -eq -1 ) {

        [int] $latestDatabaseVersion = ( $migrations | Select -Last 1 ).Version

        Write-ToLogfile "Register initial deployment to version '$latestDatabaseVersion'."
        Invoke-SqlNonQuery `
            -ServerInstance $ServerInstance `
            -Database 'DI_IRM_Maintenance' `
            -SqlCommand "INSERT INTO migration.Version (DatabaseName, Version, IsInitialDeployment) VALUES ('$DatabaseName', '$latestDatabaseVersion', 1)" `
            -ExpectedReturn 1
    }
}
