# DatabaseDeployment

## Deployment Configuration

A database deployment can be configured with a XML node in the ARA.template.xml.

```XML
<scriptcommand
    scriptfolder="DatabaseDeployment"
    serverInstance="..."
    databaseName="..."
    dacpacTimeout="..."
    index="..."
/>
```

The optional `dacpacTimeout` parameter can be used if the default timeout for the schema change of 3600 seconds needs to be changed.
The optional `index` parameter can be used if multiple databases need to be deployed and require a defined deployment order.

## Database Migrations

For database migrations there must be a directory with the name 'Migration' in the database project directory.
Each migration resides in it's own subfolder which has the name of a integer version. The migrations will be executed in ascending order.

Each migration may have a subset of the following scripts:

- 01_drop_constraints.sql
- 02_create_tables.sql
- 03_migrate_data.sql
- 04_switch_tables.sql
- 05_add_constraints.sql
- 06_cleanup.sql

Each migration will only be executed once. If a migration fails it wont be executed on the next deployment. It may be fixed with a new version number.
