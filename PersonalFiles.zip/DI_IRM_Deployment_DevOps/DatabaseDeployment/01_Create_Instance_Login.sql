/*

    # Create database login

    Create a database login, that represents a ad group.

    Date: 07.01.2019
    Autor: Steffen Kampmann

    ## Parameters

    - LoginName
    - DefaultDatabaseName

*/

if not exists ( select 1 from sys.syslogins where name = '$(LoginName)' )
CREATE LOGIN [$(LoginName)] FROM WINDOWS WITH DEFAULT_DATABASE=[$(DefaultDatabaseName)]
