[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $BuildSourceDirectory

)

$ErrorActionPreference = 'Stop'

$exitCode = 0
$LASTEXITCODE = 0


# Formulate the full path of the Renderer dependecies folder in the solution
$folder1 = "$BuildSourceDirectory\Bin64"

# Get the first directory that matches the pattern "Enscape.Renderer.Dependencies*"
$folderName = Get-ChildItem -Path $BuildSourceDirectory -Filter "Enscape.Renderer.Dependencies*" -Directory | Select-Object -First 1

# Check if a matching directory was found
if ($null -ne $folderName) {
    # Formulate the full path of the installed Dpendecies folder
    $folder2 = Join-Path -Path $folderName.FullName -ChildPath "data\win-x64\Bin64"
}
else {
    Write-Host "Matching folder not found in $BuildSourceDirectory."
    $exitCode = 1  
}


# Read the list of filenames to exclude from the text file
$excludeListFilePath = "$BuildSourceDirectory\Bin64\ExcludeDllsCompare_list.txt"
$excludeList = Get-Content -Path $excludeListFilePath


#compare files from solution to Dependencies
Write-Host "Comparing the dlls and it's contents from Solution to Dependencies."

# Get all DLL files in the first folder
$dllFiles = Get-ChildItem -Path $folder1 -Filter *.dll -File | Where-Object { $excludeList -notcontains $_.Name }

# Loop through each DLL file in the first folder
foreach ($dllFile in $dllFiles) {
    # Check if the DLL file exists in the second folder with the same name
    if (Test-Path -Path "$folder2\$($dllFile.Name)") {
        # Load the DLL files from both folders as byte arrays
        $dllFile1 = [System.IO.File]::ReadAllBytes("$folder1\$($dllFile.Name)")
        $dllFile2 = [System.IO.File]::ReadAllBytes("$folder2\$($dllFile.Name)")

        Write-Host "The $($dllFile.Name) exists in Dependeies folder $folder2."

        # Compare the contents of the two DLL files
        if ($dllFile1.Length -ne $dllFile2.Length) {
            Write-Host "The contents of $($dllFile.Name) in $folder1 and $folder2 are different."
            # Set the exit code to 1
            $exitCode = 1
        }
        else {
            for ($i = 0; $i -lt $dllFile1.Length; $i++) {
                if ($dllFile1[$i] -ne $dllFile2[$i]) {
                    Write-Host "The contents of $($dllFile.Name) in $folder1 and $folder2 are different."
                    # Set the exit code to 1
                    $exitCode = 1
                    break
                }
            }
            Write-Host "The contents of $($dllFile.Name) in $folder1 and $folder2 are Same."
        }
    }
    else {
        Write-Host "The DLL file $($dllFile.Name) does not exist in Dependeies folder $folder2." 
        Write-Host "Either Please add $($dllFile.Name) to ExcludeDllsCompare_list.txt if this dll does not require in the Dependencies Nuget package"
        Write-Host "(Or) Please add $($dllFile.Name) to Third Party  Dependencies folder if this dll is required in the Dependencies Nugetpackage"
        # Set the exit code to 1
        $exitCode = 1
    }
}


#Compare files from Dependency to solution
Write-Host "Comparing the dlls from Dependencies to Solution ."

# Get all DLL files in the second folder
$dllFiles = Get-ChildItem -Path $folder2 -Filter *.dll

# Loop through each DLL file in the first folder
foreach ($dllFile in $dllFiles) {
    # Check if the DLL file exists in the second folder with the same name
    if (Test-Path -Path "$folder1\$($dllFile.Name)") {
        Write-Host "The $($dllFile.Name) exists in soluition folder  $folder1."
    }
    else{
        Write-Host "The $($dllFile.Name) does not exists in soluition folder $folder1."
        # Set the exit code to 1
        $exitCode = 1
    }
}

# Exit the script with the exit code
$LASTEXITCODE = $exitCode
Exit $exitCode


