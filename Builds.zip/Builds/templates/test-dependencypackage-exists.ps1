[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $BuildArtifactsStagingDirectory,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $PackageName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $Version,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $BuildId
)

$ErrorActionPreference = 'Stop'

#Fetch the directory for LocalFeed
$AgentWorkingPath = Split-Path(Split-Path $BuildArtifactsStagingDirectory)
$LocalFeedDirectory = "$AgentWorkingPath\_temp\LocalFeed"
Write-Verbose "Local Feed Directory is $LocalFeedDirectory"

#Fetch the Nuget file to be installed
$NugetFilePath = "$BuildArtifactsStagingDirectory\NuGet"
Write-Verbose "NuGet File Path is $NugetFilePath"

#Delete LocalFeed Directory if exists
Remove-Item $LocalFeedDirectory -Recurse -ErrorAction Ignore
Write-Verbose "Cleaned up Local Feed Directory if exists"

#Create LocalFee Directory to install Nuget Packages
New-Item -ItemType Directory -Force -Path $LocalFeedDirectory
Write-Verbose "Created new Local Feed Directory"

try{
    #Define Source for LocalFeed
    nuget sources add -name Local -Source $LocalFeedDirectory
    Write-Verbose "New Nuget Local source created"

    #Add Nuget Package to LocalFeed
    nuget add "$NugetFilePath\$PackageName.$Version.$BuildId.nupkg" -source $LocalFeedDirectory
    Write-Verbose "added $PackageName.$Version.$BuildId.nupkg to LocalFeed"

    #Install Nuget Package
    nuget install $PackageName -Version "$Version.$BuildId" 

    if($LASTEXITCODE -eq 0)
    {
        Write-Verbose "Installed $PackageName with version $Version.$BuildId successfully"
    }
    else
    {
        Write-Verbose "$PackageName with version $Version.$BuildId not installed successfully"
        exit -1
    }    
}
catch{
    Write-Verbose "ERROR: $( $_.Exception )"
    exit -1
}
finally {
    #Delete Local Source for NugetFeed
    nuget sources remove -name Local
    Write-Verbose "Removed Local Nuget Source"

    #Clean LocalFeed Directory
    Remove-Item $LocalFeedDirectory -Recurse -ErrorAction Ignore
    Write-Verbose "Cleaned up LocalFeed Directory"
}


