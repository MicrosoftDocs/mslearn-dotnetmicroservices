#!/usr/bin/bash

# Script expects: gtestResult.xml FlakyTests.mac.txt NonFlakyFailedTests.txt paths
GTEST_RESULT_FILE="$1"
FLAKY_TESTS_FILE="$2"
NON_FLAKY_FAILED_TESTS_FILE="$3"

# Parse XML file for Failed Test Names:
FAILED_TEST_NAMES_STRING=$(xmllint --xpath '/testsuites/testsuite/testcase/failure/../@name' "$GTEST_RESULT_FILE" | sed 's/"/\n/g;' | grep -v '^ ')

# Parse Failed Test Names to an array:
FAILED_TEST_NAMES_ARRAY=(${FAILED_TEST_NAMES_STRING//'\r\n'/ })
# Get Number of Failed Tests:
NUMBER_OF_FAILED_TESTS=${#FAILED_TEST_NAMES_ARRAY[@]}

# Read FlakyTests.mac.txt:
FLAKY_TEST_NAMES_STRING=`cat "$FLAKY_TESTS_FILE"`
# Parse FlakyTests.mac.txt content to an array:
FLAKY_TEST_NAMES_ARRAY=(${FLAKY_TEST_NAMES_STRING//'\r\n'/ })

# Container for non flaky failed tests:
NON_FLAKY_FAILED_TEST_NAMES=""

# Check if failed tests are Flaky or not:
for failedTestName in "${FAILED_TEST_NAMES_ARRAY[@]}"
do
	testIsFlaky=false
	for flakyTestName in "${FLAKY_TEST_NAMES_ARRAY[@]}"
	do
		if [ ${failedTestName} = ${flakyTestName} ]
		then
			testIsFlaky=true
		fi
	done


	if [ $testIsFlaky = true ]
	then
		echo "Test failed: $failedTestName (ignored due to known flakiness)"
		NUMBER_OF_FAILED_TESTS=$((NUMBER_OF_FAILED_TESTS-1))
	else
		echo "Test failed: $failedTestName"
		NON_FLAKY_FAILED_TEST_NAMES="$NON_FLAKY_FAILED_TEST_NAMES\n$failedTestName"
	fi
done

# If NonFlakyFailedTests.txt exists remove it
if [ -f "$NON_FLAKY_FAILED_TESTS_FILE" ]
then
	rm -rf "$NON_FLAKY_FAILED_TESTS_FILE"
fi

# Print how many non flaky tests failed:
echo "number of non flaky tests failed: $NUMBER_OF_FAILED_TESTS"

# If there are non flaky test failures write such test names to NonFlakyFailedTests.txt and fail
echo $NON_FLAKY_FAILED_TEST_NAMES > "$NON_FLAKY_FAILED_TESTS_FILE"
if [ $NUMBER_OF_FAILED_TESTS -gt 0 ]
then
	exit 1
fi
