param([bool]$wait=$true)

if (-not $wait)
{
	Start-Job -FilePath $PSCommandPath
	exit 0
}



Start-Sleep -Seconds 100000