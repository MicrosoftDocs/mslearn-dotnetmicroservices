<# Install.ps1
  Usage: Install.ps1 -Product {Product} [-Version {Version}] [-WhatIf] [-Force]
  {Product} can contain wildcards, e. g. DotNet*, you can concatenate several products like this: "Revit*;Sketchup*"
  
  {Version} usually corresponds to a source (file or folder) in the installer-sources directory. For unversioned Products, 0 is used
  {WhatIf} Don't actually run the installer, just display what would have happened
  {Force} Install even if Registry entry with matching version exists.
  
  Adding new products:
  
  To use an .msi file with default args, simply put the file to $InstallerSources\$Product\$Version.msi
  and call this script like so:
  Install.ps1 -Product $Product
 
  For all kinds of customizations, see Install-Product.ps1.template
#>
param
(
  [Parameter(Mandatory=$true)][String]$Product,
  $Version=$null,
  [Switch]$WhatIf=$false,
  [Switch]$Force=$false
)

Import-Module "$PSScriptRoot\Log.psm1"
Import-Module "$PSScriptRoot\Install.psm1"

$products = Find-Products -Product $Product -Version $Version
Write-Host "Found products: {$products}"
if ($products.Count -eq 0)
{
  Write-Error "No products found with name '$Product'."
  exit 1
}

if ($WhatIf) { exit 0 }

$hasError = 0
$successProducts = @()
$errorProducts = @()
$exitCode = 0
foreach ($product in $products)
{
  $exitCode = (Install -Product $product -Version $version -Force $Force) | Select-Object -Last 1
  Write-Host "'$product' exit code: $exitCode."
  if ($exitCode -ne 0)
  {
    $errorProducts += $product
    $hasError = 1
  }
  else
  {
    $successProducts += $product
  }
}

Write-Host "Successful Products: {$successProducts}"
if ($errorProducts.Count -ne 0)
{
  Write-Error "Errorous Products: {$errorProducts}"
}

if ($hasError)
{
  if ($exitCode -ne 0)
  {
			exit $exitCode
  }
  exit 1
}
else
{
  exit 0
}


