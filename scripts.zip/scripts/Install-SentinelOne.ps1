# Args for the .exe installer of SentinelOne Agent
# Enscape-ProtectDetect Token:
$GroupToken = "eyJ1cmwiOiAiaHR0cHM6Ly9ldWNlMS0xMDYuc2VudGluZWxvbmUubmV0IiwgInNpdGVfa2V5IjogImdfMTkzZWNhMzIxNTlmN2E2MiJ9"

$AdditionalArgs = @("--qn","-t",$GroupToken)