param([String]$computerName="",[String]$productKey="")

$sls = Get-WmiObject -Query 'SELECT * FROM SoftwareLicensingService' -ComputerName $computerName
@($sls).foreach({
  $_.InstallProductKey($productKey)
  $_.RefreshLicenseStatus()
})

