﻿$LoaderScriptFileName = "Run-Tfs-Agent-Loader.ps1"
$LoaderScriptFileLocation = $PSScriptRoot
$LoaderScriptFileFullPath = Join-Path -Path $LoaderScriptFileLocation -ChildPath $LoaderScriptFileName

$LocalFolder = "${Env:USERPROFILE}\AppData\Roaming\Enscape-Agent\Agent\"
$LocalLoaderScriptFullPath = Join-Path -Path $LocalFolder -ChildPath $LoaderScriptFileName
if (! (Test-Path $LocalFolder )) { mkdir $LocalFolder }
if (! (Test-Path $LocalLoaderScriptFullPath )) { cp $LoaderScriptFileFullPath $LocalFolder }
