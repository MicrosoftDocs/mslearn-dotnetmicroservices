param
(
  [Switch]$force=$false
)

Import-Module "$PSScriptRoot\Log.psm1"
Import-Module "$PSScriptRoot\Install.psm1"

$product = "icinga2 agent"

$installed = Get-EnscapeSoftware $product

$ComputerName = $env:COMPUTERNAME.ToLower()
$ParamPath = 'HKLM:\System\CurrentControlSet\Services\TCPIP\Parameters'
$Property = 'Hostname'
Push-Location $ParamPath
Set-ItemProperty -path $ParamPath -name $Property -value $ComputerName
Pop-Location

if (-not [string]::IsNullOrEmpty($installed) -and -not $force) 
{
  Write-Host "Not installing $product. If this is undesired, use force."
}
else
{

$DOMAIN_SHARE = "$PSScriptRoot\.."
$icingaMetaClientDir = Join-Path -Path $DOMAIN_SHARE -ChildPath "scripts\icinga"
$icingaMetaClient = Join-Path -Path $icingaMetaClientDir -ChildPath "ci-host.exe"

$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition

$hostname = hostname
$hostname = $hostname.ToLower()
echo $hostname
$fullhostname = $hostname + ".local.enscape"
echo $fullhostname
$filename = $fullhostname + ".txt"
echo $filename
$fullfilename = Join-Path -Path $scriptPath -ChildPath $filename
echo $fullfilename

Pushd $icingaMetaClientDir
& $icingaMetaClient create $hostname -v
$ticket = & $icingaMetaClient pki $hostname
Popd
echo "Ticket: $ticket"

$icingapath = [io.path]::combine($Env:Programfiles, "Icinga2" , "sbin")
Pushd $icingapath

echo ".\icinga2 pki save-cert --host icinga2.local.enscape --port 5665 --key local.key --cert local.crt --trustedcert parent.crt"
.\icinga2 pki save-cert --host icinga2.local.enscape --port 5665 --key local.key --cert local.crt --trustedcert parent.crt
echo "Setting up node: '$fullhostname' ..."
echo ".\icinga2 node setup --zone $fullhostname --endpoint icinga2.local.enscape --parent_host icinga2.local.enscape --parent_zone Master --ticket $ticket --accept-config --accept-commands --disable-confd --trustedcert parent.crt"
.\icinga2.exe node setup --zone $fullhostname --endpoint icinga2.local.enscape --parent_host icinga2.local.enscape --parent_zone Master --ticket $ticket --accept-config --accept-commands --disable-confd --trustedcert parent.crt

Popd

echo "net stop icinga2"
net stop icinga2
$Icinga2StatePath = "C:\ProgramData\icinga2\var\lib\icinga2\icinga2.state"
echo "deleting $Icinga2StatePath ..."
if (Test-Path -Path $Icinga2StatePath) { del $Icinga2StatePath }
$Icinga2ApiPath = "C:\ProgramData\icinga2\var\lib\icinga2\api"
echo "deleting $Icinga2ApiPath ..."
if (Test-Path -Path $Icinga2ApiPath) { Remove-Item -Recurse -Force $Icinga2ApiPath }

echo "net start icinga2"
net start icinga2

Set-EnscapeSoftwareRegKey $product "1"
}
