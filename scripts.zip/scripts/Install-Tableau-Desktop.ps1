& "$PSScriptRoot\Install.ps1" -Product "VCRedist"
& "$PSScriptRoot\Install.ps1" -Product "OpenJdk"
& "$PSScriptRoot\Install.ps1" -Product "Snowflake"

$AdditionalArgs = @("/quiet", "/norestart", "ACCEPTEULA=1", "AUTOUPDATE=0", "REMOVEINSTALLEDAPP=1")