$AdditionalArgs = @("/VERYSILENT", "/SP-", "/CLOSEAPPLICATIONS", "/RESTARTAPPLICATIONS", "/SUPPRESSMSGBOXES", "/COMPONENTS=ext,ext\shellhere,ext\guihere,assoc,assoc_sh")

$OnPostInstall = {
  param($sourcePath)

  & "$PSScriptRoot\Install.ps1" -Product "Git-Lfs"
  
  return 0
}

