$DomainShare = "$PSScriptRoot\.."

$InitialErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"
$scriptFileDescriptor = (Split-Path $MyInvocation.PSCommandPath -leaf).Replace(":","").Replace("\","").Replace("/","")
$LOG_FILE = "C:\Enscape-PS-Logs\$scriptFileDescriptor.log"
New-Item -ItemType Directory -Force -Path (get-item $LOG_FILE).Directory.Parent
Start-Transcript -path $LOG_FILE -append
$ErrorActionPreference = $InitialErrorActionPreference

$PathLogs = [IO.Path]::Combine($DomainShare, "logs")
$PathLogsScripts = [IO.Path]::Combine($DomainShare, "scripts")

$DateTime = Get-Date -Format "yyyy.MM.dd-HHmmss"
$LogFileName = [IO.Path]::Combine($PathLogs, $env:computername, "$scriptFileDescriptor-$DateTime.log")

Write-Host "LogFileName: $LogFileName"

Start-Transcript -path $LogFileName -append

