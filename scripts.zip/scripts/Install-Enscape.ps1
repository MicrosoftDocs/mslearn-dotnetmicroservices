& "$PSScriptRoot\Install.ps1" -Product "Vulkan-Runtime"
& "$PSScriptRoot\Install.ps1" -Product "VCRedist"
& "$PSScriptRoot\Install.ps1" -Product "Enscape-License"

$AdditionalArgs = @("ACCEPTEULA=1", "ALLUSERS=1")