﻿#Get current date and time for folder rename
$datetime = Get-Date -Format yyMMdd_HHMM

#Stop icinga2 service
net stop "Icinga2"

#Rename existing files and folders
Rename-Item -NewName outofsync_api.$datetime-Path C:\ProgramData\icinga2\var\lib\icinga2\api -Force
Rename-Item -NewName outofsync_icinga2.state.$datetime -Path C:\ProgramData\icinga2\var\lib\icinga2\icinga2.state -Force
Rename-Item -NewName outofsync_modified-attributes.conf.$datetime_ -Path C:\ProgramData\icinga2\var\lib\icinga2\modified-attributes.conf -Force

#Restart icinga2 service
net start "Icinga2"