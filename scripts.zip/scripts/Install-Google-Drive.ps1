$AdditionalArgs = @("--silent", "--desktop_shortcut")

$OnPostInstall = {
  param($sourcePath)

# Kill the "Sign-in now" popup window
  Write-Host "Kill sign-in process"
  TASKKILL /F /IM GoogleDriveFS.exe
  exit 0
}