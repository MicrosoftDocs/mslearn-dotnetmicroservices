$AdditionalArgs = @("/VERYSILENT", "/SP-", "/CLOSEAPPLICATIONS", "/RESTARTAPPLICATIONS", "/SUPPRESSMSGBOXES")

$OnPostInstall = {
  param($sourcePath)
  
  # Refresh environment variables
  Write-Output "Refreshing environment variables"
  $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine")

  #Configure git lfs
  $GitLFSVersion = & git lfs --version
  Write-Output $GitLFSVersion
  

  if ($GitLFSVersion -contains "git: 'lfs' is not a git command.")
  {
	  Write-Error "lfs not recognized by git"
	  return 1
  }

  Write "Git LFS found, configuring..."
  cd C:\
  & git lfs install --system

  return 0
}
