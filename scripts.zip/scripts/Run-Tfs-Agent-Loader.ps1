﻿$RunScriptFullPath = "\\rackstation.local.enscape\domain-share\scripts\Run-Tfs-Agent.ps1"

while($true)
{
	& $RunScriptFullPath
	if ($?)
	{
		exit 0
	}
	sleep 60
}