$InstallerPath = "rustdesk-1.1.9-host=rustdeck.local.enscape,key=4uKTqCMAQOz7VOt42GGyJnYvixR+AK5jRyGPcn6ywdU=.exe"
$AdditionalArgs = @("--silent-install")

$OnPostInstall = {  
    
    Remove-Item "C:\Users\Public\Desktop\RustDesk.lnk"
    
    return 0
} 

