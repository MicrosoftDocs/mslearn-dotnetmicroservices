$InstallerPath = "installer.exe"
$AdditionalArgs = @("/S")

#todo: uninstall
# uninstall software
# remove node config
# delete node?

$OnPostInstall = {
  param($sourcePath)

  write-host "Copying sidecar.yml ..."
  copy $sourcePath\sidecar.yml 'C:\Program Files\Graylog\sidecar' 
  if (!$?) { "Error copying sidecar.ym"; return 1 }

  write-host "installing service ..."
  & "C:\Program Files\graylog\sidecar\graylog-sidecar.exe" -service install
  if (!$?) { "Error installing service" } # don't give up yet, we can still try to start it.

  write-host "starting service ..."
  & "C:\Program Files\graylog\sidecar\graylog-sidecar.exe" -service start
  if (!$?) { "Error starting service" } # will throw an error if already running. That's how things are.

  write-host "getting node_id ..."
  $node_id = Get-Content "C:\Program Files\graylog\sidecar\node-id"
  if (!$?) { "Error getting node_id"; return 1 }
  write-host "node_id: $node_id"

  
  write-host "enable sidecar configuration on graylog server ..."
  PushD \\rackstation.local.enscape\domain-share\bin\sidecar
  $max_tries = 3
  $try = 0
  do
  {
    $try += 1
    write-host "waiting 10 seconds for node poll (try: $try) ..."
    Start-Sleep 10
    .\sidecar.exe add $node_id
    $exitcode = $?
  } while(!$exitcode -and $try -lt $max_tries)
  PopD
  if (!$exitcode) { "Error adding node_id $node_id to server"; return 1 }
  
  return 0
}

