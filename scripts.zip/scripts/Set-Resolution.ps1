param([Int]$x, [Int]$y)

& $PSScriptRoot\..\software\QRes.exe /x $x /y $y
