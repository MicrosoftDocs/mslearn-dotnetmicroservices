param([String]$computerName="",[String]$agentPassword="")

$domain = "local.enscape"
$ou = "OU=ci-agents,OU=Computers,OU=enscape,DC=local,DC=enscape"
if ($computerName)
{
  Add-Computer -DomainName $domain -OUPath $ou -NewName $computerName
}
else
{
  Add-Computer -DomainName $domain -OUPath $ou
}

New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "AutoAdminLogon" -Value "1" -PropertyType String -Force | Out-Null
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "DefaultDomainName" -Value "local.enscape" -PropertyType String -Force | Out-Null
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "DefaultUserName" -Value "agent" -PropertyType String -Force | Out-Null
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "DefaultPassword" -Value $agentPassword -PropertyType String -Force | Out-Null

echo "Restarting in 10 seconds. Press CTRL+C to abort"
Start-Sleep -Seconds 10
Restart-Computer