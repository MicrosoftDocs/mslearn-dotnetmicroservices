$InstallerPath = "rustdesk-1.1.9-host=rustdeck.local.enscape,key=4uKTqCMAQOz7VOt42GGyJnYvixR+AK5jRyGPcn6ywdU=.exe"
$AdditionalArgs = @("--silent-install")

$OnPostInstall = {  
    Stop-Service -name "RustDesk"
    
    $lowhostname = $env:computername.ToLower()

    $idline = Get-Content c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk.toml | Select-String "id =" | Select-Object -ExpandProperty Line
    (Get-Content c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk.toml) -replace $idline,"id = '$lowhostname'" | Set-Content c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk.toml
    
    $idline = Get-Content c:\Users\agent\AppData\Roaming\RustDesk\config\RustDesk.toml | Select-String "id =" | Select-Object -ExpandProperty Line
    (Get-Content c:\Users\agent\AppData\Roaming\RustDesk\config\RustDesk.toml) -replace $idline,"id = '$lowhostname'" | Set-Content c:\Users\agent\AppData\Roaming\RustDesk\config\RustDesk.toml
        
    $passline = Get-Content c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk.toml | Select-String "password =" | Select-Object -ExpandProperty Line
    (Get-Content c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk.toml) -replace $passline,"password = 'Enscape123'" | Set-Content c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk.toml

    $passline = Get-Content c:\Users\agent\AppData\Roaming\RustDesk\config\RustDesk.toml | Select-String "password =" | Select-Object -ExpandProperty Line
    (Get-Content c:\Users\agent\AppData\Roaming\RustDesk\config\RustDesk.toml) -replace $passline,"password = 'Enscape123'" | Set-Content c:\Users\agent\AppData\Roaming\RustDesk\config\RustDesk.toml

    Add-Content -Path c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk2.toml -Value "key = '4uKTqCMAQOz7VOt42GGyJnYvixR+AK5jRyGPcn6ywdU='"
    Add-Content -Path c:\Windows\ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config\RustDesk2.toml -Value "custom-rendezvous-server = 'rustdeck.local.enscape'"
    
    Start-Service -name "RustDesk"
    Write-Host "RustDesk Service restarted"

    Remove-Item "C:\Users\Public\Desktop\RustDesk.lnk"
    
    return 0
} 

