$InstallerPath = "Firefox Setup.exe"
$AdditionalArgs = @("/S", "/INI=$InstallerPath\install.ini")

$OnPostInstall = {
  param($sourcePath)

  #Install Browser Extensions
  Copy-Item -Path "$sourcePath\extensions\" -Destination "${env:ProgramFiles}\Mozilla Firefox\distribution\extensions\" -Recurse -Force

  return 0
}
