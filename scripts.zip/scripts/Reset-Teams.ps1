# Create/Overwrite backup of Teams or reset Teams to backuped state

param([Parameter(Mandatory=$true)][String]$User, [switch]$make = $false)

Import-Module "$PSScriptRoot\Log.psm1"

$TeamsDir = "C:\Users\$User\AppData\Roaming\Microsoft\Teams"
$BackupDir = "C:\Users\$User\repository\Teams"

Write-Host "DEBUG: TeamsDir = $TeamsDir"
Write-Host "DEBUG: BackupDir = $BackupDir"


#Make Backup
if ($make)
{
	if((Test-Path $TeamsDir) -eq $false)
	{
		Write-Error "Source Directory $TeamsDir not found!"
		exit 1
	}
	
	Write-Host "DEBUG: Make/Update Backup at $BackupDir"
	robocopy $TeamsDir $BackupDir /B /MIR /r:0 /w:0 /log:C:\Enscape-PS-Logs\Reset-Teams-Make.log
	Write-Host "Make/Update Backup - Complete"
	exit 0
}
#Reset Teams
else
{
	if((Test-Path $BackupDir) -eq $false)
	{
		Write-Error "Backup Repository $BackupDir not found!"
		exit 1
	}
	
	Write-Host "DEBUG: Reset Teams for $User"
	robocopy $BackupDir $TeamsDir /B /MIR /r:0 /w:0 /log:C:\Enscape-PS-Logs\Reset-Teams.log
	Write-Host "Reset Teams - Complete"
	exit 0
}
