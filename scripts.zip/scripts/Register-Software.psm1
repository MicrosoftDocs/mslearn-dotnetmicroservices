$enscape_reg_key = "HKLM:\Software\Enscape\Installed Software"

function Set-EnscapeSoftware { param([String]$vendor, [String]$product, [Int32]$value)

	$key = "$enscape_reg_key\$vendor"
	if(!(Test-Path $key)){
		New-Item $key  -Force;
	}
	Set-ItemProperty -Path $key -Name $product -Value $value -Force
}

function Get-EnscapeSoftware($vendor, $product)
{
	$key = "$enscape_reg_key\$vendor"
	if(!(Test-Path $key)){
	  return ""
	}
	else
	{
	  $item = Get-ItemProperty -Path $key
	  return $item.$product
	}
}
