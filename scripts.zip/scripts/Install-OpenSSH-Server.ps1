$OnInstall = {
  param($sourcePath)
    $success = $True
	Write-Host "Searching for DISM capability 'OpenSSH.Server' ..."
    $capability = dism /online /get-capabilities | findstr /i "OpenSSH.Server"
	$capabilities = $capability.split(" ")
	$capability = $capabilities[$capabilities.Count - 1]
	Write-Host "Activating DISM capability '$capability' ..."
    dism /online /Add-Capability /CapabilityName:"$capability"
	$success = $success -And $?
	Write-Host "Success: $success"
	$config_file = Join-Path -Path $sourcePath -ChildPath "sshd_config"
	$config_file_target = Join-Path -Path $env:ProgramData -ChildPath "ssh"
	Write-Host "copying config file ..."
    Copy-Item $config_file -Destination $config_file_target -Force
	$success = $success -And $?
	Write-Host "Success: $success"
	Write-Host "(Re)starting sshd service"
	Restart-Service sshd
	$success = $success -And $?
	Write-Host "Success: $success"
	$returnCode = if ($success) {0} Else {1}
	return $returnCode
}
