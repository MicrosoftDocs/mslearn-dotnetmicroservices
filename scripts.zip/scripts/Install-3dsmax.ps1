$InstallerPath = "Img\Setup.exe"
$AdditionalArgs = @("/w", "/qb", "/I", "Img\Minimal.ini", "/Trial", "/language" ,"en-us")
