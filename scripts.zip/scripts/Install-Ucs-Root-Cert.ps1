$OnInstall = {
  param($sourcePath)
  Import-Certificate -FilePath $sourcePath  -CertStoreLocation 'Cert:\LocalMachine\Root'
  return 0
}
