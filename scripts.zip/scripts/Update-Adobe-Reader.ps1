<# General Notes
Updates Adobe Acrobat Reader
Check if installed and status, get newest version, install
Source of the base script: https://reverse-shell.net/2018/07/20/powershell_autoupdate_adobereader/
#>

param([switch]$Force = $false)

Import-Module "$PSScriptRoot\Log.psm1"
Import-Module "$PSScriptRoot\Register-Software.psm1"
# Import-Module "$PSScriptRoot\Lib-Utility.psm1"

$DomainSharePath = "$PSScriptRoot\.."
$InstallerPath = "$DomainSharePath\software\Adobe\Acrobat Reader"
$TempFolderPath = "C:\Windows\Temp\Adobe Reader\"
$ArgumentList = @("/sAll", "-NoNewWindow")

# Get Current Adobe reader version.
$CurrentReaderInfo = Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Where-Object{$_.DisplayName -like "*Adobe*" -and $_.DisplayName -like "*Reader*"}

Write "DEBUG: $CurrentReaderInfo"

# If reader is installed then...
if ($CurrentReaderInfo -ne $null)
{

	# Tidy version to numeric string.
	$CurrentReaderVersion = ($CurrentReaderInfo.DisplayVersion.ToString()).Replace(".","")
	
	Write "DEBUG: CurrentVersion: $CurrentReaderVersion"

	# Set download folder and ftp folder variables
	$FTPFolderUrl = "ftp://ftp.adobe.com/pub/adobe/reader/win/AcrobatDC/"

	#connect to ftp, and get directory listing
	$FTPRequest = [System.Net.FtpWebRequest]::Create("$FTPFolderUrl")
	$FTPRequest.Method = [System.Net.WebRequestMethods+Ftp]::ListDirectory
	$FTPResponse = $FTPRequest.GetResponse()
	$ResponseStream = $FTPResponse.GetResponseStream()
	$FTPReader = New-Object System.IO.Streamreader -ArgumentList $ResponseStream
	$DirList = $FTPReader.ReadToEnd()

	#from Directory Listing get last entry in list, but skip one to avoid the 'misc' dir
	$LatestUpdate = $DirList -split '[\r\n]' | Where {$_} | Select -Last 1 -Skip 1

	Write "DEBUG: NewestVersion $LatestUpdate"

	# Compare latest availiable update version to currently installed version.
	if (($LatestUpdate -ne $CurrentReaderVersion) -or ($force))
	{
		#Detect Language
		$CurrentReaderLanguage = $CurrentReaderInfo.DisplayName.Split(" - ")[-1]
		if($CurrentReaderLanguage -eq "DC")
		{
			$lang = "_en_US"
		}
		elseif ($CurrentReaderLanguage -eq "Deutsch")
		{
			$lang = "_de_DE"
		}
		else
		{
			Write-Error "Language Pack for $CurrentReaderLanguage currently not supported. Please update manually and/or contact Operations"
			exit 1
		}

		#build file name
		$LatestFile = "AcroRdrDC" + $LatestUpdate + $lang + ".exe"
		
		# Build filepath
		$FilePath = "$InstallerPath\$LatestFile"
		Write "DEBUG: Checking FilePath: $FilePath"
		
		#Check for installer on domain-share
		if (!(Test-Path "$FilePath"))
		{
			#build download url for latest file
			$DownloadURL = "$FTPFolderUrl$LatestUpdate/$LatestFile"
		
			Write "DEBUG: Downloading $DownloadURL to $FilePath"
	
			#download file
			"Downloading latest Reader version."
			(New-Object System.Net.WebClient).DownloadFile($DownloadURL, $FilePath)
		}
		
		#Copy Installer File(s) to Local Disk
		"Copy File."
		if (!(Test-Path "$TempFolderPath\$LatestFile"))
		{
			New-Item -Path $TempFolderPath -ItemType "directory" -Force
			Copy-Item -Path "$FilePath" -Destination "$TempFolderPath" -Recurse
		}
		else 
		{
			"Skipped: Local temp file $TempFolderPath\$LatestFile already exists!"
		}
		# Install quietly
		"Installing."
		$p = Start-Process -PassThru -Wait -FilePath "$TempFolderPath\$LatestFile" -ArgumentList $ArgumentList
		$exitcode = $p.ExitCode

		# Clean up after install
		"Cleaning."
		Remove-Item -Path $TempFolderPath -Recurse
		exit $exitcode
	}

	else
	{"Latest version already installed."}
}

else
{"Reader not installed."}