$AdditionalArgs = @("ADDLOCAL=ALL")
Set-Alias -Name svn -Value "$($Env:ProgramFiles)\TortoiseSVN\bin\svn.exe"