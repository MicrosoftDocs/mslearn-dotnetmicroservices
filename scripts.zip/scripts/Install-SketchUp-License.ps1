$OnInstall = {
  param($sourcePath)
  $CommonApplicationData = [Environment]::GetFolderPath('CommonApplicationData')
  $Versions = @(2018, 2019, 2020, 2021, 2022, 2023)
  foreach ($version in $versions)
  {
    $SketchUpPath = Join-Path -Path $CommonApplicationData -ChildPath "SketchUp\SketchUp $version"
    if (!(Test-Path -Path $SketchUpPath))
    {
      New-Item -Path $SketchUpPath -ItemType "directory"
    }
	$license_src = "$sourcePath\$version\activation_info.txt"
    Copy-Item $license_src $SketchUpPath
  }
  return 0
}
