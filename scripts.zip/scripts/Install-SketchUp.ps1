& "$PSScriptRoot\Install.ps1" -Product "SketchUp-License" -force
& "$PSScriptRoot\Install.ps1" -Product "VCRedist"

if ($null -eq $Version -or $Version.contains("2020") -or $Version.contains("2021") -or $Version.contains("2022") -or $Version.contains("2023")) { $AdditionalArgs = @("/silent") }
