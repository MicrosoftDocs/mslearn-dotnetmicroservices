$ProductSource = "Stadia"

$OnInstall = {
  param($sourcePath)
    $argumentListUninstall = @("/x", $sourcePath, "/qn", "REBOOT=R")
	Write-Host "Uninstalling ..."
    $p = Start-Process -PassThru -Wait -FilePath "msiexec" -ArgumentList $argumentListUninstall
	Write-Host "Uninstalling returned $($p.ExitCode)"
	return $p.ExitCode
}
