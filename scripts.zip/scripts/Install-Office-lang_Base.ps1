$ProductSource = "Office"
$OnInstall = {
  param($sourcePath)
    $argumentList = @("/configure", "$sourcePath\Office365-x64-lang_Base.xml")
    $p = Start-Process -PassThru -Wait -FilePath "$sourcePath\setup.exe" -ArgumentList $argumentList
	return $p.ExitCode
}
