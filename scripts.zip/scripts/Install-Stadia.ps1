$OnInstall = {
  param($sourcePath)
    $argumentListUninstall = @("/x", $sourcePath, "/qn", "REBOOT=R")
	Write-Host "Uninstalling ..."
    $p = Start-Process -PassThru -Wait -FilePath "msiexec" -ArgumentList $argumentListUninstall
	Write-Host "Uninstalling returned $($p.ExitCode)"
	Write-Host "Installing ..."
	$argumentList = @("/i", $sourcePath, "/qn", "ALLUSERS=1", "REBOOT=R")
	$p = Start-Process -PassThru -Wait -FilePath "msiexec" -ArgumentList $argumentList
	return $p.ExitCode
}
