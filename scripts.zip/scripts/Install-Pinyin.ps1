$AdditionalArgs = @("/S")
