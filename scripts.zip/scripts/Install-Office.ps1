$OnInstall = {
  param($sourcePath)
    $argumentList = @("/configure", "$sourcePath\configuration-Office365-x64.xml")
    $p = Start-Process -PassThru -Wait -FilePath "$sourcePath\setup.exe" -ArgumentList $argumentList
	return $p.ExitCode
}
