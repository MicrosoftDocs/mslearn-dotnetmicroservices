$output = & $PSScriptRoot\..\software\QRes.exe /s
foreach ($line in $output)
{
  $parts1 = $line.Split('x')
  if ($parts1.Count -eq 2)
  {
    $x = $parts1[0]
	$parts2 = $parts1[1].Split(',')
	$y = $parts2[0]
	$res = @($x,$y)
	return $res
  }
}