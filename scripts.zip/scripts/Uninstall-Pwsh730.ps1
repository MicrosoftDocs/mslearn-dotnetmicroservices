Start-Process C:\Windows\System32\msiexec.exe -ArgumentList "/uninstall \\rackstation\domain-share\installer-sources\Pwsh\7.3.0.msi /q " -wait
Start-Process C:\Windows\System32\msiexec.exe -ArgumentList "/uninstall \\rackstation\domain-share\installer-sources\Pwsh\7.3.2.msi /q " -wait

\\rackstation\domain-share\scripts\Install.ps1 -Product "Pwsh" -version "7.1.3"