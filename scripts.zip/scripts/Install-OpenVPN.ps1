$InstallerPath = "OpenVPN-2.5.8-I603-amd64.msi"
$AdditionalArgs = @("/norestart")

$OnPostInstall = {
  param($sourcePath)

  Copy-Item -Path "$sourcePath\client config\" -Destination "${env:ProgramFiles}\OpenVPN\config\" -Recurse -Force

  return 0
}
