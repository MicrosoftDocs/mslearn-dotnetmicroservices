$InstallerPath = "WixToolset.vsix"

if ($null -eq $Version)
{
  $version = "2019"
}

$OnInstall = {
  param($sourcePath, $version)
    $argumentList = @("/quiet", "$sourcePath\$InstallerPath")
	$exitCode = 1
	$hasRun = $false
	foreach ($productType in @("professional", "community"))
	{
	  foreach ($programFilesLocation in @( ${env:ProgramFiles(x86)}, ${env:ProgramFiles} ))
	  {
		  $path = "${programFilesLocation}\Microsoft Visual Studio\$version\$productType\Common7\IDE\VSIXInstaller.exe"
		  if([System.IO.File]::Exists($path))
		  {
			Write-Host "Found VSIXInstaller in '$path'."
			$p = Start-Process -PassThru -Wait -FilePath $path -ArgumentList $argumentList
			Write-Host "VSIXInstaller returned $($p.exitCode)."
			if ($p.exitCode -eq 0)
			{
			  $exitCode = 0
			}
			$hasRun = $true
		  }
	  }
	}
	if (!$hasRun) { Write-Host "VSIXInstaller was not found in any path." }
	return $exitCode
}