<# General Notes
Checks for installation &  version
Update config files
#>

Import-Module "$PSScriptRoot\Log.psm1"
Import-Module "$PSScriptRoot\Register-Software.psm1"
Import-Module "$PSScriptRoot\Lib-Utility.psm1"

$DomainSharePath = "$PSScriptRoot\.."
$InstallerPath = "$DomainSharePath\software\OpenVPN"
$RegistryPath = "HKLM:\Software\OpenVPN"

$MinVersionRequired = "2.4.0"

#Get Info and check installation


if (Test-Path $RegistryPath)
{
	$CurrentSoftwareInfo = Get-ItemProperty $RegistryPath | Select-Object config_dir, exe_path
	$ConfigPath = $CurrentSoftwareInfo.config_dir.ToString()
	$ExePath = $CurrentSoftwareInfo.exe_path.ToString()

#	Write "DEBUG: $CurrentSoftwareInfo"
#	Write "DEBUG: ConfigPath $ConfigPath"
#	Write "DEBUG: ExePath $ExePath"

	#Check Version
	$CurrentVersion = (& $ExePath --version).Split(" ")[1]
	Write-Host "Compatible OpenVPN Version $CurrentVersion found."
	
	if ($CurrentVersion -ge $MinVersionRequired)
	{
		Write-Host "Copy config to $ConfigPath"
		Copy-Item -Path "$InstallerPath\client config\" -Destination $ConfigPath -Recurse -Force
		Write-Host "Successful."		
	}
	else
	{
		Write-Error "Old version of OpenVPN detected ($CurrentVersion)."
		exit 1
	}
}

else
{
	Write-Host "OpenVPN not installed."
	exit 0
}