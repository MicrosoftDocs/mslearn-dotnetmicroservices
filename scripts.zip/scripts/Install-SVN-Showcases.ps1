& "$PSScriptRoot\Install.ps1" -Product "TortoiseSVN"

function GetLocalDrives
{
  return Get-WmiObject Win32_LogicalDisk -Filter drivetype=3
}

function GetDriveFreeSpace($driveId)
{
  return (Get-WmiObject Win32_LogicalDisk -Filter drivetype=3 | Where-Object { $_.DeviceID -eq $driveId}).FreeSpace / 1024 / 1024 / 1024
}

function FindLocalDriveWithAtLeastGBytes($minBytes)
{
  Write-Host "FindLocalDriveWithAtLeastBytes: $minBytes ... "
  $disks = GetLocalDrives
  $maxFreeSpace = 0
  $selectedDisk = $null
  foreach($disk in $disks)
  { 
    Write-Host "Checking disk: ... $disk ..."
    if ($disk.FreeSpace -gt $maxFreeSpace -and $disk.FreeSpace -ge $minBytes)
    {
      $maxFreeSpace = $disk.FreeSpace
      $selectedDisk = $disk
    }
  }
  Write-Host "Yielding $selectedDisk ..."
  return $selectedDisk
}

function CallProcess($processFile, $argumentList)
{
  Write-Host "running $processFile with args {$argumentList}"
  $p = Start-Process -PassThru -Wait -FilePath $processFile -ArgumentList $argumentList
  return $p
}

function CreateShortcut($shortcutLocation, $dst)
{
	Write-Host "Creating shortcut '$shortcutLocation' -> '$dst'"
	$WshShell = New-Object -ComObject WScript.Shell
	$Shortcut = $WshShell.CreateShortcut($shortcutLocation)
	$Shortcut.TargetPath = $dst
	$Shortcut.Save()
}

function Install-Showcases()
{
  $version = "0"
  if (!$Force)
  {
    $installedVersion = Get-EnscapeSoftware $product
	Write-Host "Installed Product Version: '$installedVersion'"
	if ($installedVersion -eq $version)
	{
	  Write-Host "Installed Product Version matches version. Skipping installation ..."
	  return 0
	}
  }
  $showcases_file = "$PSScriptRoot\svn-showcases\showcases.txt"
  $drive = FindLocalDriveWithAtLeastGBytes(100GB)
  if ($null -eq $drive)
  {
    Write-Error "Could not find hard drive fullfilling specs."
	return 1
  }
  $driveLetter = $drive.DeviceID

  $showcases = Get-Content $showcases_file
  foreach ($showcase in $showcases)
  {
    $showcase_args = $showcase.Split(" ")
    $clone_path = $showcase_args[0]
    $dst_path = Join-Path -Path $driveLetter -ChildPath $showcase_args[1]
    if (!(Test-Path -Path $dst_path))
    {
      $args = @("co", "--username", "svn", "--password", "Enscape123", "--non-interactive", "--trust-server-cert", $clone_path, $dst_path  )
	  svn status
	  if (!$?)
	  {
	    Set-Alias -Name svn -Value "$($Env:ProgramFiles)\TortoiseSVN\bin\svn.exe"
	  }
      svn $args
      if (!$?)
      {
        Write-Error "svn $args failed with $exitcode."
        return $exitcode
      }
    }
  }
  $dst = Join-Path -Path $driveLetter -ChildPath "svn"
  $desktop = [Environment]::GetFolderPath("CommonDesktopDirectory")
  Write-Host "desktop: $desktop"
  $shortcutLocation = Join-Path -Path $desktop -ChildPath "svn.lnk"
  CreateShortcut $shortcutLocation $dst
  Set-EnscapeSoftware $product $version
  return 0
}

$UseDefaultInstaller = $false
$OverrideExitCode = (Install-Showcases)[-1]


