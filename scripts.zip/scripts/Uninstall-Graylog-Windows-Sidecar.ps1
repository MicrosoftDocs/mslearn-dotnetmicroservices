#Uninstalling Graylog Sidecar for Windows

Import-Module "$PSScriptRoot\Log.psm1"
Import-Module "$PSScriptRoot\Install.psm1"

$product = "graylog-windows-sidecar"
$graylogPath = "C:\Program Files\Graylog\sidecar\"

if (!(Test-Path $graylogPath\graylog-sidecar.exe))
{
	Write-Output "$graylogPath\graylog-sidecar.exe does not exist. Exiting..."
	exit 0
}
#Stop + Remove service
& "$graylogPath\graylog-sidecar.exe" -service stop 
& "$graylogPath\graylog-sidecar.exe" -service uninstall

if (!(Test-Path $graylogPath\uninstall.exe))
{
	Write-Output "$graylogPath\uninstall.exe does not exist. Uninstall failed..."
	exit 1
}
#Uninstalling
& "$graylogPath\uninstall" /S

#Remove registry key
Remove-EnscapeSoftwareRegKey ($product)

exit 0