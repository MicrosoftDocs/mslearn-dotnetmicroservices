$InstallerPath = "2021-2-0.exe"
$AdditionalArgs = @("/quiet", "/norestart", "ACCEPTEULA=1", "AUTOUPDATE=0", "REMOVEINSTALLEDAPP=1")

<#
$OnPostInstall = {
  param($sourcePath)

  #Import Config
	$sourcePath = $sourcePath + "\config"
	$targetPath = "${env:USERPROFILE}\Documents\My Tableau Repository"

	$sourceFile = "Preferences.tps"

	Write-Host "Import config: $sourceFile"

	if (!(Test-Path $sourcePath\$sourceFile))
	{
		Write-Error "$sourcePath\$sourceFile not found. Skipping."
	}
	else
	{
		Write-Host "$sourcePath\$sourceFile found."
		if (Test-Path $targetPath\$sourceFile)
		{
			Write-Host "$targetPath\$sourceFile already exists."
			$backupFile = (Get-Date -f yyyy-MM-dd-HH-mm-ss)+"_"+$sourceFile
			Write-Host "Creating backup: $targetPath\$backupFile"
			Copy-Item $targetPath\$sourceFile $targetPath\$backupFile	
		}
		
		Write-Host "Copying $sourcePath\$sourceFile to $targetPath\$sourceFile"
		Copy-Item $sourcePath\$sourceFile $targetPath\$sourceFile
		Write-Host "Import config: Success"

	}
	return 0
}
#>