$AdditionalArgs = @("-quiet", "-passive", "-norestart")
