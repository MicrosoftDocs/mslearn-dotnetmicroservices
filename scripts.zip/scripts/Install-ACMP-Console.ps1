$AdditionalArgs = @("/VERYSILENT", "/norestart", "/noautostartconsole")

