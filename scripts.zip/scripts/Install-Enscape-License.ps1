$UseCache = $false

$OnInstall = {
  param($sourcePath)
  
  $serial = Get-Content -Path "$sourcePath\license.txt"
  $key = "HKLM:\SOFTWARE\Enscape"
  if(!(Test-Path $key)) { New-Item $key -Force }
  
  $value = Get-ItemProperty -Path $key -Name "LicenseKey" -ErrorAction SilentlyContinue
  if(($value -eq $null) -or ($value.lenght -eq 0))
  {
	Write-Host "No serial found: registering serial."
	Set-ItemProperty -Path $key -Name "LicenseKey" -Value $serial
  }
  elseif ($value.LicenseKey -eq $serial)
  {
	Write-Host "Serial already registered."
  }
  else
  {
    Write-Host "A different serial is already registered: Skipping."
	return 1
  }
  return 0 
 }
 
<# Deprecated since Enscape 2.8
$OnInstall = {
  param($sourcePath)

  $CommonApplicationData = [Environment]::GetFolderPath('CommonApplicationData')
  $enscapePath = Join-Path -Path $CommonApplicationData -ChildPath "Enscape"
  if (!(Test-Path -Path $enscapePath))
  {
    New-Item -Path $CommonApplicationData  -Name "Enscape" -ItemType "directory"
  }
  $licenseKey = "$sourcePath\license.txt"
  Write-Host "Copying '$licenseKey' -> '$enscapePath'"
  Copy-Item $licenseKey $enscapePath
  return 0
}
#>
