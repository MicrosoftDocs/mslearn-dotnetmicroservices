# /S is deprecated since v. 1.2.189.1
# see: https://vulkan.lunarg.com/doc/sdk/1.3.204.1/windows/getting_started.html
# $AdditionalArgs = @("/S")
$AdditionalArgs = @("--accept-licenses", "--default-answer", "--confirm-command", "install")