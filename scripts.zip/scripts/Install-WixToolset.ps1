$AdditionalArgs = @("/install", "/quiet", "/norestart")

# This is a workaround for https://github.com/wixtoolset/issues/issues/6089 that occurs with WiX 3.11.2.
# The 3.14 release will fix the issue, so the workaround can be removed after upgrading.
$OnPostInstall = {
  $exitCode = 1
  $signtoolPath = "${env:ProgramFiles(x86)}\Windows Kits\10\App Certification Kit\signtool.exe"
  $dllPath = "${env:ProgramFiles(x86)}\WiX Toolset v3.11\SDK\x64\sfxca.dll"
  if ([System.IO.File]::Exists($signtoolPath) -and [System.IO.File]::Exists($dllPath))
  {
    Write-Host "Found signtool in '$signtoolPath'."
    Write-Host "Found sfxca.dll in '$dllPath'."
    $argumentList = @("remove", "/s", """$dllPath""")
    $p = Start-Process -PassThru -Wait -FilePath "$signtoolPath" -ArgumentList $argumentList
    Write-Host "signtool returned $($p.exitCode)."
    if ($p.exitCode -eq 0)
    {
      $exitCode = 0
    }
  }
  else
  {
    Write-Host "Could not find signtool or sfxca.dll."
  }

  return $exitCode
}
