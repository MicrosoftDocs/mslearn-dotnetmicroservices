$SETUP_INF_FILE = "uvnc-install.inf"
$UVNC_INI_FILE = "ultravnc.ini"
$UVNC_REG_FILE = "uvnc.reg"
$UVNC_INSTALL_DIR = "${Env:Programfiles}\uvnc bvba\UltraVNC"

$InstallerPath = "UltraVNC_1_3_81_X64_Setup.exe"
$AdditionalArgs = @("/loadinf=$SETUP_INF_FILE", "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART")

$OnInstall = {
  param($sourcePath)

  reg import "$sourcePath\$UVNC_REG_FILE"
  if (!(Test-Path -Path $UVNC_INSTALL_DIR)) {New-Item $UVNC_INSTALL_DIR -itemtype directory}
  Copy-Item "$sourcePath\$UVNC_INI_FILE" -Destination $UVNC_INSTALL_DIR
  $p = Start-Process -PassThru -Wait -FilePath "$sourcePath\$InstallerPath" -ArgumentList @("/loadinf=$sourcePath\$SETUP_INF_FILE", "/VERYSILENT", "/SUPPRESSMSGBOXES")
  return $p.ExitCode
}
