[CmdletBinding()]
param
(
	[Parameter(Position=0)][String]$MountPoint = "C",
	[switch]$ForceRestart
)
# --- Global Variables --- #

if (!(($MountPoint[0] -match '[a-zA-Z]') -and ($null -eq $MountPoint[1] -or $MountPoint[1] -eq ":")))
{
	Write-Output "Mountpoint of target drive must be a single letter (e.g. C or D)"
	Write-Error "Invalid value for MountPoint"
	exit 1
}

Write-Verbose "Mount point for encryption set to: $MountPoint"

$Hostname = HOSTNAME.EXE
$KeyPath = "\\rackstation\Operations\RecoveryKeys"
$CypherPath = "\\rackstation\Operations\RecoveryKeys\BL-Recovery-AES.key"

Write-Verbose "Target computer: $Hostname"
Write-Verbose "Recovery key path: $KeyPath"

$Cypher = (Get-Content $CypherPath)

# --- Functions --- #

function IsTpmReady
{
	$TpmStatus = Get-Tpm

	Write-Verbose ($TpmStatus | Out-String)
	return ($TpmStatus.TpmReady -and $TpmStatus.TpmEnabled -and $TpmStatus.TpmActivated -and $TpmStatus.TpmOwned)
}

function CreateRecoveryKey
{
	[CmdletBinding()]
    param([parameter(ValueFromRemainingArguments=$true)][String[]] $args)
		
	Add-BitLockerKeyProtector -MountPoint $MountPoint -RecoveryPasswordProtector | Out-Null
	$BitLockerStatus = Get-BitLockerVolume -MountPoint $MountPoint

	$KeyProtectorId = $BitLockerStatus.KeyProtector[1].KeyProtectorId
		
	$BitLockerStatus.KeyProtector[1].RecoveryPassword | ConvertTo-SecureString -AsPlainText -force | ConvertFrom-SecureString -key $Cypher | Out-File $KeyPath\$Hostname-$KeyProtectorId.txt -NoNewLine
	
}

#Currently uncalled - move to seperate script / Client Command
function GetRecoveryKey
{
	#Read encrypted key file and convert to SecureString
	$RecoveryKeySecStr = Get-Content $KeyPath\$Hostname-$KeyProtectorId.txt | ConvertTo-SecureString -key $Cypher
	
	#Output as plaintext
	[Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($RecoveryKeySecStr))
}


# --- Main Script START --- #

if ( !(IsTpmReady))
{
	Write-Error "No TPM detected: Aborting"
	exit 1
}

$BitLockerStatus = Get-BitLockerVolume -MountPoint $MountPoint
Write-Verbose ($BitLockerStatus | Out-String)

if ($BitLockerStatus.ProtectionStatus -eq "On")
{
	Write-Output $BitLockerStatus
	Write-Output "BitLocker already enabled on Volume $MountPoint"
	exit 0
}

if ($BitLockerStatus.VolumeStatus -eq "EncryptionInProgress")
{
	Write-Output $BitLockerStatus
	Write-Output "Encryption already in progress on Volume $MountPoint"
	exit 0
}

Enable-BitLocker -MountPoint $MountPoint -TpmProtector
Write-Output "Bitlocker Enabled"

try
{
	CreateRecoveryKey -ErrorAction Stop
}
catch
{
	Write-Verbose ($_ | Out-String)
	Write-Output "Error - {$_.Exception.Message}"
	Disable-Bitlocker -MountPoint $MountPoint
	Write-Output "Bitlocker Disabled"
	exit 1
}

Write-Output "Recovery key creation: success"

if ($ForceRestart)
{
	Write-Output "ForceRestart flag set. Restarting"
	Restart-Computer -force
	exit 0
}
else
{
	Write-Output "Done. Restart required"
	exit 0
}

