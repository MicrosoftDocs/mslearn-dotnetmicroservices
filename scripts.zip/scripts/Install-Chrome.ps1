$InstallerPath = "GoogleChromeStandaloneEnterprise64.msi"

$OnPostInstall = {
  param($sourcePath)

  #Chrome Extensions
  $chrome_reg_key = "HKEY_LOCAL_MACHINE\Software\Wow6432Node\Google\Chrome\Extensions"
  $ExtensionIDList = New-Object System.Collections.Generic.List[string]
  
  $ExtensionIDList.Add("oboonakemofpalcgghocfoadofidjkkk")	# KeePassXC
  $ExtensionIDList.Add("cjpalhdlnbpafiamejdnhcphjbkeiagm")	# uBlock Origin
  $ExtensionIDList.Add("pkehgijcmpdhfbdbbnkijodmdjhbjlgp")	# PrivacyBadger
  
  #Copy Master_Preferences (defaults for first startup)
  Copy-Item -Path "$sourcePath\master_preferences" -Destination "${env:ProgramFiles(x86)}\Google\Chrome\Application\master_preferences" -Force

  #Install Browser Extensions
  #Set Registry Keys...
  foreach ($id in $ExtensionIDList)
  {
    reg add "$chrome_reg_key\$id" /f /v update_url /d "https://clients2.google.com/service/update2/crx" /t REG_SZ
  }
  return 0
}


