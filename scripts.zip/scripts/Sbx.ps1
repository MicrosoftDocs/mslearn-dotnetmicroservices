function TestFunc {
  param(
    $TestParam
  )
  process {
    Write-Host "Arg: $TestParam"
  }
}

TestFunc -TestParam "ETRN"