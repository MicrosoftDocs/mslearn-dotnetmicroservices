if ($null -eq $Version)
{
  $version = "professional_2019.11.2"
}

$components =
  if ($Version.contains("2022"))
  {
    # https://docs.microsoft.com/en-us/visualstudio/install/workload-component-id-vs-professional?view=vs-2022
    @(
      "Microsoft.VisualStudio.Workload.ManagedDesktop;includeRecommended",
      "Microsoft.VisualStudio.Workload.NativeDesktop;includeRecommended",
      "Microsoft.VisualStudio.ComponentGroup.VC.Tools.142.x86.x64",
      "Microsoft.VisualStudio.Workload.NetWeb",
      "Microsoft.VisualStudio.Component.VC.Llvm.Clang",
      "Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset",
      "Microsoft.Net.Component.4.8.SDK",
      "Microsoft.Net.Component.4.8.TargetingPack"
    )
  }
  elseif ($Version.contains("2019"))
  {
    # https://docs.microsoft.com/en-us/visualstudio/install/workload-component-id-vs-professional?view=vs-2019
    @(
      "Microsoft.VisualStudio.Workload.ManagedDesktop;includeRecommended",
      "Microsoft.VisualStudio.Workload.NativeDesktop;includeRecommended",
      "Microsoft.VisualStudio.Component.Windows10SDK.10240",
      "Microsoft.VisualStudio.Component.Windows10SDK.17134",
      "Microsoft.VisualStudio.Component.VC.v141.x86.x64",
      "Microsoft.VisualStudio.Component.VC.v141.ATL",
      "Microsoft.VisualStudio.Component.VC.v141.MFC",
      "Microsoft.VisualStudio.Component.Windows81SDK",
      "Microsoft.VisualStudio.Workload.NetWeb",
      "Microsoft.VisualStudio.Component.VC.Llvm.Clang",
      "Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset",
      "Microsoft.Net.Component.4.8.SDK",
      "Microsoft.Net.Component.4.8.TargetingPack"
    )
  }
  else
  {
    @(
      "Microsoft.VisualStudio.Workload.ManagedDesktop;includeRecommended",
      "Microsoft.VisualStudio.Workload.NativeDesktop;includeRecommended",
      "Microsoft.VisualStudio.Component.Windows10SDK.10240",
      "Microsoft.VisualStudio.Component.Windows10SDK.17134",
      "Microsoft.VisualStudio.Component.VC.ATLMFC",
      "Microsoft.VisualStudio.Component.Windows81SDK",
      "Microsoft.VisualStudio.Workload.NetWeb"
    )
  }

$installerArgs = @("--noUpdateInstaller", "--quiet", "--wait", "--force", "--locale", "En-us", "--addProductLang", "En-us")
foreach ($component in $components)
{
  $installerArgs += @("--add", $component)
}

$AdditionalArgs = $installerArgs

if ($version.Contains("2019") -or $version.Contains("2022"))
{
  $OnInstall =
    {
      param($sourcePath, $version)

      $exitCode = (InstallFile -File $sourcePath -AdditionalArgs $additionalArgs)[-1]
      if ($exitCode -eq 1)
      {
        $current_additionalArgs = @("update") + $additionalArgs
        $exitCode = (InstallFile -File $sourcePath -AdditionalArgs $current_additionalArgs)[-1]
      }
      return $exitCode
    }
}

$OnPostInstall =
  {
    param($sourcePath, $version)

    if ($version.Contains("2019"))
    {
      & "$PSScriptRoot\Install.ps1" -Product "WixExtension" -Version "2019"
      return $LASTEXITCODE
    }
    elseif ($version.Contains("2022"))
    {
      & "$PSScriptRoot\Install.ps1" -Product "WixExtension" -Version "2022"
      & "$PSScriptRoot\Install.ps1" -Product "DotNetDevPack" -Version "4.5.2"
      return $LASTEXITCODE
    }
    return 0
  }


