$AllowedExitCodes = @(0, 1638) # 1638: another product version is already installed.
# $AdditionalArgs = @("/l*v", "C:\Enscape-PS-Logs\teams-logfile.txt")