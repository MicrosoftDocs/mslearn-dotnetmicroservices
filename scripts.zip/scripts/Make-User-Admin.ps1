param([String]$computer="", [String]$username="")


$LocalGrp = [ADSI]"WinNT://$computer/Administrators,group"
$DomainUser = [ADSI]"WinNT://local.enscape/$username,user"
$LocalGrp.Add($DomainUser.Path)
