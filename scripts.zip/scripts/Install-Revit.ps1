$InstallerPath = "Img\Setup.exe"
$AdditionalArgs = @("/t", "/w", "/q", "/I", "Img\Minimal.ini", "/Trial", "/language" ,"en-us")
