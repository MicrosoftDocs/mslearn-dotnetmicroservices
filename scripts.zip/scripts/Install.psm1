$DomainShare = "$PSScriptRoot\.."
$InstallerDir = [IO.Path]::Combine($DomainShare, "installer-sources")
$SupportedSourceTypes = @("", ".msi", ".exe")

$EnscapeRegKey = "HKLM:\Software\Enscape\Installed Software"

function Set-EnscapeSoftwareRegKey ($product, $version)
{
  $key = "$EnscapeRegKey"
  if(!(Test-Path $key)) {
    New-Item $key -Force
  }
  Set-ItemProperty -Path $key -Name $product -Value $version -Force
}

function Remove-EnscapeSoftwareRegKey ($product)
{
  $key = "$EnscapeRegKey"
  Remove-ItemProperty -Path $key -Name $product -ErrorAction SilentlyContinue
}

function Get-EnscapeSoftware($product)
{
  $key = "$EnscapeRegKey"
  if(!(Test-Path $key)){ return "" }
  $item = Get-ItemProperty -Path $key
  return $item.$product
}

# Searches sources and scripts directory for products
# Returns list of products
function Find-Products($product, $version)
{
  if ($product -match '\;')
  {
    $products0 = $product.split(";")
	$products = @()
	foreach ($product in $products0)
	{
	  $product = $product.Trim()
	  if (![string]::IsNullOrEmpty($product))
	  {
	    $moreProducts = Find-Products -Product $product -Version $version
		foreach ($product in $moreProducts)
		{
		  if (!$products.contains($product))
		  {
		    $products += $product
		  }
		}
	  }
	}
    return $products
  }
  if ($product -match '\*')
  {
    Write-Host "Searching for sources with name '$product' in '$InstallerDir' ..."
    $sources = Get-ChildItem -Path "$InstallerDir\$product" | Select-Object -ExpandProperty Name | Sort-Object
	$count = $sources.Count
	Write-Host "Found $count sources(s):"
	Write-Host "$sources"
    Write-Host "Searching for scripts with name 'Install-$product.ps1' in dir '$PSScriptRoot' ..."
    $scripts = Get-ChildItem -Path "$PSScriptRoot\Install-$product.ps1" | Select-Object -ExpandProperty Name | Sort-Object
	$count = $scripts.Count
	Write-Host "Found $count scripts(s):"
	Write-Host "$scripts"
	$products = @()
	foreach ($source in $sources)
	{
	  $product = $source.toLower()
	  if (!$products.contains($product))
	  {
	    $products += $product
	  }
	}
	foreach ($script in $scripts)
	{
	  $product = $script.substring(8,$script.length-8-4).toLower()
	  if (!$products.contains($product))
	  {
	    $products += $product
	  }
	}
	return $products
  }
  else
  {
    return @($product.toLower())
  }
}

# Finds installer sources by product name
# Returns filePath or $null
function Get-Source($dir, $sourceType = $null, $version = $null)
{
  Write-Host "Searching sources in '$dir' type='$sourceType' version='$version' ..."
  if ($null -eq $sourceType)
  {
    foreach ($sourceType in $SupportedSourceTypes)
    {
      $source = Get-Source -Dir $dir -SourceType $sourceType -Version $version
      if ($null -ne $source) { return $source }
    }
	return $null
  }
  if ($null -eq $version)
  {
    $sources = (Get-ChildItem -Path ([String]([IO.Path]::Combine($dir, "*$sourceType")))) | Sort-Object -Descending
    if ($null -ne $sources -and $sources.Count -gt 0) { return $sources[0] }
	return $null
  }
  $source = [IO.Path]::Combine($dir, "$version$sourceType")
  if (Test-Path -Path $source) { return $source }
  return $null
}

function Get-Version($source)
{
  $leaf = Split-Path -Path $source -Leaf
  return [io.path]::GetFileNameWithoutExtension($leaf)
}

function Get-TempDir($name)
{
  return [IO.Path]::Combine(${env:temp}, $name)
}

$CacheDirs = @()
function New-CacheSource($path)
{
  $leaf = Split-Path $path -leaf
  $cacheParent = Get-TempDir([System.IO.Path]::GetRandomFileName())
  $Script:CacheDirs += $cacheParent
  New-Item -Path $cacheParent -ItemType "directory" -Force
  $cachePath = [IO.Path]::Combine($cacheParent, $leaf)
  Write-Host "Caching source '$path' -> '$cachePath' ... "
  Copy-Item -Path $path -Destination $cacheParent -recurse -Force
  return $cachePath
}

function Remove-CacheSources()
{
  foreach ($dir in $Script:CacheDirs)
  {
    Write-Host "Removing cache '$dir' ..."
    Remove-Item -Path $dir -Force -Recurse
  }
  $Script:CacheDirs = @()
}

# executes an installer and returns its exit code
function InstallFile($file, $additionalArgs = @())
{
  Write-Host "Installing '$file' ..."
  $fileType = [IO.Path]::GetExtension($file)
  $args = @()
  if($fileType -eq ".msi")
  {
	$filePath = "msiexec"
	$args += @("/i", $file, "/qn", "ALLUSERS=1") + $additionalArgs
  }
  elseif($fileType -eq ".exe")
  {
    $filePath = $file
	$args += $additionalArgs
  }
  Write-Host "Running '$filePath' with args {$args}"
  if ($args.Count -gt 0)
  {
    $p = Start-Process -PassThru -Wait -FilePath $filePath -ArgumentList $args
  }
  else
  {
    $p = Start-Process -PassThru -Wait -FilePath $filePath
  }
  $exitCode = $p.ExitCode
  Write-Host "ExitCode: $exitCode"
  return $exitCode
}

# finds and caches installer files by product name, executes an installer and returns its exit code
function Install-Main($product, $productSource = $null, $version, $installerPath = $null, $additionalArgs = @(), $useCache = $true, $onPreInstall = $null, $onInstall = $null, $onPostInstall = $null, $allowedExitCodes = @(0), $cleanUpSourceFiles = $true, $force = $false)
{
  $hasError = 0
  $exitCode = 0
  if ($null -eq $productSource)
  {
    $productSource = [IO.Path]::Combine($InstallerDir, $product)
  }
  else
  {
    $productSource = [IO.Path]::Combine($InstallerDir, $productSource)
  }
  $versionSource = Get-Source -Dir $productSource -Version $version
  if ([string]::IsNullOrEmpty($versionSource))
  {
    Write-Error "No version source was found in '$productSource'."
	return 0
  }
  $source = $versionSource
  Write-Host "Using Source '$source'."
  $version = Get-Version $source
  Write-Host "Product Version is '$version'."
  if (!$force)
  {
    $installedVersion = Get-EnscapeSoftware $product
	Write-Host "Installed Product Version: '$installedVersion'"
	if ($installedVersion -eq $version)
	{
	  Write-Host "Installed Product Version matches version. Skipping installation ..."
	  return 0
	}
  }
  $stopwatchCache = [Diagnostics.Stopwatch]::StartNew()
  if ($useCache) { $source = (New-CacheSource -Path $source)[-1] }
  Write-Host "'$product' Cache time: $($stopwatchCache.Elapsed)."

  $stopwatchInstall = [Diagnostics.Stopwatch]::StartNew()

  $installerFile = $source
  if ($null -ne $installerPath)
  {
    $installerFile = [IO.Path]::Combine($source, $installerPath)
  }

  if ($null -ne $onPreInstall)
  {
    Write-Host "Executing PreInstall ..."
    $exitCode = (Invoke-Command -ScriptBlock $onPreInstall -ArgumentList @($source, $version))[-1]
	if (-not ($exitCode -in $allowedExitCodes)) {$hasError = 1}
	Write-Host "PreInstall returned $exitCode."
  }
  if ($null -ne $onInstall)
  {
    Write-Host "Executing Explicit Install ..."
    $exitCode = (Invoke-Command -ScriptBlock $onInstall -ArgumentList @($source, $version))[-1]
	if (-not ($exitCode -in $allowedExitCodes)) {$hasError = 1}
	Write-Host "Explicit Install returned $exitCode."
  }
  else
  {
    Write-Host "Executing Default Install ..."
    $exitCode = (InstallFile -File $installerFile -AdditionalArgs $additionalArgs)[-1]
	if (-not ($exitCode -in $allowedExitCodes)) {$hasError = 1}
	Write-Host "Default Install returned $exitCode."
  }
  if ($null -ne $onPostInstall)
  {
    Write-Host "Executing PostInstall ..."
    $exitCode = (Invoke-Command -ScriptBlock $onPostInstall -ArgumentList @($source, $version))[-1]
	if (-not ($exitCode -in $allowedExitCodes)) {$hasError = 1}
	Write-Host "PostInstall returned $exitCode."
  }

  Write-Host "'$product' Install time: $($stopwatchInstall.Elapsed)."

  if ($useCache -and $cleanUpSourceFiles) { Remove-CacheSources }
  if (!$hasError)
  {
    Set-EnscapeSoftwareRegKey $product $version
	return 0
  }
  else
  {
    if ($exitcode -ne 0)
    {
	  Write-Host "Install-Main will exit with Specific error code: $exitcode."
      return $exitcode
    }
    else
    {
	  Write-Host "Install-Main will exit with default exitcode 1."
      return 1
    }
  }
}
		
function Install($product, $version, $force)
{
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()

  #overridables
  $UseDefaultInstaller = $true
  $ProductSource = $null
  $InstallerPath = $null
  $AdditionalArgs = @()
  $UseCache = $true
  $OverrideExitCode = 1
  $OnPreInstall = $null
  $OnInstall = $null
  $OnPostInstall = $null
  $AllowedExitCodes = @(0)
  $CleanUpSourceFiles = $true

  $productScript = "$PSScriptRoot\Install-$product.ps1"
  if ([System.IO.File]::Exists($productScript))
  {
    Write-Host "product '$product': explicit script found '$productScript'. Executing ..."
    .$productScript
  }
  else
  {
    Write-Host "product '$product': no explicit script found."
  }

  if ($UseDefaultInstaller)
  {
    $exitCode = Install-Main -Product $product -ProductSource $ProductSource -Version $version -InstallerPath $installerPath -AdditionalArgs $AdditionalArgs -UseCache $UseCache -OnPreInstall $OnPreInstall -OnInstall $OnInstall -OnPostInstall $OnPostInstall -AllowedExitCodes $AllowedExitCodes -CleanUpSourceFiles $CleanUpSourceFiles -Force $force
  }
  else
  {
    $exitCode = $OverrideExitCode
  }

  Write-Host "'$product' Total time: $($stopwatch.Elapsed)."
  return $exitCode
}