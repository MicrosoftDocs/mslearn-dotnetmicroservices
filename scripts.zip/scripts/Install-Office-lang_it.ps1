$ProductSource = "Office"
$OnInstall = {
  param($sourcePath)
    $argumentList = @("/configure", "$sourcePath\Office365-x64-lang_it.xml")
    $p = Start-Process -PassThru -Wait -FilePath "$sourcePath\setup.exe" -ArgumentList $argumentList
	return $p.ExitCode
}

