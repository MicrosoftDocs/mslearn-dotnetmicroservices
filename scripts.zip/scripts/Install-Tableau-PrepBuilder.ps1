$AdditionalArgs = @("/quiet", "/norestart", "ACCEPTEULA=1", "AUTOUPDATE=1", "REMOVEINSTALLEDAPP=1")
