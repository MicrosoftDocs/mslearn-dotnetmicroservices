﻿param([Bool]$force=$false)

Import-Module "$PSScriptRoot\Log.psm1"
Import-Module "$PSScriptRoot\Install.psm1"

$DesiredAgentVersion = "2.206.1"
$ForceAgentUpdate = $force
$MinRes = @(1280, 1024)
$MinFreeSpaceGb = 150
$MinFreeSpaceGbRevit = 200
$MinFreeSpaceGbDiskCleanup = 150
$MinFreeSpacePercDiskCleanup = 30
$CleanUpObjects = @(
  (Join-Path -Path $Env:AppData -ChildPath "Enscape\Data\logs"),
  (Join-Path -Path $Env:USERPROFILE -ChildPath "Desktop"),
  (Join-Path -Path $Env:LocalAppData -ChildPath "NuGet\v3-cache")
)
$CleanUpDirect = @(
  "C:\hyperfil.sys"
)

$TfsUrl = "http://tfs.local.enscape/tfs"
$DesiredRevitVersion = "2020"
$DesiredVsVersions = @("professional_2019.11.2", "professional_2022.2.6")
$MinTotalMemoryGbForVs = 15
$DeploymentDateTime = "2022-12-22 14:14"
$DeploymentDateTimeCMake = "2022-12-04"
$DeploymentDateTimeAwsCli = "2023-01-16"

#Paths
$DomainSharePath = "$PSScriptRoot\.."
$AgentLocalPath = "tfs\Agent"
$LogFilePath = Join-Path -Path (Get-Item $env:AppData) -ChildPath "Run-Tfs-Agent.log"
$LogFilePathOld = Join-Path -Path (Get-Item $env:AppData) -ChildPath "Run-Tfs-Agent.old.log"
$NUnitTestAdapterPath = "$DomainSharePath\software\NUnit3TestAdapter"
$GitLfsExePath = "$DomainSharePath\software\git-lfs\git-lfs.exe"
$PythonPath = "$DomainSharePath\software\python-3.11.1-amd64"
$TokenLogonHandlerPath = "$DomainSharePath\tools\HandleTokenLogon.exe"
$AcmpPath = "\\win-serv-1\ACMP\Client\Launcher.exe"
$RootCertificatePath = "\\rackstation\home\root-certificate\ucs-root-ca.crt"

$Hostname = (Invoke-Expression -Command hostname).ToLower()
$AgentHostname = $Hostname
$AgentHostname -match 'a([0-9]+)'
$AgentNumber = [int]$Matches[1]

$RtxAgents = @(16,20,21,27,28)
$SlowAgents = @(24,14) # used in build pipelines
$IsSlowAgent = $AgentNumber -in $SlowAgents
$HwrtAgents = $RtxAgents + @(2,26)
$IsGraphicalReference = $AgentNumber -in @(2,27,28)
$IsEligibleForVs = $AgentNumber -lt 40
$IsEligibleForRevit =  -not ($hostname -like "*-vm-*")
$suppressGraphicsAdapter = $AgentNumber -in @(4, 19, 31)

# Agent specific DeploymentGroups
$DeploymentGroups = @(
  # Sample staged deployment group.
  # @{
  #   Agents = @(1, 3, 7, 9, 11, 12, 15, 20, 26, 27)
  #   Script = {
  #     $Script:DesiredAgentVersion = "2.206.1"
  #     $Script:DesiredVsVersions = @("professional_2022.2.6")
  #   }
  # }
  @{
    Agents = @(1, 3, 8, 7, 16, 25, 27, 31)
    Script = {
      $Script:DesiredVsVersions = @("professional_2022.5.1")
    }
  }
)

foreach ($Group in $DeploymentGroups) {
  if ($AgentNumber -in $Group.Agents) {
    Write-Host "Running on deployment test Agent"
    & $Group.Script
  }
}


######################################################################################################
######################################################################################################
######################################################################################################

# functions
function EnableAgent($s)
{
	Write-Host "Setting Agent '$Hostname' state to '$s' ..."
	Push-Location "$PSScriptRoot\agent-enable"
	& ".\agent-enable.exe" -p 1 -n $hostname -s $s
	Pop-Location
}

function DeleteOldItems($path, $days)
{
	Write-Host "Cleaning up $path ..."
	$totalsize = 0
	$items = ( Get-ChildItem -Path $path -Recurse | Where-Object {($_.LastWriteTime -lt (Get-Date).AddDays(-$days))})
	foreach ($item in $items)
	{
		$totalsize += $item.length
		$itemPath = Join-Path -Path $path -ChildPath $item
		if (Test-Path $itemPath)
		{
		  Remove-Item $itemPath  -Recurse -Force
		}
	}
	Write-Host "Cleanup of $path yielded"($totalsize/1GB)"GB."
}

function Get-TimeStamp
{
   return "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
}

function SetEnvironmentVariable($envKey, $envValue)
{
  Write-Host "SetEnvironmentVariable: $envKey -> $envValue"
  [Environment]::SetEnvironmentVariable($envKey, $envValue)
  [Environment]::SetEnvironmentVariable($envKey, $envValue, "Machine")
}

function AddToEnvironmentVariable($envKey, $envValue)
{
  Write-Host "AddToEnvironmentVariable: $envKey -> $envValue"
  $current = [Environment]::GetEnvironmentVariable($envKey)
  if (-not $current.tolower().contains($envValue))
  {
    [Environment]::SetEnvironmentVariable($envKey, $current+$envValue)
  }
  else
  {
	  Write-Host "Already contained: $envValue in $current"
  }
  $currentMachine = [Environment]::GetEnvironmentVariable($envKey, "Machine")
  if (-not $currentMachine.tolower().contains($envValue))
  {
    [Environment]::SetEnvironmentVariable($envKey, $currentMachine+$envValue, "Machine")
  }
  else
  {
	  Write-Host "Already contained: $envValue in $currentMachine"
  }
}

function GetLocalDrives
{
  return Get-WmiObject Win32_LogicalDisk -Filter drivetype=3
}

function GetDriveFreeSpace($driveId)
{
  return (Get-WmiObject Win32_LogicalDisk -Filter drivetype=3 | Where-Object { $_.DeviceID -eq $driveId}).FreeSpace / 1024 / 1024 / 1024
}

function SetCad
{
  $gName = wmic path win32_VideoController get name
  if ($gName -match "quadro")
  {
    SetEnvironmentVariable "IsCad" "1"
  }
  elseif ($gName -match "firepro")
  {
    SetEnvironmentVariable "IsCad" "1"
  }
  else
  {
    SetEnvironmentVariable "IsCad" "0"
  }
}

function InstallDotNet35
{
  $dn35_product = "DotNet35"
  $installed = Get-EnscapeSoftware $dn35_product
  if (-not [string]::IsNullOrEmpty($installed) -and -not $force)
  {
    Write-Host "Not installing $dn35_product. If this is undesired, use force."
  }
  else
  {
    Write-Host "InstallDotNet35 ..."
    DISM /Online /Enable-Feature /FeatureName:NetFx3 /All
  }
  Set-EnscapeSoftwareRegKey $dn35_product "1"
}

function FindLocalDriveWithAtLeastBytes($minBytes)
{
  Write-Host "FindLocalDriveWithAtLeastBytes: $minBytes ... "
  $disks = GetLocalDrives
  $maxFreeSpace = 0
  $selectedDisk = $null
  foreach($disk in $disks)
  {
    Write-Host "Checking disk: ... $disk ..."
    if ($disk.FreeSpace -gt $maxFreeSpace -and $disk.FreeSpace -ge $minBytes)
    {
      $maxFreeSpace = $disk.FreeSpace
      $selectedDisk = $disk
    }
  }
  Write-Host "Yielding $selectedDisk ..."
  return $selectedDisk
}

function FindDriveWithSpecialFile($specialFile)
{
  Write-Host "FindSpecialFileOnDrive: $specialFile ... "
  $disks = GetLocalDrives
  foreach($disk in $disks)
  {
	$path = Join-Path -Path $disk.DeviceID -ChildPath $specialFile
	if (Test-Path -Path $path)
	{
		Write-Host "Special file found in $path. Yielding this drive..."
		return $disk.DeviceID
	}
  }
  Write-Host "Yielding NULL ..."
  return $null
}

function FindDirectoryOnDrives($dirPath)
{
  Write-Host "FindDirectoryOnDrives: $dirPath ... "
  if (!$dirPath) { return $null }
  $disks = GetLocalDrives
  foreach($disk in $disks)
  {
    Write-Host "Checking disk: ... $disk ..."
    $path = Join-Path -Path $disk.DeviceID -ChildPath $dirPath
    if(Test-Path -Path $path)
    {
      Write-Host "Yielding $path ..."
      return $path
    }
  }
  Write-Host "Yielding NULL ..."
  return $null
}

function FindDiskForDirectoryOnDrives($dirPath)
{
  Write-Host "FindDirectoryOnDrives: $dirPath ... "
  if (!$dirPath) { return $null }
  $disks = GetLocalDrives
  foreach($disk in $disks)
  {
    Write-Host "Checking disk: ... $disk ..."
    $path = Join-Path -Path $disk.DeviceID -ChildPath $dirPath
    if(Test-Path -Path $path)
    {
      Write-Host "Yielding $disk ..."
      return $disk
    }
  }
  Write-Host "Yielding NULL ..."
  return $null
}

function DownloadAgentZip($dir)
{
  Write-Host DownloadAgentZip $dir ...
  $agentUrl = "$DomainSharePath\software\agent-installer\vsts-agent-win-x64-$DesiredAgentVersion.zip"
  $outFileName = Split-Path -Path $agentUrl -Leaf
  $outFilePath = Join-Path -Path $dir -ChildPath $outFileName
  Invoke-WebRequest -Uri $agentUrl -OutFile $outFilePath
  return $outFilePath
}

function ConfigureAgent($dir)
{
  Write-Host "ConfigureAgent: $dir ... "
  $run = Join-Path -Path $dir -ChildPath "config.cmd"
  & $run --unattended --url $TfsUrl --replace --auth integrated
}

function GetAgentVersion($dir)
{
  $run = Join-Path -Path $dir -ChildPath "config.cmd"
  if (Test-Path -path $run)
  {
    $agentVersion = & $run --version
    $agentVersion = $agentVersion.Trim()
    Write-Host "Installed Agent Version: $agentVersion $dir"
    $agentVersion
  }
}

function InstallNUnitTestAdapter($dir)
{
  Write-Host "Installing: NUnitTestAdapter $dir ..."
  Copy-Item $NUnitTestAdapterPath -Destination $dir -Recurse
}

function InstallGitLfs($dir)
{
  $lfsDir = [IO.Path]::Combine($dir, "externals", "git", "cmd")
  New-Item -ItemType "directory" -Path $lfsDir
  Write-Host "Installing: GitLFS: $GitLfsExePath -> $lfsDir ..."
  Copy-Item $GitLfsExePath -Destination $lfsDir
}

function InstallGitRootCert($dir)
{
  $gitDir = [IO.Path]::Combine($dir, "externals", "git", "cmd")
  Write-Host "Installing: GitRootCert: $gitDir ..."
  Push-Location $gitDir
  & .\git config --global http.sslCAInfo $RootCertificatePath
  Pop-Location
}

function CheckDotNetCore()
{
  & dotnet -h | Out-Null
  return $?
}

function InstallDotNetCore()
{
  $deploymentKey = "DotNetCoreDeployment"
  if (HasDeployment $deploymentKey $DeploymentDateTime) { return }
  & "$PSScriptRoot\Install.ps1" -Product "DotNetCoreSdk"
  $result = CheckDotNetCore
  if (!$result)
  {
    Write-Host "DotNetCore not in scope after installation. Restart required ..."
    $Global:RequireRestart = $true
    return
  }
  SetEnvironmentVariable "DotNetCore" "1"
  SetDeployment $deploymentKey $DeploymentDateTime
}

function CheckPython()
{
  & pip freeze | Out-Null
  return $?
}

function InstallPython()
{
  $deploymentKey = "PythonDeployment"
  if (HasDeployment $deploymentKey $DeploymentDateTime) { return }
  Write-Host "Checking: Python ..."
  & $PythonPath PrependPath=1 /silent | Out-Null
  $result = CheckPython
  if (!$result)
  {
    Write-Host "Python not in scope after installation. Restart required ..."
    $Global:RequireRestart = $true
    return
  }
  SetDeployment $deploymentKey $DeploymentDateTime
}

function InstallJDK()
{
  $deploymentKey = "JDKDeployment"
  if (HasDeployment $deploymentKey $DeploymentDateTime) { return }
  choco install javaruntime -y
  choco install openjdk -y
  choco install jdk11 -y
  SetEnvironmentVariable "HasJDK" "1"
  SetEnvironmentVariable "java" "1"
  SetEnvironmentVariable "jdk" "1"
  refreshenv
  & java -version
  if(!$?)
  {
	Write-Host "Java not in scope. Restart required ..."
	$Global:RequireRestart = $true
  }
  else
  {
    SetDeployment $deploymentKey $DeploymentDateTime
  }
}

function IsSoftwareInstalled($software)
{
  $installed = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -match $software }) -ne $null

  If(-Not $installed)
  {
    Write-Host "'$software' is NOT installed.";
  }
  else
  {
    Write-Host "'$software' is installed."
  }
  return $installed
}

function InstallRevit($version)
{
  $installed = IsSoftwareInstalled "revit $version"
  If(-Not $installed)
  {
     if ($IsElligibleForRevit)
     {
	   $FreeSpaceGB = GetDriveFreeSpace "C:"
	   if ($FreeSpaceGB -gt $MinFreeSpaceGbRevit)
	   {
		 Write-Host "Enough Space for Revit."
		 & "$PSScriptRoot\Install.ps1" -Product "Revit" -Version $version
		 SetEnvironmentVariable "HasRevit" "1"
	   }
	   else
	   {
		 Write-Host "NOT enough Space for Revit."
		 SetEnvironmentVariable "HasRevit" "0"
	   }
     }
     else
     {
       SetEnvironmentVariable "HasRevit" "0"
     }
  }
  else
  {
    SetEnvironmentVariable "HasRevit" "1"
  }
}

function InstallAws()
{
  if (HasDeployment $deploymentKey $DeploymentDateTimeAwsCli) { return }
  Write-Host "Installing: AWS ..."
  python -m pip install --upgrade pip
  pip install awscli
  pip install aws-sam-cli

  echo "Warning: Sandbox only"
  aws configure set aws_secret_access_key JqH3Yr4JLgwsFJbzBFb0QHmorThWzZ4CpdRZ98Vp --profile WebStandaloneDeploySandbox
  aws configure set aws_access_key_id AKIAJHAOGTYPSNRXTBRQ --profile WebStandaloneDeploySandbox
  aws configure set region eu-central-1 --profile WebStandaloneDeploySandbox
  if (!$?)
  {
	Write-Host "Error installing awscli. Restart required ..."
	$Global:RequireRestart = $true
	return
  }
  SetEnvironmentVariable "AwsCli" "1"
  SetDeployment $deploymentKey $DeploymentDateTimeAwsCli
}

function SetAgentAutoLogon()
{
  Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "AutoAdminLogon" -Value "1"
  Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "DefaultDomainName" -Value "local.enscape"
  Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "DefaultUserName" -Value "agent"
}

function SetAgentNumber()
{
  Write-Host "SetAgentNumber: $AgentNumber"
  SetEnvironmentVariable "Agent.Number" $AgentNumber
}

function IsElligibleForVS()
{
  $totalMemoryGB = (Get-CIMInstance Win32_OperatingSystem).TotalVisibleMemorySize/1024/1024
  Write-Host "totalMemoryGB: $totalMemoryGB, minimum total memory for VS: $MinTotalMemoryGbForVs gb"
  if ($totalMemoryGB -lt $MinTotalMemoryGbForVs) { return $false }
  if ($IsEligibleForVs)
  {
    Write-Host "$hostname is eligible for VS."
  }
  else
  {
    Write-Host "$hostname is NOT eligible for VS."
  }
  return $IsEligibleForVs
}

function ProbeGpuType($gpuTypeProbed, $actualGpuType)
{
  $gpuKey = "Gpu"
  $matchExpr = "-" + $gpuTypeProbed
  if ($hostname -match $matchExpr)
  {
    Write-Host "Detected gputype: $actualGpuType"
    SetEnvironmentVariable $gpuKey $actualGpuType
    return $true
  }
  return $false
}

function InstallNvidiaDrivers()
{
  Write-Host "Installing nvidia drivers ..."
  $tempdir = [System.IO.Path]::GetTempPath()
  Push-Location $TempDir
  if ( $AgentNumber -in @(27,28) )
  {
    & choco install --version 512.95 nvidia-display-driver -y --allow-downgrade --params "/DCH"
  }
  else
  {
    & choco upgrade nvidia-display-driver -y --params "/DCH"
  }
  Pop-Location
  Write-Host "Installing nvidia drivers: done."
}

function ChocoLocalVersionOf($package)
{
  $cmd = choco list --local-only --exact $package
  foreach ($line in $cmd)
  {
    if ($line.StartsWith($package)) { return $line.Substring($package.Length+1) }
  }
}

function ChocoRemoteVersionOf($package)
{
  $cmd = choco list --exact $package
  foreach ($line in $cmd)
  {
    if ($line.StartsWith($package)) { return $line.Substring($package.Length+1).Split(" ")[0] }
  }
}

function ChocoRemoteVersionExists($package, $version)
{
  $cmd = choco list --exact $package --version $version
  foreach ($line in $cmd)
  {
    if ($line.StartsWith("1 packages found.")) { return $True }
  }
  return $False
}

function VersionGetMajor($version)
{
  return $version.Split(".")[0]
}

function VersionIsGreaterThan($v1, $v2)
{
  return ($v1 -as [int] -gt $v2 -as [int])
}

function VersionGetSmallest($v1, $v2)
{
  If (VersionIsGreaterThan $v2 $v1) { return $v1} Else { return $v2}
}

function VersionGetLargest($v1, $v2)
{
  If (VersionIsGreaterThan $v1 $v2) { return $v1} Else { return $v2}
}

function InstallChrome()
{
  $localGoogleChromeVersion = ChocoLocalVersionOf "GoogleChrome"
  $localChromeDriverVersion = ChocoLocalVersionOf "chromedriver"
  $localGoogleChromeVersionMajor = VersionGetMajor $localGoogleChromeVersion
  $localChromeDriverVersionMajor = VersionGetMajor $localChromeDriverVersion
  $localLatestMajor = VersionGetLargest $localGoogleChromeVersionMajor $localChromeDriverVersionMajor
  $localSmallestMajor = VersionGetSmallest $localGoogleChromeVersionMajor $localChromeDriverVersionMajor

  $remoteGoogleChromeVersion = ChocoRemoteVersionOf "GoogleChrome"
  $remoteChromeDriverVersion = ChocoRemoteVersionOf "chromedriver"
  $remoteGoogleChromeVersionMajor = VersionGetMajor $remoteGoogleChromeVersion
  $remoteChromeDriverVersionMajor = VersionGetMajor $remoteChromeDriverVersion
  $remoteLatestMajor = VersionGetLargest $remoteGoogleChromeVersionMajor $remoteChromeDriverVersionMajor
  $remoteSmallestMajor = VersionGetSmallest $remoteGoogleChromeVersionMajor $remoteChromeDriverVersionMajor

  Write-Host "localGoogleChromeVersion: '$localGoogleChromeVersion'"
  Write-Host "localChromeDriverVersion: '$localChromeDriverVersion'"
  Write-Host "localGoogleChromeVersionMajor: '$localGoogleChromeVersionMajor'"
  Write-Host "localChromeDriverVersionMajor: '$localChromeDriverVersionMajor'"
  Write-Host "localLatestMajor: '$localLatestMajor'"
  Write-Host "localLatestMajor: '$localLatestMajor'"

  Write-Host "remoteGoogleChromeVersion: '$remoteGoogleChromeVersion'"
  Write-Host "remoteChromeDriverVersion: '$remoteChromeDriverVersion'"
  Write-Host "remoteGoogleChromeVersionMajor: '$remoteGoogleChromeVersionMajor'"
  Write-Host "remoteChromeDriverVersionMajor: '$remoteChromeDriverVersionMajor'"
  Write-Host "remoteSmallestMajor: '$remoteSmallestMajor'"
  Write-Host "remoteLatestMajor: '$remoteLatestMajor'"

  if ([string]::IsNullOrEmpty($localGoogleChromeVersionMajor))
  {
	  Write-Host "localGoogleChromeVersionMajor is ''. Installing ..."
	  & choco upgrade GoogleChrome --version $remoteGoogleChromeVersion -y
  }

  if ([string]::IsNullOrEmpty($localChromeDriverVersionMajor))
  {
	  Write-Host "localChromeDriverVersionMajor is ''. Installing ..."
	  & choco upgrade chromedriver --version $remoteChromeDriverVersion -y
  }

  if ($remoteGoogleChromeVersionMajor -ne $remoteChromeDriverVersionMajor)
  {
    Write-Host "Remote remoteGoogleChromeVersionMajor ($remoteGoogleChromeVersionMajor) is different from remoteChromeDriverVersionMajor ($remoteChromeDriverVersionMajor). Cannot upgrade."
    return
  }

  if (VersionIsGreaterThan $localLatestMajor $remoteLatestMajor)
  {
    Write-Host "Local major version ($localLatestMajor) is greater than remote major version ($remoteLatestMajor). Cannot upgrade."
    return
  }

  Write-Host "Upgrading chromedriver to version $remoteChromeDriverVersion ..."
  & choco upgrade chromedriver --version $remoteChromeDriverVersion -y
  Write-Host "Done."
  Write-Host "Upgrading GoogleChrome to version $remoteGoogleChromeVersion ..."
  & choco upgrade GoogleChrome --version $remoteGoogleChromeVersion -y
  Write-Host "Done."
}

function InstallGeckoDrivers()
{
  Write-Host "Installing gecko drivers ..."
  $tempdir = [System.IO.Path]::GetTempPath()
  Push-Location $TempDir
  & choco upgrade selenium-gecko-driver -y
  Pop-Location
  Write-Host "Installing gecko drivers: done."
}

function PrepareGpu()
{
  if ($suppressGraphicsAdapter)
  {
    SetEnvironmentVariable "gpu" $null
    Write-Host "Agent Gpu is ignored."
    return
  }
  Write-Host "Probing Gpu types ..."
  if (ProbeGpuType "nv" "nvidia")
  {
    InstallNvidiaDrivers
  }
  ProbeGpuType "amd" "amd"
  ProbeGpuType "int" "intel"
}

function IsSignDonglePresent()
{
  $ret = $false
  if ((gwmi Win32_USBControllerDevice).__PATH -match "VID_0529&PID_0620")
  {
    $ret = $true
  }
  return $ret
}

function SetSignDongle()
{
  if (IsSignDonglePresent)
  {
    Write-Host "Sign Dongle detected."
    SetEnvironmentVariable "HasCryptoDongle" "1"
  }
  else
  {
    Write-Host "Sign Dongle NOT detected."
    SetEnvironmentVariable "HasCryptoDongle" "0"
  }
}

function SetMachineType()
{
  if ($hostname -match "-mobile-")
  {
    SetEnvironmentVariable "MachineType" "mobile"
  }
  elseif ($hostname -match "-vm-")
  {
    SetEnvironmentVariable "MachineType" "vm"
  }
  else
  {
    SetEnvironmentVariable "MachineType" "desktop"
  }
}

function SetIsSteamVR()
{
  if ( $AgentNumber -in @(21,24,25) )
  {
  Write-Host "Agent $AgentNumber : SteamVR=1"
    SetEnvironmentVariable "SteamVR" "1"
  }
}

function SetIsHWRT_RTX()
{
  if ($RtxAgents.Contains($AgentNumber))
  {
	Write-Host "Agent $AgentNumber : IsRtx=1"
    SetEnvironmentVariable "IsRtx" "1"
  }
  else
  {
	Write-Host "Agent $AgentNumber : IsRtx=0"
    SetEnvironmentVariable "IsRtx" "0"
  }
  if ($HwrtAgents.Contains($AgentNumber))
  {
	Write-Host "Agent $AgentNumber : IsHWRT=1"
    SetEnvironmentVariable "IsHWRT" "1"
  }
  else
  {
	Write-Host "Agent $AgentNumber : IsHWRT=0"
    SetEnvironmentVariable "IsHWRT" "0"
  }
}

function SetGraphicalReference()
{
  if ($IsGraphicalReference)
  {
    SetEnvironmentVariable "GraphicalReference" "1"
  }
  else
  {
    SetEnvironmentVariable "GraphicalReference" "0"
  }
}

function SetSlowAgent()
{
  if ($IsSlowAgent)
  {
    SetEnvironmentVariable "IsSlowAgent" "1"
  }
  else
  {
    SetEnvironmentVariable "IsSlowAgent" "0"
  }
}

function InstallAmazonLambdaTools()
{
  $deploymentKey = "AmazonLambdaDeployment"
  if (HasDeployment $deploymentKey $DeploymentDateTime) { return }
  $toolList = dotnet tool list -g

  $isInstalled = $toolList.Where({$_.Contains('amazon.lambda.tools')}).Count -gt 0

  if ($isInstalled)
  {
    dotnet tool update -g Amazon.Lambda.Tools
  }
  else
  {
    dotnet tool install -g Amazon.Lambda.Tools
  }
  dotnet lambda help
  if ($?)
  {
    Write-Host "Dotnet lambda is installed."
	SetDeployment $deploymentKey $DeploymentDateTime
  }
  else
  {
    Write-Host "Dotnet lambda is NOT installed. Restart required."
    $Global:RequireRestart = $true
  }
}

function InstallACMP()
{
  & $AcmpPath
}

function InstallCMake()
{
  $deploymentKey = "CMakeDeployment"
  if (HasDeployment $deploymentKey $DeploymentDateTimeCMake) { return }
  & choco uninstall cmake -y
  & choco uninstall cmake.install -y
  & choco uninstall cmake -y
  # & choco install cmake --installargs 'ADD_CMAKE_TO_PATH=System' --force -y
  & "$PSScriptRoot\Install.ps1" -Product "cmake" -Version "3.25.0"
  #Write-Host "cmake is NOT installed. Restart required."
  $Global:RequireRestart = $true
  SetDeployment $deploymentKey $DeploymentDateTimeCMake
}

function InstallVulkanSDK()
{
  $defaultVersion = "1.3.204.1"
  & "$PSScriptRoot\Install.ps1" -Product "Vulkan-Sdk" -Version $defaultVersion
}

function InstallChoco()
{
  & "$PSScriptRoot\Install.ps1" -Product "Choco"
}

function EnforceMinimumResolution($MinRes)
{
  $res = & "$PSScriptRoot\Get-Resolution.ps1"
  echo "Current resolution is $res. Minimum Resolution is $MinRes."
  if ( ([Int]$res[0] -lt [Int]$MinRes[0]) -or ([Int]$res[1] -lt [Int]$MinRes[1]) )
  {
    echo "Current resolution is too low. Setting to $MinRes."
    & "$PSScriptRoot\Set-Resolution.ps1" -x $MinRes[0] -y $MinRes[1]
  }
}

function InstallSVN()
{
  & choco install svn -y
  svn --version
  if ($?)
  {
    Write-Host "svn is installed."
  }
  else
  {
    $Global:RequireRestart = $true
  }
}

function HasDeployment($key, $desiredValue)
{
  $actualValue = Get-EnscapeSoftware $key
  Write-Host "deployment key='$key' desiredValue='$desiredValue' actualValue='$actualValue'"
  if ($actualValue -eq $desiredValue)
  {
	Write-Host "deployment is matching."
	return $true
  }
  Write-Host "deployment missing."
  return $false
}

function SetDeployment($key, $desiredValue)
{
	Set-EnscapeSoftwareRegKey $key $desiredValue
}

function DeployGgpKey()
{
  $dst = "C:\tools\key_gpp_service_account.pub"
  if (!(Test-Path -path $dst)) {Copy-Item "$DomainSharePath\scripts\agents\key_gpp_service_account.pub" $dst -Recurse -Force}
  SetEnvironmentVariable GGP_CI_KEY $dst
  SetEnvironmentVariable GGP_SDK_PATH "C:\Program Files\GGP SDK\"
}

function EnsurePrerequisites()
{
  EnableAgent 1
  
  & "$PSScriptRoot\Install.ps1" -Product "RemoveStadia"
  
  DeployGgpKey
  Set-Service -Name sshd -startupType automatic -status running
  EnforceMinimumResolution $MinRes
  
  PrepareGpu
  SetAgentNumber
  SetSignDongle
  SetMachineType
  SetCad
  SetIsHWRT_RTX
  SetGraphicalReference
  SetSlowAgent
  SetIsSteamVR
  
  InstallACMP
  InstallChoco
  & "$PSScriptRoot\Install.ps1" -Product "DotNetSdk"
  & "$PSScriptRoot\Install.ps1" -Product "Uvnc"
  & "$PSScriptRoot\Install.ps1" -Product "RustDesk"
  & "$PSScriptRoot\Install.ps1" -Product "Git"
  & "$PSScriptRoot\Install.ps1" -Product "VcRedist"
  & "$PSScriptRoot\Install.ps1" -Product "VcRedist2010"
  & "$PSScriptRoot\Install.ps1" -Product "OpenSSH-Server"
  & "$PSScriptRoot\Install.ps1" -Product "TreeSize"
  & "$PSScriptRoot\Install.ps1" -Product "Pwsh" -version "7.3.3"
  & "$PSScriptRoot\Add-icinga-agent.ps1" -Force

  InstallDotNet35
  InstallDotNetCore
  InstallPython
  InstallJDK
  InstallAws
  InstallRevit $DesiredRevitVersion
  if (IsElligibleForVS)
  {
    & "$PSScriptRoot\Uninstall-VisualStudio-Except.ps1" -versions $DesiredVsVersions
    foreach ($DesiredVsVersion in $DesiredVsVersions)
    {
      & "$PSScriptRoot\Install.ps1" -Product "VisualStudio" -version $DesiredVsVersion
    }
    & "$PSScriptRoot\Install.ps1" -Product "WixToolset" -Version "311" # Remove sfxca.dll workaround when upgrading to newer version
  }
  else
  {
    & "$PSScriptRoot\Uninstall-VisualStudio-Except.ps1" -versions @()
  }
  & "$PSScriptRoot\Install.ps1" -Product "VS-Code"
  InstallAmazonLambdaTools
  InstallVulkanSDK
  InstallChrome
  InstallGeckoDrivers
  InstallCMake
  InstallSVN
}

function InstallAgent($dir)
{
  Write-Host "InstallAgent: $dir ..."
  New-Item $dir -ItemType Directory
  InstallGitLfs($dir)
  InstallNUnitTestAdapter($dir)
  $agentZip = DownloadAgentZip($dir)
  Write-Host "Add-Type -AssemblyName System.IO.Compression.FileSystem ... "
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  Write-Host "[System.IO.Compression.ZipFile]ExtractToDirectory($agentZip, $dir) ..."
  [System.IO.Compression.ZipFile]::ExtractToDirectory($agentZip, $dir)
  ConfigureAgent($dir)
  InstallGitRootCert($dir)
}

function CleanUp()
{
  Write-Host "Clean-up ..."
  powercfg -h off
  vssadmin delete shadows /all /quiet
  foreach ($i in $CleanUpObjects) {
	  DeleteOldItems $i 2
  }
  foreach ($i in $CleanUpDirect) {
	  Write-Host "Removing item $i ..."
	  if (Test-Path  $i) 
	  {
	    Remove-Item $i -Force
	  }
  }
  
  $disk = FindDiskForDirectoryOnDrives($AgentLocalPath)
  if ($disk)
  {
    $freeSpaceGB = $disk.FreeSpace/1024/1024/1024
    $SizeGB = $disk.Size/1024/1024/1024
    $freePerc = $freeSpaceGB / $SizeGB * 100
    Write-Host "CleanUp: free space on $disk.DeviceID: $freeSpaceGB GB"
    Write-Host "CleanUp: size of $disk.DeviceID: $SizeGB GB"
    Write-Host "CleanUp: freePerc of $disk.DeviceID: $freePerc %"
    Write-Host "CleanUp: clean up threshold is $MinFreeSpaceGbDiskCleanup GB AND $MinFreeSpacePercDiskCleanup %"
    if (($freeSpaceGB -lt $MinFreeSpaceGbDiskCleanup) -or ($freePerc -lt $MinFreeSpacePercDiskCleanup))
    {
      Write-Host "CleanUp: Cleaning up..."
      Write-Host "CleanUp: Cleaning up TFS Dir"
      $agentLocalPathDyn = FindDirectoryOnDrives($AgentLocalPath)
      Write-Host agentLocalPath $agentLocalPathDyn
      if ($agentLocalPathDyn)
      {
        Remove-Item $agentLocalPathDyn -Force -Recurse
        $agentLocalPathDyn = $null
      }
      Write-Host "CleanUp: .nuget dir..."
      $nugetDir = [IO.Path]::Combine($env:userprofile, ".nuget", "packages")
      Get-ChildItem -Directory $nugetDir | ForEach-Object { Remove-Item "$($_.FullName)" -Recurse }
      $freeSpaceGB = $disk.FreeSpace/1024/1024/1024
      Write-Host "CleanUp: free space on $disk.DeviceID is now $freeSpaceGB GB."
    }
    else
    {
      Write-Host "CleanUp: disk is fine."
    }
  }
  else
  {
    Write-Host "CleanUp: no disk."
  }
}

function RunTokenLogonHandler()
{
  $exename = Split-Path $TokenLogonHandlerPath -leaf
  $fullLocalExe = Join-Path -Path "C:\TokenLogonHandlerPath" -ChildPath $exename
  if (-not (Test-Path -Path $fullLocalExe))
  {
    New-Item -Path "c:\" -Name "TokenLogonHandlerPath" -ItemType "directory"
    Copy-Item $TokenLogonHandlerPath -Destination "C:\TokenLogonHandlerPath"
  }
  & $fullLocalExe
}

function FindPreferredPathForTfsAgent($agentPath)
{
  # Assuming no agent path exists we use the flagged drive or the one with the most amount of space.

  $specialDrive = FindDriveWithSpecialFile("tfs-drive")
	if ($null -ne $specialDrive)
	{
		$path = Join-Path -Path $specialDrive -ChildPath $agentPath
		Write-Host "agent will be installed to special disk $path"
		return $path
	}

  $suitableDisk = FindLocalDriveWithAtLeastBytes($MinFreeSpaceGb * 1GB)
  Write-Host suitableDisk $suitableDisk
  if (!$suitableDisk)
  {
    Write-Warning "Could not find a disk large enough to meet requirements ($MinFreeSpaceGb GB)"
    Write-Warning "Trying to find a smaller disk ..."
    $suitableDisk = FindLocalDriveWithAtLeastBytes(1GB)
    Write-Host suitableDisk $suitableDisk
    if (!$suitableDisk)
    {
      Write-Error "Could not find a suitable drive to install agent."
      exit 1
    }
  }
  return Join-Path -Path $suitableDisk.DeviceId -ChildPath $agentPath
}

function RemoveOutdatedTfsAgent($agentPath)
{
  if ($agentPath -and (Test-Path -Path $agentPath))
  {
    $InstalledAgentVersion = GetAgentVersion($agentPath)
    if ($ForceAgentUpdate -or $InstalledAgentVersion -ne $DesiredAgentVersion)
    {
      Remove-Item $agentPath -Force -Recurse
    }
  }
}

######################################################################################################
######################################################################################################
######################################################################################################

# main
Write-Host "$(Get-TimeStamp): Starting up ..."
$RequireRestart = $false
Import-Certificate -FilePath $RootCertificatePath -CertStoreLocation 'Cert:\LocalMachine\Root'
CleanUp
SetAgentAutoLogon
EnsurePrerequisites
RunTokenLogonHandler

$loop = {

$existingAgentPath = FindDirectoryOnDrives($AgentLocalPath)
RemoveOutdatedTfsAgent($existingAgentPath)

if ($existingAgentPath -and (Test-Path -Path $existingAgentPath))
{
  $agentLocalPathDyn = $existingAgentPath
}
else
{
  $agentLocalPathDyn = FindPreferredPathForTfsAgent($AgentLocalPath)
  InstallAgent($agentLocalPathDyn)
}

if ($Global:RequireRestart)
{
  Write-Host "Restart is required. Restarting ..."
  Restart-Computer
  exit 0
}

$runCmd = Join-Path -Path $agentLocalPathDyn -ChildPath "run.cmd"
Write-Host "running $runCmd"
$result = Invoke-Expression -Command $runCmd
if ($result -ne 0)
{
  Write-Host "running $runCmd returned non-zero. Reinstalling TFS ..."
  Remove-Item $agentLocalPathDyn -Force -Recurse
}
else
{
  Write-Host "running $runCmd returned zero."
}
Start-Sleep -Seconds 10
&$loop

}

&$loop

Stop-Transcript