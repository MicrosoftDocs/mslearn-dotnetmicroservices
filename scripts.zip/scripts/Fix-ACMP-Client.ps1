param([switch]$Install = $true, [switch]$Uninstall = $true, [switch]$ComputerScannerFix = $false)

Import-Module "$PSScriptRoot\Log.psm1"

function RunComputerScannerFix
{
  Write-Host "Running ACMP ComputerScannerFix ..."
  $registryPath32 = "HKLM:\SOFTWARE\Aagon\ACMP\Client\ComputerScannerConfig"
  $registryPath64 = "HKLM:\SOFTWARE\WOW6432Node\Aagon\ACMP\Client\ComputerScannerConfig"
  $Name = "SkipMitecIDEScanner"
  $value = "1"
  New-Item -Path $registryPath32 			-Force | Out-Null
  New-ItemProperty -Path $registryPath32 -Name $name -Value $value -PropertyType DWORD -Force | Out-Null   
  New-Item -Path $registryPath64 -Force | Out-Null
  New-ItemProperty -Path $registryPath64 -Name $name -Value $value -PropertyType DWORD -Force | Out-Null   
  Write-Host "completed."
}

function PurgeACMPClientDir
{
	Write-Host "Purging ACMP Directory ..."
	$dir = [IO.Path]::Combine(${env:programfiles(x86)},"acmpclient")
	Remove-Item $dir -Recurse -Force
	Write-Host "completed."
}

function InstallACMPClient
{
	PurgeACMPClientDir
    Write-Host "Installing ACMP Service ..."
    & \\win-serv-1\acmp\client\launcher.exe
	Write-Host "completed."
}

function UninstallACMPClient
{
    Write-Host "UnInstalling ACMP Service ..."
    SC.exe DELETE ACMPClient
	Write-Host "completed."
}

if ($ComputerScannerFix)
{
  RunComputerScannerFix 
}

$acmpService = Get-Service -Name ACMPClient
if ($acmpService -and $acmpService.Status -eq "Running")
{
  Write-Host "ACMP Service is running."
  exit 0
}

Write-Host "ACMP Service is NOT running."

if ($acmpService)
{
  Write-Host "ACMP Service exists."
  if ($Uninstall)
  {
    UninstallACMPClient
    $acmpService = Get-Service -Name ACMPClient
    if ($acmpService)
    {
      Write-Host "ACMP Service is probably marked for deletion."
    }
    else
    {
	  if ($Install)
	  {
        InstallACMPClient
	  }
    }
  }
}
else
{
  Write-Host "ACMP Service does NOT exist."
  if ($Install)
  {
    InstallACMPClient
  }
}
