$DstBaseFolder = "C:\DesktopClean"
$DateTime = ([datetime]::now).tostring("yyyy-MM-dd_HH-mm-ss.fff")
$DstFolder = Join-Path -Path $DstBaseFolder -ChildPath $DateTime
$SrcFolder = "C:\Users\Besprechung\Desktop"

Write-Host "Cleaning Desktop to $FinalFolder..."

if([System.IO.File]::Exists($DstFolder)){
	Write-Error "DstFolder already exists. Exiting ..."
    exit 1
}

New-Item -Path $DstFolder -ItemType "directory"

Get-ChildItem -Path $SrcFolder -Recurse |  Move-Item -Destination $DstFolder