$InstallerPath = "Setup.exe"
$AdditionalArgs = @("--silent")