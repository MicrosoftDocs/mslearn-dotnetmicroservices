$UseDefaultInstaller = $false

$OverrideExitCode = 0

write-host "getting node_id ..."
$node_id = Get-Content "C:\Program Files\graylog\sidecar\node-id"
if (!$?) { "Error getting node_id"; $OverrideExitCode = 1}
write-host "node_id: $node_id"
  
write-host "remove sidecar configuration on graylog server ..."
PushD \\rackstation.local.enscape\domain-share\bin\sidecar
.\sidecar.exe remove $node_id
$exitcode = $?
PopD
if (!$exitcode) { "Error remove node_id $node_id from server"; $OverrideExitCode = 1}
   


