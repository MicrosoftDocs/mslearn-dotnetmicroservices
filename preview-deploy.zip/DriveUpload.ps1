[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $ClientID,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $ClientSecret,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $RefreshToken,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $SourceFile,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $SourcesDirectory,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $BuildId,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $DestinationDriveFolder
)

$ErrorActionPreference = 'Stop'

#Fetch the version name to form the Destination FileName
$DestinationFileName = Get-Content "$SourcesDirectory\DemoApp\Bin64\version.txt"
$DestinationFileName = "Enscape-SDK-$DestinationFileName-$BuildId.zip"

Write-Verbose "ClientId is $ClientID"
Write-Verbose "DestinationFileName is $DestinationFileName"
Write-Verbose "DestinationFolder is $DestinationDriveFolder"

# Set the Google Auth parameters. Fill in your RefreshToken, ClientID, and ClientSecret
 $params = @{
     Uri = 'https://accounts.google.com/o/oauth2/token'
     Body = @(
         "refresh_token=$RefreshToken", 
         "client_id=$ClientID",         
         "client_secret=$ClientSecret", 
         "grant_type=refresh_token"
     ) -join '&'
     Method = 'Post'
     ContentType = 'application/x-www-form-urlencoded'
 }

 # Fetch the access token using ClientID, Clinet Secret and Refresh Token
 try{
    $accessToken = (Invoke-RestMethod @params).access_token
 }
 catch{
    Write-Verbose "ERROR: $( $_.Exception )"
    exit -1
 }

# If uploading to a Team Drive, set this to 'true'
$supportsTeamDrives = 'true'


try{
    curl -X POST -L -H "Authorization: Bearer $accessToken" `
                    -F "metadata={name : '$DestinationFileName', parents : ['$DestinationDriveFolder']};type=application/json;charset=UTF-8" `
                    -F "file=@$SourceFile" "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsTeamDrives=$supportsTeamDrives"
}
catch{
    Write-Verbose "ERROR: $( $_.Exception )"
    exit -1
}


